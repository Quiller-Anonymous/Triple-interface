import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Term_2_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Term_2_797

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4782_797_X1000000_rowChunk_2_0 : Finset ℕ :=
  ([1, 797] : List ℕ).toFinset

def periodicMainPair_4782_797_X1000000_rowPartValue_2_0 : ℕ → ℚ
| 1 => (-11101636 : ℚ) / 2778889
| 797 => (-8836902256 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4782_797_X1000000_rowPart_2_0 :
    (∑ h ∈ periodicMainPair_4782_797_X1000000_rowChunk_2_0,
      ramanujanGcdClassCoeffRat 4782 2 * ramanujanGcdClassCoeffRat 797 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 2 h
                - ramanujanGcdClassWindowAverageRat X0 797 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 2
                - ramanujanGcdClassWindowAverageRat X0 4782 2
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 h
                + ramanujanGcdClassWindowAverageRat X0 4782 2
                    * ramanujanGcdClassWindowAverageRat X0 797 h
                    * evenRamanujanBlockCountRat 4782 797))
    ) = (-8848003892 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4782_797_X1000000_rowChunk_2_0,
        ramanujanGcdClassCoeffRat 4782 2 * ramanujanGcdClassCoeffRat 797 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 2 h
                  - ramanujanGcdClassWindowAverageRat X0 797 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 2
                  - ramanujanGcdClassWindowAverageRat X0 4782 2
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 h
                  + ramanujanGcdClassWindowAverageRat X0 4782 2
                      * ramanujanGcdClassWindowAverageRat X0 797 h
                      * evenRamanujanBlockCountRat 4782 797))
      ) = (∑ h ∈ periodicMainPair_4782_797_X1000000_rowChunk_2_0, periodicMainPair_4782_797_X1000000_rowPartValue_2_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4782_797_X1000000_rowChunk_2_0] at hh
    rcases hh with rfl | rfl
    · simpa [periodicMainPair_4782_797_X1000000_rowPartValue_2_0] using periodicMainPair_4782_797_X1000000_term_2_1
    · simpa [periodicMainPair_4782_797_X1000000_rowPartValue_2_0] using periodicMainPair_4782_797_X1000000_term_2_797
  rw [hsum]
  norm_num [periodicMainPair_4782_797_X1000000_rowChunk_2_0, periodicMainPair_4782_797_X1000000_rowPartValue_2_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
