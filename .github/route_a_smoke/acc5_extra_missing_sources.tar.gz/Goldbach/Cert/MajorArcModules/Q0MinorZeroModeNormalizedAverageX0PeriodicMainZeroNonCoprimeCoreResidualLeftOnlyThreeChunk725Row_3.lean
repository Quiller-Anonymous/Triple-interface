import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_3Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_797_X1000000_divRight_for_row_3 : Nat.divisors 797 = ([1, 797] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4782_797_X1000000_row_3 :
    (∑ h ∈ Nat.divisors 797,
      ramanujanGcdClassCoeffRat 4782 3 * ramanujanGcdClassCoeffRat 797 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 3 h
                - ramanujanGcdClassWindowAverageRat X0 797 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 3
                - ramanujanGcdClassWindowAverageRat X0 4782 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 h
                + ramanujanGcdClassWindowAverageRat X0 4782 3
                    * ramanujanGcdClassWindowAverageRat X0 797 h
                    * evenRamanujanBlockCountRat 4782 797))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_4782_797_X1000000_divRight_for_row_3]
  have hset : ([1, 797] : List ℕ).toFinset = periodicMainPair_4782_797_X1000000_rowChunk_3_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4782_797_X1000000_rowPart_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
