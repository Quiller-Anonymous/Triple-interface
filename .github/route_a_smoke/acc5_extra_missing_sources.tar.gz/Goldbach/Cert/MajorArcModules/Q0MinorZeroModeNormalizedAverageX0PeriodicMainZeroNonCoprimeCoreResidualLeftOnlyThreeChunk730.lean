import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Row_1609
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Row_4827

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 730. -/

theorem periodicMainPair_4827_1609_X1000000_divLeft : Nat.divisors 4827 = ([1, 3, 1609, 4827] : List ℕ).toFinset := by
  decide

def periodicMainPair_4827_1609_X1000000_rowValue : ℕ → ℚ
| 1 => (-8936913752 : ℚ) / 2778889
| 3 => (8936913752 : ℚ) / 2778889
| 1609 => (-14370557313216 : ℚ) / 2778889
| 4827 => (14370557313216 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4827_1609_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 4827 1609 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 4827, ∑ h ∈ Nat.divisors 1609,
        ramanujanGcdClassCoeffRat 4827 g * ramanujanGcdClassCoeffRat 1609 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 g h
                  - ramanujanGcdClassWindowAverageRat X0 1609 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 g
                  - ramanujanGcdClassWindowAverageRat X0 4827 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 h
                  + ramanujanGcdClassWindowAverageRat X0 4827 g
                      * ramanujanGcdClassWindowAverageRat X0 1609 h
                      * evenRamanujanBlockCountRat 4827 1609))
      ) = (∑ g ∈ Nat.divisors 4827, periodicMainPair_4827_1609_X1000000_rowValue g) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_4827_1609_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4827_1609_X1000000_rowValue] using periodicMainPair_4827_1609_X1000000_row_1
    · simpa [periodicMainPair_4827_1609_X1000000_rowValue] using periodicMainPair_4827_1609_X1000000_row_3
    · simpa [periodicMainPair_4827_1609_X1000000_rowValue] using periodicMainPair_4827_1609_X1000000_row_1609
    · simpa [periodicMainPair_4827_1609_X1000000_rowValue] using periodicMainPair_4827_1609_X1000000_row_4827
  rw [hsum, periodicMainPair_4827_1609_X1000000_divLeft]
  norm_num [periodicMainPair_4827_1609_X1000000_rowValue]

theorem periodicMainPair_4827_1609_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 4827 1609) = (0 : ℚ) / 1 := by
  have hneq : 4827 ≠ 1609 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 4827 = (5 : ℚ) / 10342656 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 1609 = (5 : ℚ) / 2585664 := by
    native_decide
  have hvalue : ((5 : ℚ) / 10342656) * ((5 : ℚ) / 2585664) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_4827_1609_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsCoreLeftOnlyThreeChunk730Pairs : Finset (ℕ × ℕ) :=
  [(4827, 1609)].toFinset

theorem PeriodicMainRecordsCoreLeftOnlyThreeChunk730_value_on_records :
    ∀ p ∈ PeriodicMainRecordsCoreLeftOnlyThreeChunk730Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsCoreLeftOnlyThreeChunk730Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_4827_1609_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
