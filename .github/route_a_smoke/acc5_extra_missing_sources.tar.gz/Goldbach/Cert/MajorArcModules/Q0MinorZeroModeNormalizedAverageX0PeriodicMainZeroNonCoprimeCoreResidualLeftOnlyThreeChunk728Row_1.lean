import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk728Row_1Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4803_1601_X1000000_divRight_for_row_1 : Nat.divisors 1601 = ([1, 1601] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4803_1601_X1000000_row_1 :
    (∑ h ∈ Nat.divisors 1601,
      ramanujanGcdClassCoeffRat 4803 1 * ramanujanGcdClassCoeffRat 1601 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4803 1601) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4803 1601 1 h
                - ramanujanGcdClassWindowAverageRat X0 1601 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 4803 1
                - ramanujanGcdClassWindowAverageRat X0 4803 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 1601 h
                + ramanujanGcdClassWindowAverageRat X0 4803 1
                    * ramanujanGcdClassWindowAverageRat X0 1601 h
                    * evenRamanujanBlockCountRat 4803 1601))
    ) = (-8892453512 : ℚ) / 2778889 := by
  rw [periodicMainPair_4803_1601_X1000000_divRight_for_row_1]
  have hset : ([1, 1601] : List ℕ).toFinset = periodicMainPair_4803_1601_X1000000_rowChunk_1_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4803_1601_X1000000_rowPart_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
