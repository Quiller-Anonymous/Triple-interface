import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_797_X1000000_term_6_797 :
    ramanujanGcdClassCoeffRat 4782 6 * ramanujanGcdClassCoeffRat 797 797
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 6 797
              - ramanujanGcdClassWindowAverageRat X0 797 797
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 6
              - ramanujanGcdClassWindowAverageRat X0 4782 6
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 797
              + ramanujanGcdClassWindowAverageRat X0 4782 6
                  * ramanujanGcdClassWindowAverageRat X0 797 797
                  * evenRamanujanBlockCountRat 4782 797))
      = (8836902256 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
