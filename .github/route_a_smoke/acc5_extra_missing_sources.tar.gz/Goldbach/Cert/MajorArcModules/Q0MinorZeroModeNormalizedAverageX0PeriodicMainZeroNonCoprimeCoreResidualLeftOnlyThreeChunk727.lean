import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk727Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk727Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk727Row_1597
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk727Row_4791

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 727. -/

theorem periodicMainPair_4791_1597_X1000000_divLeft : Nat.divisors 4791 = ([1, 3, 1597, 4791] : List ℕ).toFinset := by
  decide

def periodicMainPair_4791_1597_X1000000_rowValue : ℕ → ℚ
| 1 => (-8870223488 : ℚ) / 2778889
| 3 => (8870223488 : ℚ) / 2778889
| 1597 => (-14156876686848 : ℚ) / 2778889
| 4791 => (14156876686848 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4791_1597_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 4791 1597 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 4791, ∑ h ∈ Nat.divisors 1597,
        ramanujanGcdClassCoeffRat 4791 g * ramanujanGcdClassCoeffRat 1597 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4791 1597) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4791 1597 g h
                  - ramanujanGcdClassWindowAverageRat X0 1597 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 4791 g
                  - ramanujanGcdClassWindowAverageRat X0 4791 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 1597 h
                  + ramanujanGcdClassWindowAverageRat X0 4791 g
                      * ramanujanGcdClassWindowAverageRat X0 1597 h
                      * evenRamanujanBlockCountRat 4791 1597))
      ) = (∑ g ∈ Nat.divisors 4791, periodicMainPair_4791_1597_X1000000_rowValue g) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_4791_1597_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4791_1597_X1000000_rowValue] using periodicMainPair_4791_1597_X1000000_row_1
    · simpa [periodicMainPair_4791_1597_X1000000_rowValue] using periodicMainPair_4791_1597_X1000000_row_3
    · simpa [periodicMainPair_4791_1597_X1000000_rowValue] using periodicMainPair_4791_1597_X1000000_row_1597
    · simpa [periodicMainPair_4791_1597_X1000000_rowValue] using periodicMainPair_4791_1597_X1000000_row_4791
  rw [hsum, periodicMainPair_4791_1597_X1000000_divLeft]
  norm_num [periodicMainPair_4791_1597_X1000000_rowValue]

theorem periodicMainPair_4791_1597_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 4791 1597) = (0 : ℚ) / 1 := by
  have hneq : 4791 ≠ 1597 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 4791 = (5 : ℚ) / 10188864 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 1597 = (5 : ℚ) / 2547216 := by
    native_decide
  have hvalue : ((5 : ℚ) / 10188864) * ((5 : ℚ) / 2547216) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_4791_1597_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsCoreLeftOnlyThreeChunk727Pairs : Finset (ℕ × ℕ) :=
  [(4791, 1597)].toFinset

theorem PeriodicMainRecordsCoreLeftOnlyThreeChunk727_value_on_records :
    ∀ p ∈ PeriodicMainRecordsCoreLeftOnlyThreeChunk727Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsCoreLeftOnlyThreeChunk727Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_4791_1597_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
