import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4791_1597_X1000000_term_1_1597 :
    ramanujanGcdClassCoeffRat 4791 1 * ramanujanGcdClassCoeffRat 1597 1597
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4791 1597) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4791 1597 1 1597
              - ramanujanGcdClassWindowAverageRat X0 1597 1597
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 4791 1
              - ramanujanGcdClassWindowAverageRat X0 4791 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 1597 1597
              + ramanujanGcdClassWindowAverageRat X0 4791 1
                  * ramanujanGcdClassWindowAverageRat X0 1597 1597
                  * evenRamanujanBlockCountRat 4791 1597))
      = (-8864669184 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
