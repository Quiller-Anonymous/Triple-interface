import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_4782Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_797_X1000000_divRight_for_row_4782 : Nat.divisors 797 = ([1, 797] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4782_797_X1000000_row_4782 :
    (∑ h ∈ Nat.divisors 797,
      ramanujanGcdClassCoeffRat 4782 4782 * ramanujanGcdClassCoeffRat 797 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 4782 h
                - ramanujanGcdClassWindowAverageRat X0 797 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 4782
                - ramanujanGcdClassWindowAverageRat X0 4782 4782
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 h
                + ramanujanGcdClassWindowAverageRat X0 4782 4782
                    * ramanujanGcdClassWindowAverageRat X0 797 h
                    * evenRamanujanBlockCountRat 4782 797))
    ) = (7043011098032 : ℚ) / 2778889 := by
  rw [periodicMainPair_4782_797_X1000000_divRight_for_row_4782]
  have hset : ([1, 797] : List ℕ).toFinset = periodicMainPair_4782_797_X1000000_rowChunk_4782_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4782_797_X1000000_rowPart_4782_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
