import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_226_X1000000_term_226_113 :
    ramanujanGcdClassCoeffRat 4746 226 * ramanujanGcdClassCoeffRat 226 113
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 226 113
              - ramanujanGcdClassWindowAverageRat X0 226 113
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 226
              - ramanujanGcdClassWindowAverageRat X0 4746 226
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 113
              + ramanujanGcdClassWindowAverageRat X0 4746 226
                  * ramanujanGcdClassWindowAverageRat X0 226 113
                  * evenRamanujanBlockCountRat 4746 226))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 4746 226 = (112 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 226 113 = (-112 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 4746 226 = (26 : ℚ) / 5001 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 226 113 = (0 : ℚ) / 1 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 226 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 113 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 226 113 = (0 : ℚ) := by
    have hcompat : ¬ ramanujanGcdClassJointCompatibility 4746 226 226 113 := by
      native_decide
    unfold rawEvenRamanujanGcdClassPairBlockResolvedCountRat
    simp [hcompat]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
