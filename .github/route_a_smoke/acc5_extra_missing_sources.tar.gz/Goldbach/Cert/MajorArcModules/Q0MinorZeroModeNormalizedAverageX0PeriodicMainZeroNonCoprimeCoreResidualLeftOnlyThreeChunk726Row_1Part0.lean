import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk726Term_1_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk726Term_1_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk726Term_1_797
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk726Term_1_1594

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4782_1594_X1000000_rowChunk_1_0 : Finset ℕ :=
  ([1, 2, 797, 1594] : List ℕ).toFinset

def periodicMainPair_4782_1594_X1000000_rowPartValue_1_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 797 => (0 : ℚ) / 1
| 1594 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_4782_1594_X1000000_rowPart_1_0 :
    (∑ h ∈ periodicMainPair_4782_1594_X1000000_rowChunk_1_0,
      ramanujanGcdClassCoeffRat 4782 1 * ramanujanGcdClassCoeffRat 1594 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 1594) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 1 h
                - ramanujanGcdClassWindowAverageRat X0 1594 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 1
                - ramanujanGcdClassWindowAverageRat X0 4782 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 h
                + ramanujanGcdClassWindowAverageRat X0 4782 1
                    * ramanujanGcdClassWindowAverageRat X0 1594 h
                    * evenRamanujanBlockCountRat 4782 1594))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4782_1594_X1000000_rowChunk_1_0,
        ramanujanGcdClassCoeffRat 4782 1 * ramanujanGcdClassCoeffRat 1594 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 1594) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 1 h
                  - ramanujanGcdClassWindowAverageRat X0 1594 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 1
                  - ramanujanGcdClassWindowAverageRat X0 4782 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 h
                  + ramanujanGcdClassWindowAverageRat X0 4782 1
                      * ramanujanGcdClassWindowAverageRat X0 1594 h
                      * evenRamanujanBlockCountRat 4782 1594))
      ) = (∑ h ∈ periodicMainPair_4782_1594_X1000000_rowChunk_1_0, periodicMainPair_4782_1594_X1000000_rowPartValue_1_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4782_1594_X1000000_rowChunk_1_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4782_1594_X1000000_rowPartValue_1_0] using periodicMainPair_4782_1594_X1000000_term_1_1
    · simpa [periodicMainPair_4782_1594_X1000000_rowPartValue_1_0] using periodicMainPair_4782_1594_X1000000_term_1_2
    · simpa [periodicMainPair_4782_1594_X1000000_rowPartValue_1_0] using periodicMainPair_4782_1594_X1000000_term_1_797
    · simpa [periodicMainPair_4782_1594_X1000000_rowPartValue_1_0] using periodicMainPair_4782_1594_X1000000_term_1_1594
  rw [hsum]
  norm_num [periodicMainPair_4782_1594_X1000000_rowChunk_1_0, periodicMainPair_4782_1594_X1000000_rowPartValue_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
