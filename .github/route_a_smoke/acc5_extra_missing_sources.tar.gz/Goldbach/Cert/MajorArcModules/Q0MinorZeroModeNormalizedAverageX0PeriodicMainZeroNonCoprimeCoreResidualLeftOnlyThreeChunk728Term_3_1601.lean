import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4803_1601_X1000000_term_3_1601 :
    ramanujanGcdClassCoeffRat 4803 3 * ramanujanGcdClassCoeffRat 1601 1601
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4803 1601) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4803 1601 3 1601
              - ramanujanGcdClassWindowAverageRat X0 1601 1601
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 4803 3
              - ramanujanGcdClassWindowAverageRat X0 4803 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 1601 1601
              + ramanujanGcdClassWindowAverageRat X0 4803 3
                  * ramanujanGcdClassWindowAverageRat X0 1601 1601
                  * evenRamanujanBlockCountRat 4803 1601))
      = (8886899200 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
