import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_791_X1000000_term_42_7 :
    ramanujanGcdClassCoeffRat 4746 42 * ramanujanGcdClassCoeffRat 791 7
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 42 7
              - ramanujanGcdClassWindowAverageRat X0 791 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 42
              - ramanujanGcdClassWindowAverageRat X0 4746 42
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 7
              + ramanujanGcdClassWindowAverageRat X0 4746 42
                  * ramanujanGcdClassWindowAverageRat X0 791 7
                  * evenRamanujanBlockCountRat 4746 791))
      = (38472021504 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
