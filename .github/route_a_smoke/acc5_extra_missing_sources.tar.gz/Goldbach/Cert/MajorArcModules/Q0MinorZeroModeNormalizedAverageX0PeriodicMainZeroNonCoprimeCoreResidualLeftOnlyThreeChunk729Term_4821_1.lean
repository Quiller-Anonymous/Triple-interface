import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4821_1607_X1000000_term_4821_1 :
    ramanujanGcdClassCoeffRat 4821 4821 * ramanujanGcdClassCoeffRat 1607 1
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4821 1607) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4821 1607 4821 1
              - ramanujanGcdClassWindowAverageRat X0 1607 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 4821 4821
              - ramanujanGcdClassWindowAverageRat X0 4821 4821
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 1607 1
              + ramanujanGcdClassWindowAverageRat X0 4821 4821
                  * ramanujanGcdClassWindowAverageRat X0 1607 1
                  * evenRamanujanBlockCountRat 4821 1607))
      = (8920244344 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
