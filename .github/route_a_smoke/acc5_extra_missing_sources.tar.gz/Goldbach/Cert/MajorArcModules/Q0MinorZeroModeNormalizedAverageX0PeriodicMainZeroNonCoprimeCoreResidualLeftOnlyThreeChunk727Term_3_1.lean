import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4791_1597_X1000000_term_3_1 :
    ramanujanGcdClassCoeffRat 4791 3 * ramanujanGcdClassCoeffRat 1597 1
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4791 1597) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4791 1597 3 1
              - ramanujanGcdClassWindowAverageRat X0 1597 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 4791 3
              - ramanujanGcdClassWindowAverageRat X0 4791 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 1597 1
              + ramanujanGcdClassWindowAverageRat X0 4791 3
                  * ramanujanGcdClassWindowAverageRat X0 1597 1
                  * evenRamanujanBlockCountRat 4791 1597))
      = (5554304 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
