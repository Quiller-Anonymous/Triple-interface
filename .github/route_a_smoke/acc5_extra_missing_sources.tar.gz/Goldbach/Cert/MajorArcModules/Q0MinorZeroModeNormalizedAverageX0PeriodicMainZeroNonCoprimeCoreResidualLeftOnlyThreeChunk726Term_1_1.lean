import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_1594_X1000000_term_1_1 :
    ramanujanGcdClassCoeffRat 4782 1 * ramanujanGcdClassCoeffRat 1594 1
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 1594) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 1 1
              - ramanujanGcdClassWindowAverageRat X0 1594 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 1
              - ramanujanGcdClassWindowAverageRat X0 4782 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 1
              + ramanujanGcdClassWindowAverageRat X0 4782 1
                  * ramanujanGcdClassWindowAverageRat X0 1594 1
                  * evenRamanujanBlockCountRat 4782 1594))
      = (0 : ℚ) / 1 := by
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 1594 1 = (0 : ℚ) / 1 := by
    native_decide
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  rw [hPair, hAvgRight, hBlockRight]
  simp

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
