import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Term_3_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Term_3_1609

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4827_1609_X1000000_rowChunk_3_0 : Finset ℕ :=
  ([1, 1609] : List ℕ).toFinset

def periodicMainPair_4827_1609_X1000000_rowPartValue_3_0 : ℕ → ℚ
| 1 => (5554328 : ℚ) / 2778889
| 1609 => (8931359424 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4827_1609_X1000000_rowPart_3_0 :
    (∑ h ∈ periodicMainPair_4827_1609_X1000000_rowChunk_3_0,
      ramanujanGcdClassCoeffRat 4827 3 * ramanujanGcdClassCoeffRat 1609 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 3 h
                - ramanujanGcdClassWindowAverageRat X0 1609 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 3
                - ramanujanGcdClassWindowAverageRat X0 4827 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 h
                + ramanujanGcdClassWindowAverageRat X0 4827 3
                    * ramanujanGcdClassWindowAverageRat X0 1609 h
                    * evenRamanujanBlockCountRat 4827 1609))
    ) = (8936913752 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4827_1609_X1000000_rowChunk_3_0,
        ramanujanGcdClassCoeffRat 4827 3 * ramanujanGcdClassCoeffRat 1609 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 3 h
                  - ramanujanGcdClassWindowAverageRat X0 1609 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 3
                  - ramanujanGcdClassWindowAverageRat X0 4827 3
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 h
                  + ramanujanGcdClassWindowAverageRat X0 4827 3
                      * ramanujanGcdClassWindowAverageRat X0 1609 h
                      * evenRamanujanBlockCountRat 4827 1609))
      ) = (∑ h ∈ periodicMainPair_4827_1609_X1000000_rowChunk_3_0, periodicMainPair_4827_1609_X1000000_rowPartValue_3_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4827_1609_X1000000_rowChunk_3_0] at hh
    rcases hh with rfl | rfl
    · simpa [periodicMainPair_4827_1609_X1000000_rowPartValue_3_0] using periodicMainPair_4827_1609_X1000000_term_3_1
    · simpa [periodicMainPair_4827_1609_X1000000_rowPartValue_3_0] using periodicMainPair_4827_1609_X1000000_term_3_1609
  rw [hsum]
  norm_num [periodicMainPair_4827_1609_X1000000_rowChunk_3_0, periodicMainPair_4827_1609_X1000000_rowPartValue_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
