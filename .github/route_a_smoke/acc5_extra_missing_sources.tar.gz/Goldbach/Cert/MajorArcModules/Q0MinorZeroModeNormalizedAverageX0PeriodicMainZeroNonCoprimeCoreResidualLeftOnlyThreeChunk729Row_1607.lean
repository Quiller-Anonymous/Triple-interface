import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk729Row_1607Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4821_1607_X1000000_divRight_for_row_1607 : Nat.divisors 1607 = ([1, 1607] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4821_1607_X1000000_row_1607 :
    (∑ h ∈ Nat.divisors 1607,
      ramanujanGcdClassCoeffRat 4821 1607 * ramanujanGcdClassCoeffRat 1607 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4821 1607) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4821 1607 1607 h
                - ramanujanGcdClassWindowAverageRat X0 1607 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 4821 1607
                - ramanujanGcdClassWindowAverageRat X0 4821 1607
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 1607 h
                + ramanujanGcdClassWindowAverageRat X0 4821 1607
                    * ramanujanGcdClassWindowAverageRat X0 1607 h
                    * evenRamanujanBlockCountRat 4821 1607))
    ) = (-14334832660808 : ℚ) / 2778889 := by
  rw [periodicMainPair_4821_1607_X1000000_divRight_for_row_1607]
  have hset : ([1, 1607] : List ℕ).toFinset = periodicMainPair_4821_1607_X1000000_rowChunk_1607_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4821_1607_X1000000_rowPart_1607_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
