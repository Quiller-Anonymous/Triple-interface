import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_226_X1000000_term_113_2 :
    ramanujanGcdClassCoeffRat 4746 113 * ramanujanGcdClassCoeffRat 226 2
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 113 2
              - ramanujanGcdClassWindowAverageRat X0 226 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 113
              - ramanujanGcdClassWindowAverageRat X0 4746 113
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 2
              + ramanujanGcdClassWindowAverageRat X0 4746 113
                  * ramanujanGcdClassWindowAverageRat X0 226 2
                  * evenRamanujanBlockCountRat 4746 226))
      = (0 : ℚ) / 1 := by
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 4746 113 = (0 : ℚ) / 1 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 113 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 113 2 = (0 : ℚ) := by
    have hcompat : ¬ ramanujanGcdClassJointCompatibility 4746 226 113 2 := by
      native_decide
    unfold rawEvenRamanujanGcdClassPairBlockResolvedCountRat
    simp [hcompat]
  rw [hPair, hAvgLeft, hBlockLeft]
  simp

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
