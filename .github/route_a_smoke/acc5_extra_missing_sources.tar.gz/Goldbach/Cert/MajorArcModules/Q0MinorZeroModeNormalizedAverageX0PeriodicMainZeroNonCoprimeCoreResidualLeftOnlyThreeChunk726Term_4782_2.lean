import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_1594_X1000000_term_4782_2 :
    ramanujanGcdClassCoeffRat 4782 4782 * ramanujanGcdClassCoeffRat 1594 2
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 1594) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 4782 2
              - ramanujanGcdClassWindowAverageRat X0 1594 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 4782
              - ramanujanGcdClassWindowAverageRat X0 4782 4782
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 2
              + ramanujanGcdClassWindowAverageRat X0 4782 4782
                  * ramanujanGcdClassWindowAverageRat X0 1594 2
                  * evenRamanujanBlockCountRat 4782 1594))
      = (8836902256 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
