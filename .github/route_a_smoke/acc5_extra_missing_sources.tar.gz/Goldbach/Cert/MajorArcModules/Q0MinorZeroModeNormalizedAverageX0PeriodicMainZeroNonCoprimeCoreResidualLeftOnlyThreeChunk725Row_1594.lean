import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_1594Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_797_X1000000_divRight_for_row_1594 : Nat.divisors 797 = ([1, 797] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4782_797_X1000000_row_1594 :
    (∑ h ∈ Nat.divisors 797,
      ramanujanGcdClassCoeffRat 4782 1594 * ramanujanGcdClassCoeffRat 797 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 1594 h
                - ramanujanGcdClassWindowAverageRat X0 797 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 1594
                - ramanujanGcdClassWindowAverageRat X0 4782 1594
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 h
                + ramanujanGcdClassWindowAverageRat X0 4782 1594
                    * ramanujanGcdClassWindowAverageRat X0 797 h
                    * evenRamanujanBlockCountRat 4782 797))
    ) = (-7043011098032 : ℚ) / 2778889 := by
  rw [periodicMainPair_4782_797_X1000000_divRight_for_row_1594]
  have hset : ([1, 797] : List ℕ).toFinset = periodicMainPair_4782_797_X1000000_rowChunk_1594_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4782_797_X1000000_rowPart_1594_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
