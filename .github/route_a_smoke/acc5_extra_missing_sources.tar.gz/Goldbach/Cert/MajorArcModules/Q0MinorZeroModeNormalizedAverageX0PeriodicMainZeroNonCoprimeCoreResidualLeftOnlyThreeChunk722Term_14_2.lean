import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_226_X1000000_term_14_2 :
    ramanujanGcdClassCoeffRat 4746 14 * ramanujanGcdClassCoeffRat 226 2
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 14 2
              - ramanujanGcdClassWindowAverageRat X0 226 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 14
              - ramanujanGcdClassWindowAverageRat X0 4746 14
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 2
              + ramanujanGcdClassWindowAverageRat X0 4746 14
                  * ramanujanGcdClassWindowAverageRat X0 226 2
                  * evenRamanujanBlockCountRat 4746 226))
      = (-66103296 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
