import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_791_X1000000_term_113_113 :
    ramanujanGcdClassCoeffRat 4746 113 * ramanujanGcdClassCoeffRat 791 113
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 113 113
              - ramanujanGcdClassWindowAverageRat X0 791 113
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 113
              - ramanujanGcdClassWindowAverageRat X0 4746 113
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 113
              + ramanujanGcdClassWindowAverageRat X0 4746 113
                  * ramanujanGcdClassWindowAverageRat X0 791 113
                  * evenRamanujanBlockCountRat 4746 791))
      = (0 : ℚ) / 1 := by
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 4746 113 = (0 : ℚ) / 1 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 113 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 113 113 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  rw [hPair, hAvgLeft, hBlockLeft]
  simp

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
