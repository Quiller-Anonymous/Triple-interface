import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_226_X1000000_term_678_226 :
    ramanujanGcdClassCoeffRat 4746 678 * ramanujanGcdClassCoeffRat 226 226
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 678 226
              - ramanujanGcdClassWindowAverageRat X0 226 226
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 678
              - ramanujanGcdClassWindowAverageRat X0 4746 678
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 226
              + ramanujanGcdClassWindowAverageRat X0 4746 678
                  * ramanujanGcdClassWindowAverageRat X0 226 226
                  * evenRamanujanBlockCountRat 4746 226))
      = (-829201149952 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
