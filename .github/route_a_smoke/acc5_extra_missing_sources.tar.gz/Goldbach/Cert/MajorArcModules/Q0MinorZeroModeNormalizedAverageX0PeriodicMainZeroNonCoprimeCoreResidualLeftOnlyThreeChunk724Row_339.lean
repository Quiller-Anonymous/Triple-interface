import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Row_339Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_1582_X1000000_divRight_for_row_339 : Nat.divisors 1582 = ([1, 2, 7, 14, 113, 226, 791, 1582] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4746_1582_X1000000_row_339 :
    (∑ h ∈ Nat.divisors 1582,
      ramanujanGcdClassCoeffRat 4746 339 * ramanujanGcdClassCoeffRat 1582 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 339 h
                - ramanujanGcdClassWindowAverageRat X0 1582 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 339
                - ramanujanGcdClassWindowAverageRat X0 4746 339
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 h
                + ramanujanGcdClassWindowAverageRat X0 4746 339
                    * ramanujanGcdClassWindowAverageRat X0 1582 h
                    * evenRamanujanBlockCountRat 4746 1582))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_4746_1582_X1000000_divRight_for_row_339]
  have hset : ([1, 2, 7, 14, 113, 226, 791, 1582] : List ℕ).toFinset = periodicMainPair_4746_1582_X1000000_rowChunk_339_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4746_1582_X1000000_rowPart_339_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
