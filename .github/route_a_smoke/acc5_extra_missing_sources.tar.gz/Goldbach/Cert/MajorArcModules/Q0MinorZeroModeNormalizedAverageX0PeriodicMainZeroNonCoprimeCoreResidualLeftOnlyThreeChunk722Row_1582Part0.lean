import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_1582_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_1582_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_1582_113
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_1582_226

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4746_226_X1000000_rowChunk_1582_0 : Finset ℕ :=
  ([1, 2, 113, 226] : List ℕ).toFinset

def periodicMainPair_4746_226_X1000000_rowPartValue_1582_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (-7403493888 : ℚ) / 2778889
| 113 => (0 : ℚ) / 1
| 226 => (-829191315456 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4746_226_X1000000_rowPart_1582_0 :
    (∑ h ∈ periodicMainPair_4746_226_X1000000_rowChunk_1582_0,
      ramanujanGcdClassCoeffRat 4746 1582 * ramanujanGcdClassCoeffRat 226 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 1582 h
                - ramanujanGcdClassWindowAverageRat X0 226 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 1582
                - ramanujanGcdClassWindowAverageRat X0 4746 1582
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 h
                + ramanujanGcdClassWindowAverageRat X0 4746 1582
                    * ramanujanGcdClassWindowAverageRat X0 226 h
                    * evenRamanujanBlockCountRat 4746 226))
    ) = (-836594809344 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4746_226_X1000000_rowChunk_1582_0,
        ramanujanGcdClassCoeffRat 4746 1582 * ramanujanGcdClassCoeffRat 226 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 1582 h
                  - ramanujanGcdClassWindowAverageRat X0 226 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 1582
                  - ramanujanGcdClassWindowAverageRat X0 4746 1582
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 h
                  + ramanujanGcdClassWindowAverageRat X0 4746 1582
                      * ramanujanGcdClassWindowAverageRat X0 226 h
                      * evenRamanujanBlockCountRat 4746 226))
      ) = (∑ h ∈ periodicMainPair_4746_226_X1000000_rowChunk_1582_0, periodicMainPair_4746_226_X1000000_rowPartValue_1582_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4746_226_X1000000_rowChunk_1582_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_226_X1000000_term_1582_1
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_226_X1000000_term_1582_2
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_226_X1000000_term_1582_113
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_226_X1000000_term_1582_226
  rw [hsum]
  norm_num [periodicMainPair_4746_226_X1000000_rowChunk_1582_0, periodicMainPair_4746_226_X1000000_rowPartValue_1582_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
