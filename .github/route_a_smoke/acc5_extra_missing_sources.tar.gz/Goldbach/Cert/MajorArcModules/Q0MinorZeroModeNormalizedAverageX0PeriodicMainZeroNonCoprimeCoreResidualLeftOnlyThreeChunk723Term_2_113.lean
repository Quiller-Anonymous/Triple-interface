import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_791_X1000000_term_2_113 :
    ramanujanGcdClassCoeffRat 4746 2 * ramanujanGcdClassCoeffRat 791 113
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 2 113
              - ramanujanGcdClassWindowAverageRat X0 791 113
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 2
              - ramanujanGcdClassWindowAverageRat X0 4746 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 113
              + ramanujanGcdClassWindowAverageRat X0 4746 2
                  * ramanujanGcdClassWindowAverageRat X0 791 113
                  * evenRamanujanBlockCountRat 4746 791))
      = (-6345927168 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
