import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_1594_X1000000_term_3_1594 :
    ramanujanGcdClassCoeffRat 4782 3 * ramanujanGcdClassCoeffRat 1594 1594
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 1594) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 3 1594
              - ramanujanGcdClassWindowAverageRat X0 1594 1594
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 3
              - ramanujanGcdClassWindowAverageRat X0 4782 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 1594
              + ramanujanGcdClassWindowAverageRat X0 4782 3
                  * ramanujanGcdClassWindowAverageRat X0 1594 1594
                  * evenRamanujanBlockCountRat 4782 1594))
      = (0 : ℚ) / 1 := by
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 4782 3 = (0 : ℚ) / 1 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 3 1594 = (0 : ℚ) := by
    have hcompat : ¬ ramanujanGcdClassJointCompatibility 4782 1594 3 1594 := by
      native_decide
    unfold rawEvenRamanujanGcdClassPairBlockResolvedCountRat
    simp [hcompat]
  rw [hPair, hAvgLeft, hBlockLeft]
  simp

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
