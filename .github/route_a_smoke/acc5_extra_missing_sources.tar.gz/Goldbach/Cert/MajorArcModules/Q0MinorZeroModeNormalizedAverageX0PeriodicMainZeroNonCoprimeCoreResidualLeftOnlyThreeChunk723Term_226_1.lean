import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_791_X1000000_term_226_1 :
    ramanujanGcdClassCoeffRat 4746 226 * ramanujanGcdClassCoeffRat 791 1
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 226 1
              - ramanujanGcdClassWindowAverageRat X0 791 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 226
              - ramanujanGcdClassWindowAverageRat X0 4746 226
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 1
              + ramanujanGcdClassWindowAverageRat X0 4746 226
                  * ramanujanGcdClassWindowAverageRat X0 791 1
                  * evenRamanujanBlockCountRat 4746 791))
      = (-6345927168 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
