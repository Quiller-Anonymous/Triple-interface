import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_1594_X1000000_term_2_797 :
    ramanujanGcdClassCoeffRat 4782 2 * ramanujanGcdClassCoeffRat 1594 797
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 1594) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 2 797
              - ramanujanGcdClassWindowAverageRat X0 1594 797
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 2
              - ramanujanGcdClassWindowAverageRat X0 4782 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 797
              + ramanujanGcdClassWindowAverageRat X0 4782 2
                  * ramanujanGcdClassWindowAverageRat X0 1594 797
                  * evenRamanujanBlockCountRat 4782 1594))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 4782 2 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 1594 797 = (-796 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 4782 2 = (1110 : ℚ) / 1667 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 1594 797 = (0 : ℚ) / 1 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 2 = (3184 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 797 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 2 797 = (0 : ℚ) := by
    have hcompat : ¬ ramanujanGcdClassJointCompatibility 4782 1594 2 797 := by
      native_decide
    unfold rawEvenRamanujanGcdClassPairBlockResolvedCountRat
    simp [hcompat]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
