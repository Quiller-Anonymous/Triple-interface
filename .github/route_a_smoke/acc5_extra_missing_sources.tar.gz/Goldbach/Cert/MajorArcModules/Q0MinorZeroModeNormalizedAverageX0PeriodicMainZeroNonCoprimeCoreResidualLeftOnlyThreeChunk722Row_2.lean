import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Row_2Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_226_X1000000_divRight_for_row_2 : Nat.divisors 226 = ([1, 2, 113, 226] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4746_226_X1000000_row_2 :
    (∑ h ∈ Nat.divisors 226,
      ramanujanGcdClassCoeffRat 4746 2 * ramanujanGcdClassCoeffRat 226 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 2 h
                - ramanujanGcdClassWindowAverageRat X0 226 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 2
                - ramanujanGcdClassWindowAverageRat X0 4746 2
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 h
                + ramanujanGcdClassWindowAverageRat X0 4746 2
                    * ramanujanGcdClassWindowAverageRat X0 226 h
                    * evenRamanujanBlockCountRat 4746 226))
    ) = (7469672448 : ℚ) / 2778889 := by
  rw [periodicMainPair_4746_226_X1000000_divRight_for_row_2]
  have hset : ([1, 2, 113, 226] : List ℕ).toFinset = periodicMainPair_4746_226_X1000000_rowChunk_2_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4746_226_X1000000_rowPart_2_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
