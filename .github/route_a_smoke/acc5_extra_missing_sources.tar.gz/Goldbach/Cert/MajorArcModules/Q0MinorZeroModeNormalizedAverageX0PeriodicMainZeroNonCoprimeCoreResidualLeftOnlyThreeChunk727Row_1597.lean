import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk727Row_1597Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4791_1597_X1000000_divRight_for_row_1597 : Nat.divisors 1597 = ([1, 1597] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4791_1597_X1000000_row_1597 :
    (∑ h ∈ Nat.divisors 1597,
      ramanujanGcdClassCoeffRat 4791 1597 * ramanujanGcdClassCoeffRat 1597 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4791 1597) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4791 1597 1597 h
                - ramanujanGcdClassWindowAverageRat X0 1597 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 4791 1597
                - ramanujanGcdClassWindowAverageRat X0 4791 1597
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 1597 h
                + ramanujanGcdClassWindowAverageRat X0 4791 1597
                    * ramanujanGcdClassWindowAverageRat X0 1597 h
                    * evenRamanujanBlockCountRat 4791 1597))
    ) = (-14156876686848 : ℚ) / 2778889 := by
  rw [periodicMainPair_4791_1597_X1000000_divRight_for_row_1597]
  have hset : ([1, 1597] : List ℕ).toFinset = periodicMainPair_4791_1597_X1000000_rowChunk_1597_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4791_1597_X1000000_rowPart_1597_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
