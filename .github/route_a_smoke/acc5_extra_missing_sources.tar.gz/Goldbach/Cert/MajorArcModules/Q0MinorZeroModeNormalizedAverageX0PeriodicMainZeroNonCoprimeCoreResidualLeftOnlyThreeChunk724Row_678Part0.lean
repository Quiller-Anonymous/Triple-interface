import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_7
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_14
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_113
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_226
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_791
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_678_1582

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4746_1582_X1000000_rowChunk_678_0 : Finset ℕ :=
  ([1, 2, 7, 14, 113, 226, 791, 1582] : List ℕ).toFinset

def periodicMainPair_4746_1582_X1000000_rowPartValue_678_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (6345927168 : ℚ) / 2778889
| 7 => (0 : ℚ) / 1
| 14 => (-6345927168 : ℚ) / 2778889
| 113 => (0 : ℚ) / 1
| 226 => (830260315136 : ℚ) / 2778889
| 791 => (0 : ℚ) / 1
| 1582 => (6354991104 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4746_1582_X1000000_rowPart_678_0 :
    (∑ h ∈ periodicMainPair_4746_1582_X1000000_rowChunk_678_0,
      ramanujanGcdClassCoeffRat 4746 678 * ramanujanGcdClassCoeffRat 1582 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 678 h
                - ramanujanGcdClassWindowAverageRat X0 1582 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 678
                - ramanujanGcdClassWindowAverageRat X0 4746 678
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 h
                + ramanujanGcdClassWindowAverageRat X0 4746 678
                    * ramanujanGcdClassWindowAverageRat X0 1582 h
                    * evenRamanujanBlockCountRat 4746 1582))
    ) = (836615306240 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4746_1582_X1000000_rowChunk_678_0,
        ramanujanGcdClassCoeffRat 4746 678 * ramanujanGcdClassCoeffRat 1582 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 678 h
                  - ramanujanGcdClassWindowAverageRat X0 1582 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 678
                  - ramanujanGcdClassWindowAverageRat X0 4746 678
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 h
                  + ramanujanGcdClassWindowAverageRat X0 4746 678
                      * ramanujanGcdClassWindowAverageRat X0 1582 h
                      * evenRamanujanBlockCountRat 4746 1582))
      ) = (∑ h ∈ periodicMainPair_4746_1582_X1000000_rowChunk_678_0, periodicMainPair_4746_1582_X1000000_rowPartValue_678_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4746_1582_X1000000_rowChunk_678_0] at hh
    rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_1
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_2
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_7
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_14
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_113
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_226
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_791
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_678_0] using periodicMainPair_4746_1582_X1000000_term_678_1582
  rw [hsum]
  norm_num [periodicMainPair_4746_1582_X1000000_rowChunk_678_0, periodicMainPair_4746_1582_X1000000_rowPartValue_678_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
