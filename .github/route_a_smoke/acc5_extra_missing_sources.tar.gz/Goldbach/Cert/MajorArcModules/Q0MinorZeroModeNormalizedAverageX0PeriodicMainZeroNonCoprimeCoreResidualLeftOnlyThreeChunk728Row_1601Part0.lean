import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk728Term_1601_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk728Term_1601_1601

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4803_1601_X1000000_rowChunk_1601_0 : Finset ℕ :=
  ([1, 1601] : List ℕ).toFinset

def periodicMainPair_4803_1601_X1000000_rowPartValue_1601_0 : ℕ → ℚ
| 1 => (-8886899200 : ℚ) / 2778889
| 1601 => (-14219038720000 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4803_1601_X1000000_rowPart_1601_0 :
    (∑ h ∈ periodicMainPair_4803_1601_X1000000_rowChunk_1601_0,
      ramanujanGcdClassCoeffRat 4803 1601 * ramanujanGcdClassCoeffRat 1601 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4803 1601) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4803 1601 1601 h
                - ramanujanGcdClassWindowAverageRat X0 1601 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 4803 1601
                - ramanujanGcdClassWindowAverageRat X0 4803 1601
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 1601 h
                + ramanujanGcdClassWindowAverageRat X0 4803 1601
                    * ramanujanGcdClassWindowAverageRat X0 1601 h
                    * evenRamanujanBlockCountRat 4803 1601))
    ) = (-14227925619200 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4803_1601_X1000000_rowChunk_1601_0,
        ramanujanGcdClassCoeffRat 4803 1601 * ramanujanGcdClassCoeffRat 1601 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4803 1601) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4803 1601 1601 h
                  - ramanujanGcdClassWindowAverageRat X0 1601 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 4803 1601
                  - ramanujanGcdClassWindowAverageRat X0 4803 1601
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 1601 h
                  + ramanujanGcdClassWindowAverageRat X0 4803 1601
                      * ramanujanGcdClassWindowAverageRat X0 1601 h
                      * evenRamanujanBlockCountRat 4803 1601))
      ) = (∑ h ∈ periodicMainPair_4803_1601_X1000000_rowChunk_1601_0, periodicMainPair_4803_1601_X1000000_rowPartValue_1601_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4803_1601_X1000000_rowChunk_1601_0] at hh
    rcases hh with rfl | rfl
    · simpa [periodicMainPair_4803_1601_X1000000_rowPartValue_1601_0] using periodicMainPair_4803_1601_X1000000_term_1601_1
    · simpa [periodicMainPair_4803_1601_X1000000_rowPartValue_1601_0] using periodicMainPair_4803_1601_X1000000_term_1601_1601
  rw [hsum]
  norm_num [periodicMainPair_4803_1601_X1000000_rowChunk_1601_0, periodicMainPair_4803_1601_X1000000_rowPartValue_1601_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
