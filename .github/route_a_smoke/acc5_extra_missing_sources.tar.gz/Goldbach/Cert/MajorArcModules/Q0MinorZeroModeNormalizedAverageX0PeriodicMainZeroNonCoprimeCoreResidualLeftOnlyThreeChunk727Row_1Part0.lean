import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk727Term_1_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk727Term_1_1597

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4791_1597_X1000000_rowChunk_1_0 : Finset ℕ :=
  ([1, 1597] : List ℕ).toFinset

def periodicMainPair_4791_1597_X1000000_rowPartValue_1_0 : ℕ → ℚ
| 1 => (-5554304 : ℚ) / 2778889
| 1597 => (-8864669184 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4791_1597_X1000000_rowPart_1_0 :
    (∑ h ∈ periodicMainPair_4791_1597_X1000000_rowChunk_1_0,
      ramanujanGcdClassCoeffRat 4791 1 * ramanujanGcdClassCoeffRat 1597 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4791 1597) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4791 1597 1 h
                - ramanujanGcdClassWindowAverageRat X0 1597 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 4791 1
                - ramanujanGcdClassWindowAverageRat X0 4791 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 1597 h
                + ramanujanGcdClassWindowAverageRat X0 4791 1
                    * ramanujanGcdClassWindowAverageRat X0 1597 h
                    * evenRamanujanBlockCountRat 4791 1597))
    ) = (-8870223488 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4791_1597_X1000000_rowChunk_1_0,
        ramanujanGcdClassCoeffRat 4791 1 * ramanujanGcdClassCoeffRat 1597 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4791 1597) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4791 1597 1 h
                  - ramanujanGcdClassWindowAverageRat X0 1597 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 4791 1
                  - ramanujanGcdClassWindowAverageRat X0 4791 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4791 1597 1597 h
                  + ramanujanGcdClassWindowAverageRat X0 4791 1
                      * ramanujanGcdClassWindowAverageRat X0 1597 h
                      * evenRamanujanBlockCountRat 4791 1597))
      ) = (∑ h ∈ periodicMainPair_4791_1597_X1000000_rowChunk_1_0, periodicMainPair_4791_1597_X1000000_rowPartValue_1_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4791_1597_X1000000_rowChunk_1_0] at hh
    rcases hh with rfl | rfl
    · simpa [periodicMainPair_4791_1597_X1000000_rowPartValue_1_0] using periodicMainPair_4791_1597_X1000000_term_1_1
    · simpa [periodicMainPair_4791_1597_X1000000_rowPartValue_1_0] using periodicMainPair_4791_1597_X1000000_term_1_1597
  rw [hsum]
  norm_num [periodicMainPair_4791_1597_X1000000_rowChunk_1_0, periodicMainPair_4791_1597_X1000000_rowPartValue_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
