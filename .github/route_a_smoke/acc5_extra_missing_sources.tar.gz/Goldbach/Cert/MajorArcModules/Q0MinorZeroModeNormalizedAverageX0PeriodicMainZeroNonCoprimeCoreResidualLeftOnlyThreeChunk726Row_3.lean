import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk726Row_3Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_1594_X1000000_divRight_for_row_3 : Nat.divisors 1594 = ([1, 2, 797, 1594] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4782_1594_X1000000_row_3 :
    (∑ h ∈ Nat.divisors 1594,
      ramanujanGcdClassCoeffRat 4782 3 * ramanujanGcdClassCoeffRat 1594 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 1594) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 1594 3 h
                - ramanujanGcdClassWindowAverageRat X0 1594 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 4782 3
                - ramanujanGcdClassWindowAverageRat X0 4782 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 1594 1594 h
                + ramanujanGcdClassWindowAverageRat X0 4782 3
                    * ramanujanGcdClassWindowAverageRat X0 1594 h
                    * evenRamanujanBlockCountRat 4782 1594))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_4782_1594_X1000000_divRight_for_row_3]
  have hset : ([1, 2, 797, 1594] : List ℕ).toFinset = periodicMainPair_4782_1594_X1000000_rowChunk_3_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4782_1594_X1000000_rowPart_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
