import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_1582_X1000000_term_2_1582 :
    ramanujanGcdClassCoeffRat 4746 2 * ramanujanGcdClassCoeffRat 1582 1582
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 2 1582
              - ramanujanGcdClassWindowAverageRat X0 1582 1582
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 2
              - ramanujanGcdClassWindowAverageRat X0 4746 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 1582
              + ramanujanGcdClassWindowAverageRat X0 4746 2
                  * ramanujanGcdClassWindowAverageRat X0 1582 1582
                  * evenRamanujanBlockCountRat 4746 1582))
      = (6345851904 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
