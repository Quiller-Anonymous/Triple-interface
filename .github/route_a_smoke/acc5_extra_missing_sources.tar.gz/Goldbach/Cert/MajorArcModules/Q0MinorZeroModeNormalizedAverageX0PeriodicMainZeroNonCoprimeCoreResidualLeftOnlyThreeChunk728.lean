import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk728Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk728Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk728Row_1601
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk728Row_4803

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 728. -/

theorem periodicMainPair_4803_1601_X1000000_divLeft : Nat.divisors 4803 = ([1, 3, 1601, 4803] : List ℕ).toFinset := by
  decide

def periodicMainPair_4803_1601_X1000000_rowValue : ℕ → ℚ
| 1 => (-8892453512 : ℚ) / 2778889
| 3 => (8892453512 : ℚ) / 2778889
| 1601 => (-14227925619200 : ℚ) / 2778889
| 4803 => (14227925619200 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4803_1601_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 4803 1601 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 4803, ∑ h ∈ Nat.divisors 1601,
        ramanujanGcdClassCoeffRat 4803 g * ramanujanGcdClassCoeffRat 1601 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4803 1601) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4803 1601 g h
                  - ramanujanGcdClassWindowAverageRat X0 1601 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 4803 g
                  - ramanujanGcdClassWindowAverageRat X0 4803 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4803 1601 1601 h
                  + ramanujanGcdClassWindowAverageRat X0 4803 g
                      * ramanujanGcdClassWindowAverageRat X0 1601 h
                      * evenRamanujanBlockCountRat 4803 1601))
      ) = (∑ g ∈ Nat.divisors 4803, periodicMainPair_4803_1601_X1000000_rowValue g) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_4803_1601_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4803_1601_X1000000_rowValue] using periodicMainPair_4803_1601_X1000000_row_1
    · simpa [periodicMainPair_4803_1601_X1000000_rowValue] using periodicMainPair_4803_1601_X1000000_row_3
    · simpa [periodicMainPair_4803_1601_X1000000_rowValue] using periodicMainPair_4803_1601_X1000000_row_1601
    · simpa [periodicMainPair_4803_1601_X1000000_rowValue] using periodicMainPair_4803_1601_X1000000_row_4803
  rw [hsum, periodicMainPair_4803_1601_X1000000_divLeft]
  norm_num [periodicMainPair_4803_1601_X1000000_rowValue]

theorem periodicMainPair_4803_1601_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 4803 1601) = (0 : ℚ) / 1 := by
  have hneq : 4803 ≠ 1601 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 4803 = (1 : ℚ) / 2048000 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 1601 = (1 : ℚ) / 512000 := by
    native_decide
  have hvalue : ((1 : ℚ) / 2048000) * ((1 : ℚ) / 512000) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_4803_1601_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsCoreLeftOnlyThreeChunk728Pairs : Finset (ℕ × ℕ) :=
  [(4803, 1601)].toFinset

theorem PeriodicMainRecordsCoreLeftOnlyThreeChunk728_value_on_records :
    ∀ p ∈ PeriodicMainRecordsCoreLeftOnlyThreeChunk728Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsCoreLeftOnlyThreeChunk728Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_4803_1601_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
