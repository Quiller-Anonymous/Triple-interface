import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Row_3Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4827_1609_X1000000_divRight_for_row_3 : Nat.divisors 1609 = ([1, 1609] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4827_1609_X1000000_row_3 :
    (∑ h ∈ Nat.divisors 1609,
      ramanujanGcdClassCoeffRat 4827 3 * ramanujanGcdClassCoeffRat 1609 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 3 h
                - ramanujanGcdClassWindowAverageRat X0 1609 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 3
                - ramanujanGcdClassWindowAverageRat X0 4827 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 h
                + ramanujanGcdClassWindowAverageRat X0 4827 3
                    * ramanujanGcdClassWindowAverageRat X0 1609 h
                    * evenRamanujanBlockCountRat 4827 1609))
    ) = (8936913752 : ℚ) / 2778889 := by
  rw [periodicMainPair_4827_1609_X1000000_divRight_for_row_3]
  have hset : ([1, 1609] : List ℕ).toFinset = periodicMainPair_4827_1609_X1000000_rowChunk_3_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4827_1609_X1000000_rowPart_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
