import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Term_4827_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Term_4827_1609

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4827_1609_X1000000_rowChunk_4827_0 : Finset ℕ :=
  ([1, 1609] : List ℕ).toFinset

def periodicMainPair_4827_1609_X1000000_rowPartValue_4827_0 : ℕ → ℚ
| 1 => (8931359424 : ℚ) / 2778889
| 1609 => (14361625953792 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4827_1609_X1000000_rowPart_4827_0 :
    (∑ h ∈ periodicMainPair_4827_1609_X1000000_rowChunk_4827_0,
      ramanujanGcdClassCoeffRat 4827 4827 * ramanujanGcdClassCoeffRat 1609 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 4827 h
                - ramanujanGcdClassWindowAverageRat X0 1609 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 4827
                - ramanujanGcdClassWindowAverageRat X0 4827 4827
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 h
                + ramanujanGcdClassWindowAverageRat X0 4827 4827
                    * ramanujanGcdClassWindowAverageRat X0 1609 h
                    * evenRamanujanBlockCountRat 4827 1609))
    ) = (14370557313216 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4827_1609_X1000000_rowChunk_4827_0,
        ramanujanGcdClassCoeffRat 4827 4827 * ramanujanGcdClassCoeffRat 1609 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 4827 h
                  - ramanujanGcdClassWindowAverageRat X0 1609 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 4827
                  - ramanujanGcdClassWindowAverageRat X0 4827 4827
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 h
                  + ramanujanGcdClassWindowAverageRat X0 4827 4827
                      * ramanujanGcdClassWindowAverageRat X0 1609 h
                      * evenRamanujanBlockCountRat 4827 1609))
      ) = (∑ h ∈ periodicMainPair_4827_1609_X1000000_rowChunk_4827_0, periodicMainPair_4827_1609_X1000000_rowPartValue_4827_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4827_1609_X1000000_rowChunk_4827_0] at hh
    rcases hh with rfl | rfl
    · simpa [periodicMainPair_4827_1609_X1000000_rowPartValue_4827_0] using periodicMainPair_4827_1609_X1000000_term_4827_1
    · simpa [periodicMainPair_4827_1609_X1000000_rowPartValue_4827_0] using periodicMainPair_4827_1609_X1000000_term_4827_1609
  rw [hsum]
  norm_num [periodicMainPair_4827_1609_X1000000_rowChunk_4827_0, periodicMainPair_4827_1609_X1000000_rowPartValue_4827_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
