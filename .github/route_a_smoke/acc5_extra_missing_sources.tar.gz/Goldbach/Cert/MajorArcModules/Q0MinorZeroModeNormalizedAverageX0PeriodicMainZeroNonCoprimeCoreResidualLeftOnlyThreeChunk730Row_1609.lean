import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk730Row_1609Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4827_1609_X1000000_divRight_for_row_1609 : Nat.divisors 1609 = ([1, 1609] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4827_1609_X1000000_row_1609 :
    (∑ h ∈ Nat.divisors 1609,
      ramanujanGcdClassCoeffRat 4827 1609 * ramanujanGcdClassCoeffRat 1609 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 1609 h
                - ramanujanGcdClassWindowAverageRat X0 1609 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 1609
                - ramanujanGcdClassWindowAverageRat X0 4827 1609
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 h
                + ramanujanGcdClassWindowAverageRat X0 4827 1609
                    * ramanujanGcdClassWindowAverageRat X0 1609 h
                    * evenRamanujanBlockCountRat 4827 1609))
    ) = (-14370557313216 : ℚ) / 2778889 := by
  rw [periodicMainPair_4827_1609_X1000000_divRight_for_row_1609]
  have hset : ([1, 1609] : List ℕ).toFinset = periodicMainPair_4827_1609_X1000000_rowChunk_1609_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4827_1609_X1000000_rowPart_1609_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
