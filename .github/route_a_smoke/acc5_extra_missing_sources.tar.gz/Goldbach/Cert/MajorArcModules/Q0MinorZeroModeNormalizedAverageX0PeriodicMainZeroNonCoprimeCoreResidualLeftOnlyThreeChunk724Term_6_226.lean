import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_1582_X1000000_term_6_226 :
    ramanujanGcdClassCoeffRat 4746 6 * ramanujanGcdClassCoeffRat 1582 226
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 6 226
              - ramanujanGcdClassWindowAverageRat X0 1582 226
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 6
              - ramanujanGcdClassWindowAverageRat X0 4746 6
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 226
              + ramanujanGcdClassWindowAverageRat X0 4746 6
                  * ramanujanGcdClassWindowAverageRat X0 1582 226
                  * evenRamanujanBlockCountRat 4746 1582))
      = (6345927168 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
