import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_6
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_7
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_14
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_21
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_42
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_113
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_226
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_339
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_678
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_791
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_1582
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_2373
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_4746

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 723. -/

theorem periodicMainPair_4746_791_X1000000_divLeft : Nat.divisors 4746 = ([1, 2, 3, 6, 7, 14, 21, 42, 113, 226, 339, 678, 791, 1582, 2373, 4746] : List ℕ).toFinset := by
  decide

def periodicMainPair_4746_791_X1000000_rowValue : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (-7469728896 : ℚ) / 2778889
| 3 => (0 : ℚ) / 1
| 6 => (7469728896 : ℚ) / 2778889
| 7 => (0 : ℚ) / 1
| 14 => (-44817846528 : ℚ) / 2778889
| 21 => (0 : ℚ) / 1
| 42 => (44817846528 : ℚ) / 2778889
| 113 => (0 : ℚ) / 1
| 226 => (-836615306240 : ℚ) / 2778889
| 339 => (0 : ℚ) / 1
| 678 => (836615306240 : ℚ) / 2778889
| 791 => (0 : ℚ) / 1
| 1582 => (-5019632830464 : ℚ) / 2778889
| 2373 => (0 : ℚ) / 1
| 4746 => (5019632830464 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4746_791_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 4746 791 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 4746, ∑ h ∈ Nat.divisors 791,
        ramanujanGcdClassCoeffRat 4746 g * ramanujanGcdClassCoeffRat 791 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 g h
                  - ramanujanGcdClassWindowAverageRat X0 791 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 g
                  - ramanujanGcdClassWindowAverageRat X0 4746 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 h
                  + ramanujanGcdClassWindowAverageRat X0 4746 g
                      * ramanujanGcdClassWindowAverageRat X0 791 h
                      * evenRamanujanBlockCountRat 4746 791))
      ) = (∑ g ∈ Nat.divisors 4746, periodicMainPair_4746_791_X1000000_rowValue g) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_4746_791_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_1
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_2
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_3
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_6
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_7
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_14
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_21
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_42
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_113
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_226
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_339
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_678
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_791
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_1582
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_2373
    · simpa [periodicMainPair_4746_791_X1000000_rowValue] using periodicMainPair_4746_791_X1000000_row_4746
  rw [hsum, periodicMainPair_4746_791_X1000000_divLeft]
  norm_num [periodicMainPair_4746_791_X1000000_rowValue]

theorem periodicMainPair_4746_791_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 4746 791) = (0 : ℚ) / 1 := by
  have hneq : 4746 ≠ 791 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 4746 = (5 : ℚ) / 1806336 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 791 = (5 : ℚ) / 451584 := by
    native_decide
  have hvalue : ((5 : ℚ) / 1806336) * ((5 : ℚ) / 451584) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_4746_791_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsCoreLeftOnlyThreeChunk723Pairs : Finset (ℕ × ℕ) :=
  [(4746, 791)].toFinset

theorem PeriodicMainRecordsCoreLeftOnlyThreeChunk723_value_on_records :
    ∀ p ∈ PeriodicMainRecordsCoreLeftOnlyThreeChunk723Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsCoreLeftOnlyThreeChunk723Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_4746_791_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
