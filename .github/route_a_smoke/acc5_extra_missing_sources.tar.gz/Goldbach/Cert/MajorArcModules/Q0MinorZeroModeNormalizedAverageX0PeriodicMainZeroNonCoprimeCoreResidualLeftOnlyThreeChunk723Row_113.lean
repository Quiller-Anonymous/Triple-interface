import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Row_113Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_791_X1000000_divRight_for_row_113 : Nat.divisors 791 = ([1, 7, 113, 791] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_4746_791_X1000000_row_113 :
    (∑ h ∈ Nat.divisors 791,
      ramanujanGcdClassCoeffRat 4746 113 * ramanujanGcdClassCoeffRat 791 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 113 h
                - ramanujanGcdClassWindowAverageRat X0 791 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 113
                - ramanujanGcdClassWindowAverageRat X0 4746 113
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 h
                + ramanujanGcdClassWindowAverageRat X0 4746 113
                    * ramanujanGcdClassWindowAverageRat X0 791 h
                    * evenRamanujanBlockCountRat 4746 791))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_4746_791_X1000000_divRight_for_row_113]
  have hset : ([1, 7, 113, 791] : List ℕ).toFinset = periodicMainPair_4746_791_X1000000_rowChunk_113_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_4746_791_X1000000_rowPart_113_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
