import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Term_1582_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Term_1582_7
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Term_1582_113
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk723Term_1582_791

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4746_791_X1000000_rowChunk_1582_0 : Finset ℕ :=
  ([1, 7, 113, 791] : List ℕ).toFinset

def periodicMainPair_4746_791_X1000000_rowPartValue_1582_0 : ℕ → ℚ
| 1 => (6345851904 : ℚ) / 2778889
| 7 => (-6345851904 : ℚ) / 2778889
| 113 => (-6354991104 : ℚ) / 2778889
| 791 => (-5013277839360 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4746_791_X1000000_rowPart_1582_0 :
    (∑ h ∈ periodicMainPair_4746_791_X1000000_rowChunk_1582_0,
      ramanujanGcdClassCoeffRat 4746 1582 * ramanujanGcdClassCoeffRat 791 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 1582 h
                - ramanujanGcdClassWindowAverageRat X0 791 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 1582
                - ramanujanGcdClassWindowAverageRat X0 4746 1582
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 h
                + ramanujanGcdClassWindowAverageRat X0 4746 1582
                    * ramanujanGcdClassWindowAverageRat X0 791 h
                    * evenRamanujanBlockCountRat 4746 791))
    ) = (-5019632830464 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4746_791_X1000000_rowChunk_1582_0,
        ramanujanGcdClassCoeffRat 4746 1582 * ramanujanGcdClassCoeffRat 791 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 791) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 791 1582 h
                  - ramanujanGcdClassWindowAverageRat X0 791 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 4746 1582
                  - ramanujanGcdClassWindowAverageRat X0 4746 1582
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 791 791 h
                  + ramanujanGcdClassWindowAverageRat X0 4746 1582
                      * ramanujanGcdClassWindowAverageRat X0 791 h
                      * evenRamanujanBlockCountRat 4746 791))
      ) = (∑ h ∈ periodicMainPair_4746_791_X1000000_rowChunk_1582_0, periodicMainPair_4746_791_X1000000_rowPartValue_1582_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4746_791_X1000000_rowChunk_1582_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4746_791_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_791_X1000000_term_1582_1
    · simpa [periodicMainPair_4746_791_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_791_X1000000_term_1582_7
    · simpa [periodicMainPair_4746_791_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_791_X1000000_term_1582_113
    · simpa [periodicMainPair_4746_791_X1000000_rowPartValue_1582_0] using periodicMainPair_4746_791_X1000000_term_1582_791
  rw [hsum]
  norm_num [periodicMainPair_4746_791_X1000000_rowChunk_1582_0, periodicMainPair_4746_791_X1000000_rowPartValue_1582_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
