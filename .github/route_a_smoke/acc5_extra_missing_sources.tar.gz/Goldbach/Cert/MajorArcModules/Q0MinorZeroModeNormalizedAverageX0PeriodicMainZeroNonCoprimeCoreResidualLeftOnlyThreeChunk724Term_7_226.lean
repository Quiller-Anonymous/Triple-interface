import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4746_1582_X1000000_term_7_226 :
    ramanujanGcdClassCoeffRat 4746 7 * ramanujanGcdClassCoeffRat 1582 226
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 7 226
              - ramanujanGcdClassWindowAverageRat X0 1582 226
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 7
              - ramanujanGcdClassWindowAverageRat X0 4746 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 226
              + ramanujanGcdClassWindowAverageRat X0 4746 7
                  * ramanujanGcdClassWindowAverageRat X0 1582 226
                  * evenRamanujanBlockCountRat 4746 1582))
      = (0 : ℚ) / 1 := by
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 4746 7 = (0 : ℚ) / 1 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 7 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 7 226 = (0 : ℚ) := by
    have hcompat : ¬ ramanujanGcdClassJointCompatibility 4746 1582 7 226 := by
      native_decide
    unfold rawEvenRamanujanGcdClassPairBlockResolvedCountRat
    simp [hcompat]
  rw [hPair, hAvgLeft, hBlockLeft]
  simp

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
