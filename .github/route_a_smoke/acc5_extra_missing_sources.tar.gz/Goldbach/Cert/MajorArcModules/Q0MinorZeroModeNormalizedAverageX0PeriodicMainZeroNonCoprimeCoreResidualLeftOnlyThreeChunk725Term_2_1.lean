import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4782_797_X1000000_term_2_1 :
    ramanujanGcdClassCoeffRat 4782 2 * ramanujanGcdClassCoeffRat 797 1
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 2 1
              - ramanujanGcdClassWindowAverageRat X0 797 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 2
              - ramanujanGcdClassWindowAverageRat X0 4782 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 1
              + ramanujanGcdClassWindowAverageRat X0 4782 2
                  * ramanujanGcdClassWindowAverageRat X0 797 1
                  * evenRamanujanBlockCountRat 4782 797))
      = (-11101636 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
