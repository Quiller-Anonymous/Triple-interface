import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk729Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk729Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk729Row_1607
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk729Row_4821

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 729. -/

theorem periodicMainPair_4821_1607_X1000000_divLeft : Nat.divisors 4821 = ([1, 3, 1607, 4821] : List ℕ).toFinset := by
  decide

def periodicMainPair_4821_1607_X1000000_rowValue : ℕ → ℚ
| 1 => (-8925798668 : ℚ) / 2778889
| 3 => (8925798668 : ℚ) / 2778889
| 1607 => (-14334832660808 : ℚ) / 2778889
| 4821 => (14334832660808 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4821_1607_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 4821 1607 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 4821, ∑ h ∈ Nat.divisors 1607,
        ramanujanGcdClassCoeffRat 4821 g * ramanujanGcdClassCoeffRat 1607 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4821 1607) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4821 1607 g h
                  - ramanujanGcdClassWindowAverageRat X0 1607 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 4821 g
                  - ramanujanGcdClassWindowAverageRat X0 4821 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 1607 h
                  + ramanujanGcdClassWindowAverageRat X0 4821 g
                      * ramanujanGcdClassWindowAverageRat X0 1607 h
                      * evenRamanujanBlockCountRat 4821 1607))
      ) = (∑ g ∈ Nat.divisors 4821, periodicMainPair_4821_1607_X1000000_rowValue g) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_4821_1607_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4821_1607_X1000000_rowValue] using periodicMainPair_4821_1607_X1000000_row_1
    · simpa [periodicMainPair_4821_1607_X1000000_rowValue] using periodicMainPair_4821_1607_X1000000_row_3
    · simpa [periodicMainPair_4821_1607_X1000000_rowValue] using periodicMainPair_4821_1607_X1000000_row_1607
    · simpa [periodicMainPair_4821_1607_X1000000_rowValue] using periodicMainPair_4821_1607_X1000000_row_4821
  rw [hsum, periodicMainPair_4821_1607_X1000000_divLeft]
  norm_num [periodicMainPair_4821_1607_X1000000_rowValue]

theorem periodicMainPair_4821_1607_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 4821 1607) = (0 : ℚ) / 1 := by
  have hneq : 4821 ≠ 1607 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 4821 = (5 : ℚ) / 10316944 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 1607 = (5 : ℚ) / 2579236 := by
    native_decide
  have hvalue : ((5 : ℚ) / 10316944) * ((5 : ℚ) / 2579236) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_4821_1607_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsCoreLeftOnlyThreeChunk729Pairs : Finset (ℕ × ℕ) :=
  [(4821, 1607)].toFinset

theorem PeriodicMainRecordsCoreLeftOnlyThreeChunk729_value_on_records :
    ∀ p ∈ PeriodicMainRecordsCoreLeftOnlyThreeChunk729Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsCoreLeftOnlyThreeChunk729Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_4821_1607_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
