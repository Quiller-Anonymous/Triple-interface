import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk729Term_4821_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk729Term_4821_1607

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4821_1607_X1000000_rowChunk_4821_0 : Finset ℕ :=
  ([1, 1607] : List ℕ).toFinset

def periodicMainPair_4821_1607_X1000000_rowPartValue_4821_0 : ℕ → ℚ
| 1 => (8920244344 : ℚ) / 2778889
| 1607 => (14325912416464 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4821_1607_X1000000_rowPart_4821_0 :
    (∑ h ∈ periodicMainPair_4821_1607_X1000000_rowChunk_4821_0,
      ramanujanGcdClassCoeffRat 4821 4821 * ramanujanGcdClassCoeffRat 1607 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4821 1607) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4821 1607 4821 h
                - ramanujanGcdClassWindowAverageRat X0 1607 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 4821 4821
                - ramanujanGcdClassWindowAverageRat X0 4821 4821
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 1607 h
                + ramanujanGcdClassWindowAverageRat X0 4821 4821
                    * ramanujanGcdClassWindowAverageRat X0 1607 h
                    * evenRamanujanBlockCountRat 4821 1607))
    ) = (14334832660808 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4821_1607_X1000000_rowChunk_4821_0,
        ramanujanGcdClassCoeffRat 4821 4821 * ramanujanGcdClassCoeffRat 1607 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4821 1607) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4821 1607 4821 h
                  - ramanujanGcdClassWindowAverageRat X0 1607 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 4821 4821
                  - ramanujanGcdClassWindowAverageRat X0 4821 4821
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4821 1607 1607 h
                  + ramanujanGcdClassWindowAverageRat X0 4821 4821
                      * ramanujanGcdClassWindowAverageRat X0 1607 h
                      * evenRamanujanBlockCountRat 4821 1607))
      ) = (∑ h ∈ periodicMainPair_4821_1607_X1000000_rowChunk_4821_0, periodicMainPair_4821_1607_X1000000_rowPartValue_4821_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4821_1607_X1000000_rowChunk_4821_0] at hh
    rcases hh with rfl | rfl
    · simpa [periodicMainPair_4821_1607_X1000000_rowPartValue_4821_0] using periodicMainPair_4821_1607_X1000000_term_4821_1
    · simpa [periodicMainPair_4821_1607_X1000000_rowPartValue_4821_0] using periodicMainPair_4821_1607_X1000000_term_4821_1607
  rw [hsum]
  norm_num [periodicMainPair_4821_1607_X1000000_rowChunk_4821_0, periodicMainPair_4821_1607_X1000000_rowPartValue_4821_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
