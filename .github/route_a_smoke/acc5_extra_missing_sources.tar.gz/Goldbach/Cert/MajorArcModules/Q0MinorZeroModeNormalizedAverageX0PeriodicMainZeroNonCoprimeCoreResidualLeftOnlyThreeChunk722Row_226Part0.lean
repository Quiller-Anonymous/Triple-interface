import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_226_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_226_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_226_113
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk722Term_226_226

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4746_226_X1000000_rowChunk_226_0 : Finset ℕ :=
  ([1, 2, 113, 226] : List ℕ).toFinset

def periodicMainPair_4746_226_X1000000_rowPartValue_226_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (7403581696 : ℚ) / 2778889
| 113 => (0 : ℚ) / 1
| 226 => (829201149952 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4746_226_X1000000_rowPart_226_0 :
    (∑ h ∈ periodicMainPair_4746_226_X1000000_rowChunk_226_0,
      ramanujanGcdClassCoeffRat 4746 226 * ramanujanGcdClassCoeffRat 226 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 226 h
                - ramanujanGcdClassWindowAverageRat X0 226 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 226
                - ramanujanGcdClassWindowAverageRat X0 4746 226
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 h
                + ramanujanGcdClassWindowAverageRat X0 4746 226
                    * ramanujanGcdClassWindowAverageRat X0 226 h
                    * evenRamanujanBlockCountRat 4746 226))
    ) = (836604731648 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4746_226_X1000000_rowChunk_226_0,
        ramanujanGcdClassCoeffRat 4746 226 * ramanujanGcdClassCoeffRat 226 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 226) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 226 226 h
                  - ramanujanGcdClassWindowAverageRat X0 226 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 4746 226
                  - ramanujanGcdClassWindowAverageRat X0 4746 226
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 226 226 h
                  + ramanujanGcdClassWindowAverageRat X0 4746 226
                      * ramanujanGcdClassWindowAverageRat X0 226 h
                      * evenRamanujanBlockCountRat 4746 226))
      ) = (∑ h ∈ periodicMainPair_4746_226_X1000000_rowChunk_226_0, periodicMainPair_4746_226_X1000000_rowPartValue_226_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4746_226_X1000000_rowChunk_226_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_226_0] using periodicMainPair_4746_226_X1000000_term_226_1
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_226_0] using periodicMainPair_4746_226_X1000000_term_226_2
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_226_0] using periodicMainPair_4746_226_X1000000_term_226_113
    · simpa [periodicMainPair_4746_226_X1000000_rowPartValue_226_0] using periodicMainPair_4746_226_X1000000_term_226_226
  rw [hsum]
  norm_num [periodicMainPair_4746_226_X1000000_rowChunk_226_0, periodicMainPair_4746_226_X1000000_rowPartValue_226_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
