import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_6
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_797
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_1594
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_2391
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk725Row_4782

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 725. -/

theorem periodicMainPair_4782_797_X1000000_divLeft : Nat.divisors 4782 = ([1, 2, 3, 6, 797, 1594, 2391, 4782] : List ℕ).toFinset := by
  decide

def periodicMainPair_4782_797_X1000000_rowValue : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (-8848003892 : ℚ) / 2778889
| 3 => (0 : ℚ) / 1
| 6 => (8848003892 : ℚ) / 2778889
| 797 => (0 : ℚ) / 1
| 1594 => (-7043011098032 : ℚ) / 2778889
| 2391 => (0 : ℚ) / 1
| 4782 => (7043011098032 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_4782_797_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 4782 797 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 4782, ∑ h ∈ Nat.divisors 797,
        ramanujanGcdClassCoeffRat 4782 g * ramanujanGcdClassCoeffRat 797 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4782 797) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4782 797 g h
                  - ramanujanGcdClassWindowAverageRat X0 797 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 4782 g
                  - ramanujanGcdClassWindowAverageRat X0 4782 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4782 797 797 h
                  + ramanujanGcdClassWindowAverageRat X0 4782 g
                      * ramanujanGcdClassWindowAverageRat X0 797 h
                      * evenRamanujanBlockCountRat 4782 797))
      ) = (∑ g ∈ Nat.divisors 4782, periodicMainPair_4782_797_X1000000_rowValue g) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_4782_797_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_1
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_2
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_3
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_6
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_797
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_1594
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_2391
    · simpa [periodicMainPair_4782_797_X1000000_rowValue] using periodicMainPair_4782_797_X1000000_row_4782
  rw [hsum, periodicMainPair_4782_797_X1000000_divLeft]
  norm_num [periodicMainPair_4782_797_X1000000_rowValue]

theorem periodicMainPair_4782_797_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 4782 797) = (0 : ℚ) / 1 := by
  have hneq : 4782 ≠ 797 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 4782 = (5 : ℚ) / 2534464 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 797 = (5 : ℚ) / 633616 := by
    native_decide
  have hvalue : ((5 : ℚ) / 2534464) * ((5 : ℚ) / 633616) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_4782_797_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsCoreLeftOnlyThreeChunk725Pairs : Finset (ℕ × ℕ) :=
  [(4782, 797)].toFinset

theorem PeriodicMainRecordsCoreLeftOnlyThreeChunk725_value_on_records :
    ∀ p ∈ PeriodicMainRecordsCoreLeftOnlyThreeChunk725Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsCoreLeftOnlyThreeChunk725Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_4782_797_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
