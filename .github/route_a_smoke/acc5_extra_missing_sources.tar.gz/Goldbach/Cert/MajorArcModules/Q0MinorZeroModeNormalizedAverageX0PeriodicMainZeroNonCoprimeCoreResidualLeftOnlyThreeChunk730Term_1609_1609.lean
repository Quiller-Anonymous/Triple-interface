import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_4827_1609_X1000000_term_1609_1609 :
    ramanujanGcdClassCoeffRat 4827 1609 * ramanujanGcdClassCoeffRat 1609 1609
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 4827 1609) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4827 1609 1609 1609
              - ramanujanGcdClassWindowAverageRat X0 1609 1609
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 4827 1609
              - ramanujanGcdClassWindowAverageRat X0 4827 1609
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4827 1609 1609 1609
              + ramanujanGcdClassWindowAverageRat X0 4827 1609
                  * ramanujanGcdClassWindowAverageRat X0 1609 1609
                  * evenRamanujanBlockCountRat 4827 1609))
      = (-14361625953792 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
