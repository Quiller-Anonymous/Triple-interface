import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_7
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_14
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_113
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_226
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_791
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk724Term_339_1582

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_4746_1582_X1000000_rowChunk_339_0 : Finset ℕ :=
  ([1, 2, 7, 14, 113, 226, 791, 1582] : List ℕ).toFinset

def periodicMainPair_4746_1582_X1000000_rowPartValue_339_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 7 => (0 : ℚ) / 1
| 14 => (0 : ℚ) / 1
| 113 => (0 : ℚ) / 1
| 226 => (0 : ℚ) / 1
| 791 => (0 : ℚ) / 1
| 1582 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_4746_1582_X1000000_rowPart_339_0 :
    (∑ h ∈ periodicMainPair_4746_1582_X1000000_rowChunk_339_0,
      ramanujanGcdClassCoeffRat 4746 339 * ramanujanGcdClassCoeffRat 1582 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 339 h
                - ramanujanGcdClassWindowAverageRat X0 1582 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 339
                - ramanujanGcdClassWindowAverageRat X0 4746 339
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 h
                + ramanujanGcdClassWindowAverageRat X0 4746 339
                    * ramanujanGcdClassWindowAverageRat X0 1582 h
                    * evenRamanujanBlockCountRat 4746 1582))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_4746_1582_X1000000_rowChunk_339_0,
        ramanujanGcdClassCoeffRat 4746 339 * ramanujanGcdClassCoeffRat 1582 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 4746 1582) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 4746 1582 339 h
                  - ramanujanGcdClassWindowAverageRat X0 1582 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 4746 339
                  - ramanujanGcdClassWindowAverageRat X0 4746 339
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 4746 1582 1582 h
                  + ramanujanGcdClassWindowAverageRat X0 4746 339
                      * ramanujanGcdClassWindowAverageRat X0 1582 h
                      * evenRamanujanBlockCountRat 4746 1582))
      ) = (∑ h ∈ periodicMainPair_4746_1582_X1000000_rowChunk_339_0, periodicMainPair_4746_1582_X1000000_rowPartValue_339_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_4746_1582_X1000000_rowChunk_339_0] at hh
    rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_1
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_2
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_7
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_14
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_113
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_226
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_791
    · simpa [periodicMainPair_4746_1582_X1000000_rowPartValue_339_0] using periodicMainPair_4746_1582_X1000000_term_339_1582
  rw [hsum]
  norm_num [periodicMainPair_4746_1582_X1000000_rowChunk_339_0, periodicMainPair_4746_1582_X1000000_rowPartValue_339_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
