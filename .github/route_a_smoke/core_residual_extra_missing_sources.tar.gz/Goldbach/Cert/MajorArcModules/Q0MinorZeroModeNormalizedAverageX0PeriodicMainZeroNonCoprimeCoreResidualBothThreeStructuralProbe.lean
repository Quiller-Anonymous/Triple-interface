import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.unusedSimpArgs false
set_option linter.unnecessarySimpa false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/-!
Diagnostic surface for the `bothThree` non-coprime residual bucket.

The first target is the sample pair `(15, 21) = (3 * 5, 3 * 7)`.  These
computable rational shadows separate the centering issue from the generated
gcd-row certificate: the raw full-block pair and one-variable block sums vanish,
and one of the two window averages vanishes, so the centered full-block
expression vanishes.
-/

def ramanujanZRat (q N : ℕ) : ℚ :=
  (Goldbach.AO_OffDiag.TailBlock.ramanujanZ q N : ℚ)

def ramanujanWindowAverageByGcdRat (X q : ℕ) : ℚ :=
  ∑ g ∈ q.divisors,
    ramanujanGcdClassCoeffRat q g * ramanujanGcdClassWindowAverageRat X q g

def rawEvenRamanujanBlockSumRat (X q q' q0 : ℕ) : ℚ :=
  ∑ k ∈ Finset.range (centeredRamanujanPairBlockPeriod q q'),
    if Goldbach.Windows.IsEven (X + k) then
      ramanujanZRat q0 (X + k)
    else
      0

def rawEvenRamanujanPairBlockSumRat (X q q' : ℕ) : ℚ :=
  ∑ k ∈ Finset.range (centeredRamanujanPairBlockPeriod q q'),
    if Goldbach.Windows.IsEven (X + k) then
      ramanujanZRat q (X + k) * ramanujanZRat q' (X + k)
    else
      0

def centeredRamanujanPairFullEvenBlockSumFromRawRat (X q q' : ℕ) : ℚ :=
  rawEvenRamanujanPairBlockSumRat X q q'
    - ramanujanWindowAverageByGcdRat X q'
        * rawEvenRamanujanBlockSumRat X q q' q
    - ramanujanWindowAverageByGcdRat X q
        * rawEvenRamanujanBlockSumRat X q q' q'
    + ramanujanWindowAverageByGcdRat X q
        * ramanujanWindowAverageByGcdRat X q'
        * evenRamanujanBlockCountRat q q'

theorem ramanujanR_eq_ratCast_ramanujanZRat (q N : ℕ) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR q N
      = (ramanujanZRat q N : ℝ) := by
  simp [ramanujanZRat, Goldbach.AO_OffDiag.TailBlock.ramanujanR]

theorem rawEvenRamanujanBlockSum_eq_ratCast
    (X q q' q0 : ℕ) :
    rawEvenRamanujanBlockSum X q q' q0
      = (rawEvenRamanujanBlockSumRat X q q' q0 : ℝ) := by
  unfold rawEvenRamanujanBlockSum rawEvenRamanujanBlockSumRat
  rw [Rat.cast_sum]
  refine Finset.sum_congr rfl ?_
  intro k _hk
  by_cases hEven : Goldbach.Windows.IsEven (X + k)
  · simp [hEven, ramanujanR_eq_ratCast_ramanujanZRat]
  · simp [hEven]

theorem rawEvenRamanujanPairBlockSum_eq_ratCast
    (X q q' : ℕ) :
    rawEvenRamanujanPairBlockSum X q q'
      = (rawEvenRamanujanPairBlockSumRat X q q' : ℝ) := by
  unfold rawEvenRamanujanPairBlockSum rawEvenRamanujanPairBlockSumRat
  rw [Rat.cast_sum]
  refine Finset.sum_congr rfl ?_
  intro k _hk
  by_cases hEven : Goldbach.Windows.IsEven (X + k)
  · simp [hEven, ramanujanR_eq_ratCast_ramanujanZRat]
  · simp [hEven]

theorem ramanujanWindowAverage_eq_ratCast_ramanujanWindowAverageByGcdRat
    (X q : ℕ) (hq : 1 ≤ q) :
    ramanujanWindowAverage X q
      = (ramanujanWindowAverageByGcdRat X q : ℝ) := by
  rw [ramanujanWindowAverage_eq_sum_gcdClassAverages (X := X) (q := q) hq]
  unfold ramanujanWindowAverageByGcdRat
  rw [Rat.cast_sum]
  refine Finset.sum_congr rfl ?_
  intro g _hg
  simp [ramanujanGcdClassCoeff_eq_ratCast, ramanujanGcdClassWindowAverage_eq_ratCast]

theorem centeredEvenRamanujanPairOffset_eq_sum_gcdClassOffsets_for_bothThree_probe
    {X q q' k : ℕ} (hq : 1 ≤ q) (hq' : 1 ≤ q') :
    centeredEvenRamanujanPairOffset X q q' k
      =
    ∑ g ∈ q.divisors, ∑ h ∈ q'.divisors,
      ramanujanGcdClassCoeff q g * ramanujanGcdClassCoeff q' h
        * centeredEvenRamanujanGcdClassPairOffset X q q' g h k := by
  unfold centeredEvenRamanujanPairOffset centeredRamanujanPairKernel
    centeredEvenRamanujanGcdClassPairOffset centeredRamanujanGcdClassPairKernel
  by_cases hEven : Goldbach.Windows.IsEven (X + k)
  · simp [hEven]
    rw [centeredRamanujanObservable_eq_sum_centeredGcdClasses
      (X := X) (q := q) (N := X + k) hq]
    rw [centeredRamanujanObservable_eq_sum_centeredGcdClasses
      (X := X) (q := q') (N := X + k) hq']
    calc
      (∑ g ∈ q.divisors,
          ramanujanGcdClassCoeff q g * centeredRamanujanGcdClassObservable X q g (X + k))
        * (∑ h ∈ q'.divisors,
          ramanujanGcdClassCoeff q' h * centeredRamanujanGcdClassObservable X q' h (X + k))
          =
        ∑ g ∈ q.divisors, ∑ h ∈ q'.divisors,
          (ramanujanGcdClassCoeff q g * centeredRamanujanGcdClassObservable X q g (X + k))
            * (ramanujanGcdClassCoeff q' h
                * centeredRamanujanGcdClassObservable X q' h (X + k)) := by
            rw [Finset.sum_mul]
            refine Finset.sum_congr rfl ?_
            intro g _hg
            rw [Finset.mul_sum]
      _ =
        ∑ g ∈ q.divisors, ∑ h ∈ q'.divisors,
          ramanujanGcdClassCoeff q g * ramanujanGcdClassCoeff q' h
            * (centeredRamanujanGcdClassObservable X q g (X + k)
                * centeredRamanujanGcdClassObservable X q' h (X + k)) := by
            refine Finset.sum_congr rfl ?_
            intro g _hg
            refine Finset.sum_congr rfl ?_
            intro h _hh
            ring
  · simp [hEven]

theorem centeredRamanujanPairFullEvenBlockSum_eq_sum_gcdClassFullEvenBlockSums_for_bothThree_probe
    {X q q' : ℕ} (hq : 1 ≤ q) (hq' : 1 ≤ q') :
    centeredRamanujanPairFullEvenBlockSum X q q'
      =
    ∑ g ∈ q.divisors, ∑ h ∈ q'.divisors,
      ramanujanGcdClassCoeff q g * ramanujanGcdClassCoeff q' h
        * centeredRamanujanGcdClassPairFullEvenBlockSum X q q' g h := by
  unfold centeredRamanujanPairFullEvenBlockSum centeredRamanujanGcdClassPairFullEvenBlockSum
  calc
    ∑ k ∈ Finset.range (centeredRamanujanPairBlockPeriod q q'),
        centeredEvenRamanujanPairOffset X q q' k
      =
    ∑ k ∈ Finset.range (centeredRamanujanPairBlockPeriod q q'),
      ∑ g ∈ q.divisors, ∑ h ∈ q'.divisors,
        ramanujanGcdClassCoeff q g * ramanujanGcdClassCoeff q' h
          * centeredEvenRamanujanGcdClassPairOffset X q q' g h k := by
        refine Finset.sum_congr rfl ?_
        intro k _hk
        exact centeredEvenRamanujanPairOffset_eq_sum_gcdClassOffsets_for_bothThree_probe
          hq hq'
    _ =
    ∑ g ∈ q.divisors, ∑ h ∈ q'.divisors,
      ∑ k ∈ Finset.range (centeredRamanujanPairBlockPeriod q q'),
        ramanujanGcdClassCoeff q g * ramanujanGcdClassCoeff q' h
          * centeredEvenRamanujanGcdClassPairOffset X q q' g h k := by
        rw [Finset.sum_comm]
        refine Finset.sum_congr rfl ?_
        intro g _hg
        rw [Finset.sum_comm]
    _ =
    ∑ g ∈ q.divisors, ∑ h ∈ q'.divisors,
      ramanujanGcdClassCoeff q g * ramanujanGcdClassCoeff q' h
        * ∑ k ∈ Finset.range (centeredRamanujanPairBlockPeriod q q'),
          centeredEvenRamanujanGcdClassPairOffset X q q' g h k := by
        refine Finset.sum_congr rfl ?_
        intro g _hg
        refine Finset.sum_congr rfl ?_
        intro h _hh
        rw [Finset.mul_sum]

theorem centeredRamanujanPairPeriodicMainTerm_eq_blockScalar_fullEvenBlockSum_for_bothThree_probe
    {X q q' : ℕ} (hq : 1 ≤ q) (hq' : 1 ≤ q') :
    centeredRamanujanPairPeriodicMainTerm X q q'
      =
    (((H + 1) / centeredRamanujanPairBlockPeriod q q') : ℕ)
      • centeredRamanujanPairFullEvenBlockSum X q q' := by
  rw [centeredRamanujanPairFullEvenBlockSum_eq_sum_gcdClassFullEvenBlockSums_for_bothThree_probe
    hq hq']
  unfold centeredRamanujanPairPeriodicMainTerm
  simp only [nsmul_eq_mul]
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl ?_
  intro g hg
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl ?_
  intro h hh
  rw [centeredRamanujanGcdClassPairFullEvenBlockSum_eq_resolved_periodic_comparison
    hq hq' hg hh]
  ring

theorem ramanujanR_prime_eq_neg_one_of_not_dvd_for_bothThree
    {p N : ℕ} (hp : p.Prime) (hpN : ¬ p ∣ N) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR p N = -1 := by
  have hgcd : Nat.gcd p N = 1 := (hp.coprime_iff_not_dvd).2 hpN |>.gcd_eq_one
  simp [Goldbach.AO_OffDiag.TailBlock.ramanujanR, Goldbach.AO_OffDiag.TailBlock.ramanujanZ,
    hgcd, ArithmeticFunction.moebius_apply_prime hp]

theorem ramanujanR_prime_eq_sub_one_of_dvd_for_bothThree
    {p N : ℕ} (hp : p.Prime) (hpN : p ∣ N) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR p N = (p - 1 : ℕ) := by
  have hgcd : Nat.gcd p N = p := Nat.gcd_eq_left hpN
  have hdiv : p / p = 1 := by
    exact Nat.div_eq_of_eq_mul_left hp.pos (by simp)
  rw [Goldbach.AO_OffDiag.TailBlock.ramanujanR, Goldbach.AO_OffDiag.TailBlock.ramanujanZ]
  simp [hgcd, hdiv, Nat.totient_prime hp, ArithmeticFunction.moebius_apply_one]

theorem ramanujanR_mul_prime_eq_neg_of_not_dvd_for_bothThree
    {r N p : ℕ} (hp : p.Prime) (hpN : ¬ p ∣ N) (hpr : ¬ p ∣ r) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR (p * r) N
      =
    -Goldbach.AO_OffDiag.TailBlock.ramanujanR r N := by
  set d : ℕ := Nat.gcd r N with hd
  have hpCN : Nat.Coprime p N := (hp.coprime_iff_not_dvd).2 hpN
  have hpCr : Nat.Coprime p r := (hp.coprime_iff_not_dvd).2 hpr
  have hd_dvd_r : d ∣ r := by simpa [hd] using Nat.gcd_dvd_left r N
  have hgcd :
      Nat.gcd (p * r) N = d := by
    simpa [d, hd, Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm] using
      hpCN.gcd_mul_left_cancel r
  have hmulDiv : (p * r) / d = p * (r / d) := by
    simpa [Nat.mul_assoc] using (Nat.mul_div_assoc p hd_dvd_r)
  have hpCrd : Nat.Coprime p (r / d) := hpCr.of_dvd_right (Nat.div_dvd_of_dvd hd_dvd_r)
  have hmu :
      (ArithmeticFunction.moebius ((p * r) / d) : ℤ)
        =
      (ArithmeticFunction.moebius p : ℤ) * (ArithmeticFunction.moebius (r / d) : ℤ) := by
    have hg : Nat.gcd p (r / d) = 1 := hpCrd.gcd_eq_one
    rw [hmulDiv]
    exact
      (ArithmeticFunction.IsMultiplicative.map_mul_of_coprime
        (f := (ArithmeticFunction.moebius : ArithmeticFunction ℤ))
        ArithmeticFunction.isMultiplicative_moebius hg)
  have hmu_p : (ArithmeticFunction.moebius p : ℤ) = -1 := by
    simpa using (ArithmeticFunction.moebius_apply_prime hp)
  have hmu' :
      (ArithmeticFunction.moebius ((p * r) / d) : ℤ)
        = -(ArithmeticFunction.moebius (r / d) : ℤ) := by
    calc
      (ArithmeticFunction.moebius ((p * r) / d) : ℤ)
          = (ArithmeticFunction.moebius p : ℤ) * (ArithmeticFunction.moebius (r / d) : ℤ) := hmu
      _ = (-1) * (ArithmeticFunction.moebius (r / d) : ℤ) := by simpa [hmu_p]
      _ = -(ArithmeticFunction.moebius (r / d) : ℤ) := by simp
  have hleft :
      Goldbach.AO_OffDiag.TailBlock.ramanujanZ (p * r) N
        =
      (ArithmeticFunction.moebius ((p * r) / d) : ℤ) * Int.ofNat (Nat.totient d) := by
    simp [Goldbach.AO_OffDiag.TailBlock.ramanujanZ, hgcd, d, hd]
  have hright :
      Goldbach.AO_OffDiag.TailBlock.ramanujanZ r N
        =
      (ArithmeticFunction.moebius (r / d) : ℤ) * Int.ofNat (Nat.totient d) := by
    simp [Goldbach.AO_OffDiag.TailBlock.ramanujanZ, d, hd]
  have hZ :
      Goldbach.AO_OffDiag.TailBlock.ramanujanZ (p * r) N
        = -Goldbach.AO_OffDiag.TailBlock.ramanujanZ r N := by
    calc
      Goldbach.AO_OffDiag.TailBlock.ramanujanZ (p * r) N
          = (ArithmeticFunction.moebius ((p * r) / d) : ℤ) * Int.ofNat (Nat.totient d) := hleft
      _ = (-(ArithmeticFunction.moebius (r / d) : ℤ)) * Int.ofNat (Nat.totient d) := by simp [hmu']
      _ = -((ArithmeticFunction.moebius (r / d) : ℤ) * Int.ofNat (Nat.totient d)) := by simp [neg_mul]
      _ = -Goldbach.AO_OffDiag.TailBlock.ramanujanZ r N := by simpa [hright]
  simpa [Goldbach.AO_OffDiag.TailBlock.ramanujanR] using congrArg (fun z : ℤ => (z : ℝ)) hZ

theorem ramanujanR_mul_prime_eq_scale_of_dvd_for_bothThree
    {r N p : ℕ} (hp : p.Prime) (hpN : p ∣ N) (hpr : ¬ p ∣ r) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR (p * r) N
      =
    ((p - 1 : ℕ) : ℝ) * Goldbach.AO_OffDiag.TailBlock.ramanujanR r N := by
  set d : ℕ := Nat.gcd r N with hd
  have hpCr : Nat.Coprime p r := (hp.coprime_iff_not_dvd).2 hpr
  have hd_dvd_r : d ∣ r := by simpa [hd] using Nat.gcd_dvd_left r N
  have hdivN : N = p * (N / p) := by
    exact (Nat.mul_div_cancel' hpN).symm
  have hgcd_r :
      Nat.gcd r (N / p) = d := by
    have htmp' : Nat.gcd (p * (N / p)) r = Nat.gcd (N / p) r := by
      simpa [Nat.mul_comm] using hpCr.gcd_mul_right_cancel (N / p)
    have htmp : Nat.gcd r N = Nat.gcd r (N / p) := by
      calc
        Nat.gcd r N = Nat.gcd r (p * (N / p)) := congrArg (Nat.gcd r) hdivN
        _ = Nat.gcd (p * (N / p)) r := by rw [Nat.gcd_comm]
        _ = Nat.gcd (N / p) r := htmp'
        _ = Nat.gcd r (N / p) := by rw [Nat.gcd_comm]
    simpa [hd] using htmp.symm
  have hgcd :
      Nat.gcd (p * r) N = p * d := by
    rw [hdivN]
    calc
      Nat.gcd (p * r) (p * (N / p)) = p * Nat.gcd r (N / p) := by
        simpa [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm] using Nat.gcd_mul_left p r (N / p)
      _ = p * d := by rw [hgcd_r]
  have hpCd : Nat.Coprime p d := hpCr.of_dvd_right hd_dvd_r
  have hphi : Nat.totient (p * d) = (p - 1) * Nat.totient d := by
    simpa [Nat.totient_prime hp] using (Nat.totient_mul hpCd)
  have hdiv : (p * r) / (p * d) = r / d := by
    simpa [Nat.mul_assoc, Nat.mul_left_comm, Nat.mul_comm] using
      (Nat.mul_div_mul_left r d hp.pos)
  have hZ :
      Goldbach.AO_OffDiag.TailBlock.ramanujanZ (p * r) N
        = (p - 1 : ℕ) * Goldbach.AO_OffDiag.TailBlock.ramanujanZ r N := by
    calc
      Goldbach.AO_OffDiag.TailBlock.ramanujanZ (p * r) N
          = (ArithmeticFunction.moebius (r / d) : ℤ) * Int.ofNat (Nat.totient (p * d)) := by
              simp [Goldbach.AO_OffDiag.TailBlock.ramanujanZ, hgcd, d, hd, hdiv]
      _ = (ArithmeticFunction.moebius (r / d) : ℤ) * Int.ofNat ((p - 1) * Nat.totient d) := by
            rw [hphi]
      _ = ((p - 1 : ℕ) : ℤ)
            * ((ArithmeticFunction.moebius (r / d) : ℤ) * Int.ofNat (Nat.totient d)) := by
            simp [Int.natCast_mul, mul_assoc, mul_left_comm, mul_comm]
      _ = (p - 1 : ℕ) * Goldbach.AO_OffDiag.TailBlock.ramanujanZ r N := by
            simp [Goldbach.AO_OffDiag.TailBlock.ramanujanZ, d, hd, Int.natCast_mul,
              mul_assoc, mul_left_comm, mul_comm]
  simpa [Goldbach.AO_OffDiag.TailBlock.ramanujanR, Int.cast_mul] using
    congrArg (fun z : ℤ => (z : ℝ)) hZ

theorem ramanujanR_mul_prime_eq_prime_mul_of_not_dvd_for_bothThree
    {r N p : ℕ} (hp : p.Prime) (hpr : ¬ p ∣ r) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR (p * r) N
      =
    Goldbach.AO_OffDiag.TailBlock.ramanujanR p N
      * Goldbach.AO_OffDiag.TailBlock.ramanujanR r N := by
  by_cases hpN : p ∣ N
  · rw [ramanujanR_mul_prime_eq_scale_of_dvd_for_bothThree hp hpN hpr]
    rw [ramanujanR_prime_eq_sub_one_of_dvd_for_bothThree hp hpN]
  · rw [ramanujanR_mul_prime_eq_neg_of_not_dvd_for_bothThree hp hpN hpr]
    rw [ramanujanR_prime_eq_neg_one_of_not_dvd_for_bothThree hp hpN]
    ring

theorem ramanujanR_three_mul_eq_three_mul_for_bothThree
    {r N : ℕ} (h3r : ¬ 3 ∣ r) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR (3 * r) N
      =
    Goldbach.AO_OffDiag.TailBlock.ramanujanR 3 N
      * Goldbach.AO_OffDiag.TailBlock.ramanujanR r N := by
  exact ramanujanR_mul_prime_eq_prime_mul_of_not_dvd_for_bothThree
    (p := 3) (r := r) (N := N) (by norm_num) h3r

theorem ramanujanR_fifteen_eq_three_mul_five_for_bothThree
    (N : ℕ) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR 15 N
      =
    Goldbach.AO_OffDiag.TailBlock.ramanujanR 3 N
      * Goldbach.AO_OffDiag.TailBlock.ramanujanR 5 N := by
  simpa using ramanujanR_three_mul_eq_three_mul_for_bothThree
    (r := 5) (N := N) (by norm_num)

theorem ramanujanR_twentyOne_eq_three_mul_seven_for_bothThree
    (N : ℕ) :
    Goldbach.AO_OffDiag.TailBlock.ramanujanR 21 N
      =
    Goldbach.AO_OffDiag.TailBlock.ramanujanR 3 N
      * Goldbach.AO_OffDiag.TailBlock.ramanujanR 7 N := by
  simpa using ramanujanR_three_mul_eq_three_mul_for_bothThree
    (r := 7) (N := N) (by norm_num)

theorem rawEvenRamanujanPairBlockSumRat_X0_15_21_eq_zero :
    rawEvenRamanujanPairBlockSumRat X0 15 21 = 0 := by
  native_decide

theorem rawEvenRamanujanBlockSumRat_X0_15_21_15_eq_zero :
    rawEvenRamanujanBlockSumRat X0 15 21 15 = 0 := by
  native_decide

theorem rawEvenRamanujanBlockSumRat_X0_15_21_21_eq_zero :
    rawEvenRamanujanBlockSumRat X0 15 21 21 = 0 := by
  native_decide

theorem ramanujanWindowAverageByGcdRat_X0_15_eq_neg_ten_div_5001 :
    ramanujanWindowAverageByGcdRat X0 15 = -(10 : ℚ) / 5001 := by
  native_decide

theorem ramanujanWindowAverageByGcdRat_X0_21_eq_zero :
    ramanujanWindowAverageByGcdRat X0 21 = 0 := by
  native_decide

theorem ramanujanWindowAverage_X0_21_eq_zero_by_bothThree_probe :
    ramanujanWindowAverage X0 21 = 0 := by
  rw [ramanujanWindowAverage_eq_ratCast_ramanujanWindowAverageByGcdRat
    (X := X0) (q := 21) (by norm_num)]
  rw [ramanujanWindowAverageByGcdRat_X0_21_eq_zero]
  norm_num

theorem centeredRamanujanPairFullEvenBlockSumFromRawRat_X0_15_21_eq_zero :
    centeredRamanujanPairFullEvenBlockSumFromRawRat X0 15 21 = 0 := by
  unfold centeredRamanujanPairFullEvenBlockSumFromRawRat
  rw [rawEvenRamanujanPairBlockSumRat_X0_15_21_eq_zero]
  rw [rawEvenRamanujanBlockSumRat_X0_15_21_15_eq_zero]
  rw [rawEvenRamanujanBlockSumRat_X0_15_21_21_eq_zero]
  rw [ramanujanWindowAverageByGcdRat_X0_21_eq_zero]
  ring

theorem centeredRamanujanPairFullEvenBlockSum_X0_15_21_eq_zero_by_bothThree_probe :
    centeredRamanujanPairFullEvenBlockSum X0 15 21 = 0 := by
  rw [centeredRamanujanPairFullEvenBlockSum_eq_rawBlock_decomposition]
  rw [rawEvenRamanujanPairBlockSum_eq_ratCast]
  rw [rawEvenRamanujanBlockSum_eq_ratCast]
  rw [rawEvenRamanujanBlockSum_eq_ratCast]
  rw [rawEvenRamanujanPairBlockSumRat_X0_15_21_eq_zero]
  rw [rawEvenRamanujanBlockSumRat_X0_15_21_15_eq_zero]
  rw [rawEvenRamanujanBlockSumRat_X0_15_21_21_eq_zero]
  rw [ramanujanWindowAverage_X0_21_eq_zero_by_bothThree_probe]
  ring

theorem centeredRamanujanPairPeriodicMainTerm_X0_15_21_eq_zero_by_bothThree_probe :
    centeredRamanujanPairPeriodicMainTerm X0 15 21 = 0 := by
  rw [centeredRamanujanPairPeriodicMainTerm_eq_blockScalar_fullEvenBlockSum_for_bothThree_probe
    (X := X0) (q := 15) (q' := 21) (by norm_num) (by norm_num)]
  rw [centeredRamanujanPairFullEvenBlockSum_X0_15_21_eq_zero_by_bothThree_probe]
  simp

theorem centeredRamanujanPairPeriodicMainTermRat_X0_15_21_eq_zero_by_bothThree_probe :
    centeredRamanujanPairPeriodicMainTermRat X0 15 21 = 0 := by
  apply Rat.cast_injective (α := ℝ)
  have hreal := centeredRamanujanPairPeriodicMainTerm_X0_15_21_eq_zero_by_bothThree_probe
  rw [centeredRamanujanPairPeriodicMainTerm_eq_ratCast] at hreal
  simpa using hreal

theorem surrogatePeriodicMainActiveOrderedPairSummandRat_X0_15_21_eq_zero_by_bothThree_probe :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (15, 21) = 0 := by
  apply surrogatePeriodicMainActiveOrderedPairSummandRat_eq_zero_of_real
  have hreal := centeredRamanujanPairPeriodicMainTerm_X0_15_21_eq_zero_by_bothThree_probe
  simp [hreal]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
