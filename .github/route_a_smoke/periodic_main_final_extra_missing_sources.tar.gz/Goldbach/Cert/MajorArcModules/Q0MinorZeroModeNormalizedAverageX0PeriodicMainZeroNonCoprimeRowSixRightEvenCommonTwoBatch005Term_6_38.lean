import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_38_X1000000_term_6_38 :
    ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 38 38
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 38) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 38 6 38
              - ramanujanGcdClassWindowAverageRat X0 38 38
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 6 6
              - ramanujanGcdClassWindowAverageRat X0 6 6
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 38 38
              + ramanujanGcdClassWindowAverageRat X0 6 6
                  * ramanujanGcdClassWindowAverageRat X0 38 38
                  * evenRamanujanBlockCountRat 6 38))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 6 = (2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 38 38 = (18 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 6 = (1 : ℚ) / 3 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 38 38 = (263 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 6 6 = (38 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 38 38 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 38 6 38 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
