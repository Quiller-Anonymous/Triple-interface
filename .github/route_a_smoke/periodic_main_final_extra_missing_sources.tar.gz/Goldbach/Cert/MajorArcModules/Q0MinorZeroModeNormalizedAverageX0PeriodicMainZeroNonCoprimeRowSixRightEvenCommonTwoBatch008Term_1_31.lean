import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_62_X1000000_term_1_31 :
    ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 62 31
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 62) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 62 1 31
              - ramanujanGcdClassWindowAverageRat X0 62 31
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 6 1
              - ramanujanGcdClassWindowAverageRat X0 6 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 62 31
              + ramanujanGcdClassWindowAverageRat X0 6 1
                  * ramanujanGcdClassWindowAverageRat X0 62 31
                  * evenRamanujanBlockCountRat 6 62))
      = (0 : ℚ) / 1 := by
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 62 31 = (0 : ℚ) / 1 := by
    have hreal := ramanujanGcdClassWindowAverage_eq_zero_of_isEven_q_of_not_isEven_g (X := X0) (q := 62) (g := 31) (by norm_num [Goldbach.Windows.IsEven]) (by norm_num [Goldbach.Windows.IsEven])
    rw [ramanujanGcdClassWindowAverage_eq_ratCast] at hreal
    exact Rat.cast_inj.mp (by simpa using hreal)
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 62 31 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 62 1 31 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  rw [hPair, hAvgRight, hBlockRight]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
