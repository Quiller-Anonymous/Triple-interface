import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_118_X1000000_term_2_59 :
    ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 118 59
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 118) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 118 2 59
              - ramanujanGcdClassWindowAverageRat X0 118 59
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 118 6 2
              - ramanujanGcdClassWindowAverageRat X0 6 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 118 118 59
              + ramanujanGcdClassWindowAverageRat X0 6 2
                  * ramanujanGcdClassWindowAverageRat X0 118 59
                  * evenRamanujanBlockCountRat 6 118))
      = (0 : ℚ) / 1 := by
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 118 59 = (0 : ℚ) / 1 := by
    have hreal := ramanujanGcdClassWindowAverage_eq_zero_of_isEven_q_of_not_isEven_g (X := X0) (q := 118) (g := 59) (by norm_num [Goldbach.Windows.IsEven]) (by norm_num [Goldbach.Windows.IsEven])
    rw [ramanujanGcdClassWindowAverage_eq_ratCast] at hreal
    exact Rat.cast_inj.mp (by simpa using hreal)
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 118 118 59 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 118 2 59 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_zero_of_incompatible]
    norm_num [ramanujanGcdClassJointCompatibility]
  rw [hPair, hAvgRight, hBlockRight]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
