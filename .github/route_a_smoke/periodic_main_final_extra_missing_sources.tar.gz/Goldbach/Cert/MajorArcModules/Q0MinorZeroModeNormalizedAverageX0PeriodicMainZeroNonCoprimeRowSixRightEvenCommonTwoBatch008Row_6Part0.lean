import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Term_6_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Term_6_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Term_6_31
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Term_6_62

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_62_X1000000_rowChunk_6_0 : Finset ℕ :=
  ([1, 2, 31, 62] : List ℕ).toFinset

def periodicMainPair_6_62_X1000000_rowPartValue_6_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 31 => (0 : ℚ) / 1
| 62 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_62_X1000000_rowPart_6_0 :
    (∑ h ∈ periodicMainPair_6_62_X1000000_rowChunk_6_0,
      ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 62 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 62) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 62 6 h
                - ramanujanGcdClassWindowAverageRat X0 62 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 6 6
                - ramanujanGcdClassWindowAverageRat X0 6 6
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 62 h
                + ramanujanGcdClassWindowAverageRat X0 6 6
                    * ramanujanGcdClassWindowAverageRat X0 62 h
                    * evenRamanujanBlockCountRat 6 62))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_62_X1000000_rowChunk_6_0,
        ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 62 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 62) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 62 6 h
                  - ramanujanGcdClassWindowAverageRat X0 62 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 6 6
                  - ramanujanGcdClassWindowAverageRat X0 6 6
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 62 h
                  + ramanujanGcdClassWindowAverageRat X0 6 6
                      * ramanujanGcdClassWindowAverageRat X0 62 h
                      * evenRamanujanBlockCountRat 6 62))
      ) = (∑ h ∈ periodicMainPair_6_62_X1000000_rowChunk_6_0, periodicMainPair_6_62_X1000000_rowPartValue_6_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_62_X1000000_rowChunk_6_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_62_X1000000_rowPartValue_6_0] using periodicMainPair_6_62_X1000000_term_6_1
    · simpa [periodicMainPair_6_62_X1000000_rowPartValue_6_0] using periodicMainPair_6_62_X1000000_term_6_2
    · simpa [periodicMainPair_6_62_X1000000_rowPartValue_6_0] using periodicMainPair_6_62_X1000000_term_6_31
    · simpa [periodicMainPair_6_62_X1000000_rowPartValue_6_0] using periodicMainPair_6_62_X1000000_term_6_62
  rw [hsum]
  norm_num [periodicMainPair_6_62_X1000000_rowChunk_6_0, periodicMainPair_6_62_X1000000_rowPartValue_6_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
