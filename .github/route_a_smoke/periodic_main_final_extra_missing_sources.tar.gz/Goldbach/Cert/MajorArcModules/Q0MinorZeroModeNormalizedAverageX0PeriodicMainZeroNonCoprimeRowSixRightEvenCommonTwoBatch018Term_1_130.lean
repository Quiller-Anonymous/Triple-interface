import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_130_X1000000_term_1_130 :
    ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 130 130
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 130) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 130 1 130
              - ramanujanGcdClassWindowAverageRat X0 130 130
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 6 1
              - ramanujanGcdClassWindowAverageRat X0 6 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 130 130
              + ramanujanGcdClassWindowAverageRat X0 6 1
                  * ramanujanGcdClassWindowAverageRat X0 130 130
                  * evenRamanujanBlockCountRat 6 130))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 130 130 = (48 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 130 130 = (77 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 6 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 130 130 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 130 1 130 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_zero_of_incompatible]
    norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
