import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch016Term_1_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch016Term_1_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch016Term_1_59
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch016Term_1_118

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_118_X1000000_rowChunk_1_0 : Finset ℕ :=
  ([1, 2, 59, 118] : List ℕ).toFinset

def periodicMainPair_6_118_X1000000_rowPartValue_1_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 59 => (0 : ℚ) / 1
| 118 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_118_X1000000_rowPart_1_0 :
    (∑ h ∈ periodicMainPair_6_118_X1000000_rowChunk_1_0,
      ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 118 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 118) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 118 1 h
                - ramanujanGcdClassWindowAverageRat X0 118 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 118 6 1
                - ramanujanGcdClassWindowAverageRat X0 6 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 118 118 h
                + ramanujanGcdClassWindowAverageRat X0 6 1
                    * ramanujanGcdClassWindowAverageRat X0 118 h
                    * evenRamanujanBlockCountRat 6 118))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_118_X1000000_rowChunk_1_0,
        ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 118 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 118) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 118 1 h
                  - ramanujanGcdClassWindowAverageRat X0 118 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 118 6 1
                  - ramanujanGcdClassWindowAverageRat X0 6 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 118 118 h
                  + ramanujanGcdClassWindowAverageRat X0 6 1
                      * ramanujanGcdClassWindowAverageRat X0 118 h
                      * evenRamanujanBlockCountRat 6 118))
      ) = (∑ h ∈ periodicMainPair_6_118_X1000000_rowChunk_1_0, periodicMainPair_6_118_X1000000_rowPartValue_1_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_118_X1000000_rowChunk_1_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_118_X1000000_rowPartValue_1_0] using periodicMainPair_6_118_X1000000_term_1_1
    · simpa [periodicMainPair_6_118_X1000000_rowPartValue_1_0] using periodicMainPair_6_118_X1000000_term_1_2
    · simpa [periodicMainPair_6_118_X1000000_rowPartValue_1_0] using periodicMainPair_6_118_X1000000_term_1_59
    · simpa [periodicMainPair_6_118_X1000000_rowPartValue_1_0] using periodicMainPair_6_118_X1000000_term_1_118
  rw [hsum]
  norm_num [periodicMainPair_6_118_X1000000_rowChunk_1_0, periodicMainPair_6_118_X1000000_rowPartValue_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
