import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_7
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_10
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_14
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_35
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_1_70

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_70_X1000000_rowChunk_1_0 : Finset ℕ :=
  ([1, 2, 5, 7, 10, 14, 35, 70] : List ℕ).toFinset

def periodicMainPair_6_70_X1000000_rowPartValue_1_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 5 => (0 : ℚ) / 1
| 7 => (0 : ℚ) / 1
| 10 => (0 : ℚ) / 1
| 14 => (0 : ℚ) / 1
| 35 => (0 : ℚ) / 1
| 70 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_70_X1000000_rowPart_1_0 :
    (∑ h ∈ periodicMainPair_6_70_X1000000_rowChunk_1_0,
      ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 70 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 70) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 70 1 h
                - ramanujanGcdClassWindowAverageRat X0 70 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 6 1
                - ramanujanGcdClassWindowAverageRat X0 6 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 70 h
                + ramanujanGcdClassWindowAverageRat X0 6 1
                    * ramanujanGcdClassWindowAverageRat X0 70 h
                    * evenRamanujanBlockCountRat 6 70))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_70_X1000000_rowChunk_1_0,
        ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 70 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 70) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 70 1 h
                  - ramanujanGcdClassWindowAverageRat X0 70 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 6 1
                  - ramanujanGcdClassWindowAverageRat X0 6 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 70 h
                  + ramanujanGcdClassWindowAverageRat X0 6 1
                      * ramanujanGcdClassWindowAverageRat X0 70 h
                      * evenRamanujanBlockCountRat 6 70))
      ) = (∑ h ∈ periodicMainPair_6_70_X1000000_rowChunk_1_0, periodicMainPair_6_70_X1000000_rowPartValue_1_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_70_X1000000_rowChunk_1_0] at hh
    rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_1
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_2
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_5
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_7
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_10
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_14
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_35
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_1_0] using periodicMainPair_6_70_X1000000_term_1_70
  rw [hsum]
  norm_num [periodicMainPair_6_70_X1000000_rowChunk_1_0, periodicMainPair_6_70_X1000000_rowPartValue_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
