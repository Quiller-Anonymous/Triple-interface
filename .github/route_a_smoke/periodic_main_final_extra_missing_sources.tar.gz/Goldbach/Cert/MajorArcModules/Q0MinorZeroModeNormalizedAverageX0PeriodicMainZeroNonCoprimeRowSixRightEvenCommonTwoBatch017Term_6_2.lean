import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_122_X1000000_term_6_2 :
    ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 122 2
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 122) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 122 6 2
              - ramanujanGcdClassWindowAverageRat X0 122 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 122 6 6
              - ramanujanGcdClassWindowAverageRat X0 6 6
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 122 122 2
              + ramanujanGcdClassWindowAverageRat X0 6 6
                  * ramanujanGcdClassWindowAverageRat X0 122 2
                  * evenRamanujanBlockCountRat 6 122))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 6 = (2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 122 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 6 = (1 : ℚ) / 3 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 122 2 = (4919 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 122 6 6 = (122 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 122 122 2 = (360 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 122 6 2 = (120 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
