import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_7
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_10
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_14
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_35
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Term_3_70

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_70_X1000000_rowChunk_3_0 : Finset ℕ :=
  ([1, 2, 5, 7, 10, 14, 35, 70] : List ℕ).toFinset

def periodicMainPair_6_70_X1000000_rowPartValue_3_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 5 => (0 : ℚ) / 1
| 7 => (0 : ℚ) / 1
| 10 => (0 : ℚ) / 1
| 14 => (0 : ℚ) / 1
| 35 => (0 : ℚ) / 1
| 70 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_70_X1000000_rowPart_3_0 :
    (∑ h ∈ periodicMainPair_6_70_X1000000_rowChunk_3_0,
      ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 70 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 70) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 70 3 h
                - ramanujanGcdClassWindowAverageRat X0 70 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 6 3
                - ramanujanGcdClassWindowAverageRat X0 6 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 70 h
                + ramanujanGcdClassWindowAverageRat X0 6 3
                    * ramanujanGcdClassWindowAverageRat X0 70 h
                    * evenRamanujanBlockCountRat 6 70))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_70_X1000000_rowChunk_3_0,
        ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 70 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 70) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 70 3 h
                  - ramanujanGcdClassWindowAverageRat X0 70 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 6 3
                  - ramanujanGcdClassWindowAverageRat X0 6 3
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 70 h
                  + ramanujanGcdClassWindowAverageRat X0 6 3
                      * ramanujanGcdClassWindowAverageRat X0 70 h
                      * evenRamanujanBlockCountRat 6 70))
      ) = (∑ h ∈ periodicMainPair_6_70_X1000000_rowChunk_3_0, periodicMainPair_6_70_X1000000_rowPartValue_3_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_70_X1000000_rowChunk_3_0] at hh
    rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_1
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_2
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_5
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_7
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_10
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_14
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_35
    · simpa [periodicMainPair_6_70_X1000000_rowPartValue_3_0] using periodicMainPair_6_70_X1000000_term_3_70
  rw [hsum]
  norm_num [periodicMainPair_6_70_X1000000_rowChunk_3_0, periodicMainPair_6_70_X1000000_rowPartValue_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
