import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch006Term_2_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch006Term_2_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch006Term_2_23
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch006Term_2_46

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_46_X1000000_rowChunk_2_0 : Finset ℕ :=
  ([1, 2, 23, 46] : List ℕ).toFinset

def periodicMainPair_6_46_X1000000_rowPartValue_2_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 23 => (0 : ℚ) / 1
| 46 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_46_X1000000_rowPart_2_0 :
    (∑ h ∈ periodicMainPair_6_46_X1000000_rowChunk_2_0,
      ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 46 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 46) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 46 2 h
                - ramanujanGcdClassWindowAverageRat X0 46 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 46 6 2
                - ramanujanGcdClassWindowAverageRat X0 6 2
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 46 46 h
                + ramanujanGcdClassWindowAverageRat X0 6 2
                    * ramanujanGcdClassWindowAverageRat X0 46 h
                    * evenRamanujanBlockCountRat 6 46))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_46_X1000000_rowChunk_2_0,
        ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 46 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 46) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 46 2 h
                  - ramanujanGcdClassWindowAverageRat X0 46 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 46 6 2
                  - ramanujanGcdClassWindowAverageRat X0 6 2
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 46 46 h
                  + ramanujanGcdClassWindowAverageRat X0 6 2
                      * ramanujanGcdClassWindowAverageRat X0 46 h
                      * evenRamanujanBlockCountRat 6 46))
      ) = (∑ h ∈ periodicMainPair_6_46_X1000000_rowChunk_2_0, periodicMainPair_6_46_X1000000_rowPartValue_2_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_46_X1000000_rowChunk_2_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_46_X1000000_rowPartValue_2_0] using periodicMainPair_6_46_X1000000_term_2_1
    · simpa [periodicMainPair_6_46_X1000000_rowPartValue_2_0] using periodicMainPair_6_46_X1000000_term_2_2
    · simpa [periodicMainPair_6_46_X1000000_rowPartValue_2_0] using periodicMainPair_6_46_X1000000_term_2_23
    · simpa [periodicMainPair_6_46_X1000000_rowPartValue_2_0] using periodicMainPair_6_46_X1000000_term_2_46
  rw [hsum]
  norm_num [periodicMainPair_6_46_X1000000_rowChunk_2_0, periodicMainPair_6_46_X1000000_rowPartValue_2_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
