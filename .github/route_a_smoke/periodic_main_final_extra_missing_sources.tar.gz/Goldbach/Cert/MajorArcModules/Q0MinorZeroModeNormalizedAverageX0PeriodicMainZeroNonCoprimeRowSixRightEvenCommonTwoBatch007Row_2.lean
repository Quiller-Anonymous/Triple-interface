import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch007Row_2Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_58_X1000000_divRight_for_row_2 : Nat.divisors 58 = ([1, 2, 29, 58] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_58_X1000000_row_2 :
    (∑ h ∈ Nat.divisors 58,
      ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 58 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 58) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 58 2 h
                - ramanujanGcdClassWindowAverageRat X0 58 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 58 6 2
                - ramanujanGcdClassWindowAverageRat X0 6 2
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 58 58 h
                + ramanujanGcdClassWindowAverageRat X0 6 2
                    * ramanujanGcdClassWindowAverageRat X0 58 h
                    * evenRamanujanBlockCountRat 6 58))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_58_X1000000_divRight_for_row_2]
  have hset : ([1, 2, 29, 58] : List ℕ).toFinset = periodicMainPair_6_58_X1000000_rowChunk_2_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_58_X1000000_rowPart_2_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
