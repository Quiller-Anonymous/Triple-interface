import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch005Row_1Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_38_X1000000_divRight_for_row_1 : Nat.divisors 38 = ([1, 2, 19, 38] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_38_X1000000_row_1 :
    (∑ h ∈ Nat.divisors 38,
      ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 38 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 38) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 38 1 h
                - ramanujanGcdClassWindowAverageRat X0 38 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 6 1
                - ramanujanGcdClassWindowAverageRat X0 6 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 38 h
                + ramanujanGcdClassWindowAverageRat X0 6 1
                    * ramanujanGcdClassWindowAverageRat X0 38 h
                    * evenRamanujanBlockCountRat 6 38))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_38_X1000000_divRight_for_row_1]
  have hset : ([1, 2, 19, 38] : List ℕ).toFinset = periodicMainPair_6_38_X1000000_rowChunk_1_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_38_X1000000_rowPart_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
