import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_110_X1000000_term_6_55 :
    ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 110 55
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 110) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 110 6 55
              - ramanujanGcdClassWindowAverageRat X0 110 55
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 110 6 6
              - ramanujanGcdClassWindowAverageRat X0 6 6
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 110 110 55
              + ramanujanGcdClassWindowAverageRat X0 6 6
                  * ramanujanGcdClassWindowAverageRat X0 110 55
                  * evenRamanujanBlockCountRat 6 110))
      = (0 : ℚ) / 1 := by
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 110 55 = (0 : ℚ) / 1 := by
    have hreal := ramanujanGcdClassWindowAverage_eq_zero_of_isEven_q_of_not_isEven_g (X := X0) (q := 110) (g := 55) (by norm_num [Goldbach.Windows.IsEven]) (by norm_num [Goldbach.Windows.IsEven])
    rw [ramanujanGcdClassWindowAverage_eq_ratCast] at hreal
    exact Rat.cast_inj.mp (by simpa using hreal)
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 110 110 55 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 110 6 55 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_zero_of_incompatible]
    norm_num [ramanujanGcdClassJointCompatibility]
  rw [hPair, hAvgRight, hBlockRight]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
