import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_10
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_13
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_26
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_65
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Term_3_130

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_130_X1000000_rowChunk_3_0 : Finset ℕ :=
  ([1, 2, 5, 10, 13, 26, 65, 130] : List ℕ).toFinset

def periodicMainPair_6_130_X1000000_rowPartValue_3_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 5 => (0 : ℚ) / 1
| 10 => (0 : ℚ) / 1
| 13 => (0 : ℚ) / 1
| 26 => (0 : ℚ) / 1
| 65 => (0 : ℚ) / 1
| 130 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_130_X1000000_rowPart_3_0 :
    (∑ h ∈ periodicMainPair_6_130_X1000000_rowChunk_3_0,
      ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 130 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 130) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 130 3 h
                - ramanujanGcdClassWindowAverageRat X0 130 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 6 3
                - ramanujanGcdClassWindowAverageRat X0 6 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 130 h
                + ramanujanGcdClassWindowAverageRat X0 6 3
                    * ramanujanGcdClassWindowAverageRat X0 130 h
                    * evenRamanujanBlockCountRat 6 130))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_130_X1000000_rowChunk_3_0,
        ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 130 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 130) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 130 3 h
                  - ramanujanGcdClassWindowAverageRat X0 130 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 6 3
                  - ramanujanGcdClassWindowAverageRat X0 6 3
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 130 h
                  + ramanujanGcdClassWindowAverageRat X0 6 3
                      * ramanujanGcdClassWindowAverageRat X0 130 h
                      * evenRamanujanBlockCountRat 6 130))
      ) = (∑ h ∈ periodicMainPair_6_130_X1000000_rowChunk_3_0, periodicMainPair_6_130_X1000000_rowPartValue_3_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_130_X1000000_rowChunk_3_0] at hh
    rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_1
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_2
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_5
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_10
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_13
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_26
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_65
    · simpa [periodicMainPair_6_130_X1000000_rowPartValue_3_0] using periodicMainPair_6_130_X1000000_term_3_130
  rw [hsum]
  norm_num [periodicMainPair_6_130_X1000000_rowChunk_3_0, periodicMainPair_6_130_X1000000_rowPartValue_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
