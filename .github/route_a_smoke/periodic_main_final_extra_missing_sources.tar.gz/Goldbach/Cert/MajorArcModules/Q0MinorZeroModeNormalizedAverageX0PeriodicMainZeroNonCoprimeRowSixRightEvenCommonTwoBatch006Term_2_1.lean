import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_46_X1000000_term_2_1 :
    ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 46 1
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 46) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 46 2 1
              - ramanujanGcdClassWindowAverageRat X0 46 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 46 6 2
              - ramanujanGcdClassWindowAverageRat X0 6 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 46 46 1
              + ramanujanGcdClassWindowAverageRat X0 6 2
                  * ramanujanGcdClassWindowAverageRat X0 46 1
                  * evenRamanujanBlockCountRat 6 46))
      = (0 : ℚ) / 1 := by
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 46 1 = (0 : ℚ) / 1 := by
    have hreal := ramanujanGcdClassWindowAverage_eq_zero_of_isEven_q_of_not_isEven_g (X := X0) (q := 46) (g := 1) (by norm_num [Goldbach.Windows.IsEven]) (by norm_num [Goldbach.Windows.IsEven])
    rw [ramanujanGcdClassWindowAverage_eq_ratCast] at hreal
    exact Rat.cast_inj.mp (by simpa using hreal)
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 46 46 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 46 2 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_zero_of_incompatible]
    norm_num [ramanujanGcdClassJointCompatibility]
  rw [hPair, hAvgRight, hBlockRight]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
