import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Row_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Row_6

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 8. -/

theorem periodicMainPair_6_62_X1000000_divLeft : Nat.divisors 6 = ([1, 2, 3, 6] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_62_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 6 62 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 6, ∑ h ∈ Nat.divisors 62,
        ramanujanGcdClassCoeffRat 6 g * ramanujanGcdClassCoeffRat 62 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 62) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 62 g h
                  - ramanujanGcdClassWindowAverageRat X0 62 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 6 g
                  - ramanujanGcdClassWindowAverageRat X0 6 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 62 h
                  + ramanujanGcdClassWindowAverageRat X0 6 g
                      * ramanujanGcdClassWindowAverageRat X0 62 h
                      * evenRamanujanBlockCountRat 6 62))
      ) = (∑ g ∈ Nat.divisors 6, (0 : ℚ)) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_6_62_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl
    · simpa using periodicMainPair_6_62_X1000000_row_1
    · simpa using periodicMainPair_6_62_X1000000_row_2
    · simpa using periodicMainPair_6_62_X1000000_row_3
    · simpa using periodicMainPair_6_62_X1000000_row_6
  rw [hsum, periodicMainPair_6_62_X1000000_divLeft]
  norm_num

theorem periodicMainPair_6_62_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 6 62) = (0 : ℚ) / 1 := by
  have hneq : 6 ≠ 62 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 6 = (5 : ℚ) / 4 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 62 = (1 : ℚ) / 180 := by
    native_decide
  have hvalue : ((5 : ℚ) / 4) * ((1 : ℚ) / 180) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_6_62_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsNonCoprimeRowSixRightEvenCommonTwoBatch008Pairs : Finset (ℕ × ℕ) :=
  [(6, 62)].toFinset

theorem PeriodicMainRecordsNonCoprimeRowSixRightEvenCommonTwoBatch008_value_on_records :
    ∀ p ∈ PeriodicMainRecordsNonCoprimeRowSixRightEvenCommonTwoBatch008Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsNonCoprimeRowSixRightEvenCommonTwoBatch008Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_6_62_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
