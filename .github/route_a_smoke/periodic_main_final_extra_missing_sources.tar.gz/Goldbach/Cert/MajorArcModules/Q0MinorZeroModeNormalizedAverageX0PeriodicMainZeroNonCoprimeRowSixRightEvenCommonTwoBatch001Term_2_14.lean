import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_14_X1000000_term_2_14 :
    ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 14 14
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 14) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 14 2 14
              - ramanujanGcdClassWindowAverageRat X0 14 14
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 14 6 2
              - ramanujanGcdClassWindowAverageRat X0 6 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 14 14 14
              + ramanujanGcdClassWindowAverageRat X0 6 2
                  * ramanujanGcdClassWindowAverageRat X0 14 14
                  * evenRamanujanBlockCountRat 6 14))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 14 14 = (6 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 2 = (2 : ℚ) / 3 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 14 14 = (238 : ℚ) / 1667 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 14 6 2 = (28 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 14 14 14 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 14 2 14 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
