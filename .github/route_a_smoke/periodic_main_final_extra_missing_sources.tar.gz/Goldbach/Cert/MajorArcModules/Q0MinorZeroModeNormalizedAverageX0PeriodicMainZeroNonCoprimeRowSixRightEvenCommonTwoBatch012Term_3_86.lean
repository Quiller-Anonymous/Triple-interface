import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_86_X1000000_term_3_86 :
    ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 86 86
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 86) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 86 3 86
              - ramanujanGcdClassWindowAverageRat X0 86 86
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 86 6 3
              - ramanujanGcdClassWindowAverageRat X0 6 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 86 86 86
              + ramanujanGcdClassWindowAverageRat X0 6 3
                  * ramanujanGcdClassWindowAverageRat X0 86 86
                  * evenRamanujanBlockCountRat 6 86))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 86 86 = (42 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 3 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 86 86 = (39 : ℚ) / 1667 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 86 6 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 86 86 86 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 86 3 86 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_zero_of_incompatible]
    norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
