import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch000Row_3Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_10_X1000000_divRight_for_row_3 : Nat.divisors 10 = ([1, 2, 5, 10] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_10_X1000000_row_3 :
    (∑ h ∈ Nat.divisors 10,
      ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 10 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 10) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 10 3 h
                - ramanujanGcdClassWindowAverageRat X0 10 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 10 6 3
                - ramanujanGcdClassWindowAverageRat X0 6 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 10 10 h
                + ramanujanGcdClassWindowAverageRat X0 6 3
                    * ramanujanGcdClassWindowAverageRat X0 10 h
                    * evenRamanujanBlockCountRat 6 10))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_10_X1000000_divRight_for_row_3]
  have hset : ([1, 2, 5, 10] : List ℕ).toFinset = periodicMainPair_6_10_X1000000_rowChunk_3_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_10_X1000000_rowPart_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
