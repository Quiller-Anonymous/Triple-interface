import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch005Term_6_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch005Term_6_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch005Term_6_19
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch005Term_6_38

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_38_X1000000_rowChunk_6_0 : Finset ℕ :=
  ([1, 2, 19, 38] : List ℕ).toFinset

def periodicMainPair_6_38_X1000000_rowPartValue_6_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 19 => (0 : ℚ) / 1
| 38 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_38_X1000000_rowPart_6_0 :
    (∑ h ∈ periodicMainPair_6_38_X1000000_rowChunk_6_0,
      ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 38 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 38) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 38 6 h
                - ramanujanGcdClassWindowAverageRat X0 38 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 6 6
                - ramanujanGcdClassWindowAverageRat X0 6 6
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 38 h
                + ramanujanGcdClassWindowAverageRat X0 6 6
                    * ramanujanGcdClassWindowAverageRat X0 38 h
                    * evenRamanujanBlockCountRat 6 38))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_38_X1000000_rowChunk_6_0,
        ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 38 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 38) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 38 6 h
                  - ramanujanGcdClassWindowAverageRat X0 38 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 6 6
                  - ramanujanGcdClassWindowAverageRat X0 6 6
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 38 h
                  + ramanujanGcdClassWindowAverageRat X0 6 6
                      * ramanujanGcdClassWindowAverageRat X0 38 h
                      * evenRamanujanBlockCountRat 6 38))
      ) = (∑ h ∈ periodicMainPair_6_38_X1000000_rowChunk_6_0, periodicMainPair_6_38_X1000000_rowPartValue_6_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_38_X1000000_rowChunk_6_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_38_X1000000_rowPartValue_6_0] using periodicMainPair_6_38_X1000000_term_6_1
    · simpa [periodicMainPair_6_38_X1000000_rowPartValue_6_0] using periodicMainPair_6_38_X1000000_term_6_2
    · simpa [periodicMainPair_6_38_X1000000_rowPartValue_6_0] using periodicMainPair_6_38_X1000000_term_6_19
    · simpa [periodicMainPair_6_38_X1000000_rowPartValue_6_0] using periodicMainPair_6_38_X1000000_term_6_38
  rw [hsum]
  norm_num [periodicMainPair_6_38_X1000000_rowChunk_6_0, periodicMainPair_6_38_X1000000_rowPartValue_6_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
