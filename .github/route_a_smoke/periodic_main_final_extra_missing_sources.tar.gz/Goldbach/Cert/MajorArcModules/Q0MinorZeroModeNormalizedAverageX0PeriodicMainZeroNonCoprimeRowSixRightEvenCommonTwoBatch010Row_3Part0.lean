import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch010Term_3_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch010Term_3_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch010Term_3_37
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch010Term_3_74

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_74_X1000000_rowChunk_3_0 : Finset ℕ :=
  ([1, 2, 37, 74] : List ℕ).toFinset

def periodicMainPair_6_74_X1000000_rowPartValue_3_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 37 => (0 : ℚ) / 1
| 74 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_74_X1000000_rowPart_3_0 :
    (∑ h ∈ periodicMainPair_6_74_X1000000_rowChunk_3_0,
      ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 74 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 74) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 74 3 h
                - ramanujanGcdClassWindowAverageRat X0 74 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 74 6 3
                - ramanujanGcdClassWindowAverageRat X0 6 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 74 74 h
                + ramanujanGcdClassWindowAverageRat X0 6 3
                    * ramanujanGcdClassWindowAverageRat X0 74 h
                    * evenRamanujanBlockCountRat 6 74))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_74_X1000000_rowChunk_3_0,
        ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 74 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 74) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 74 3 h
                  - ramanujanGcdClassWindowAverageRat X0 74 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 74 6 3
                  - ramanujanGcdClassWindowAverageRat X0 6 3
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 74 74 h
                  + ramanujanGcdClassWindowAverageRat X0 6 3
                      * ramanujanGcdClassWindowAverageRat X0 74 h
                      * evenRamanujanBlockCountRat 6 74))
      ) = (∑ h ∈ periodicMainPair_6_74_X1000000_rowChunk_3_0, periodicMainPair_6_74_X1000000_rowPartValue_3_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_74_X1000000_rowChunk_3_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_74_X1000000_rowPartValue_3_0] using periodicMainPair_6_74_X1000000_term_3_1
    · simpa [periodicMainPair_6_74_X1000000_rowPartValue_3_0] using periodicMainPair_6_74_X1000000_term_3_2
    · simpa [periodicMainPair_6_74_X1000000_rowPartValue_3_0] using periodicMainPair_6_74_X1000000_term_3_37
    · simpa [periodicMainPair_6_74_X1000000_rowPartValue_3_0] using periodicMainPair_6_74_X1000000_term_3_74
  rw [hsum]
  norm_num [periodicMainPair_6_74_X1000000_rowChunk_3_0, periodicMainPair_6_74_X1000000_rowPartValue_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
