import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_38_X1000000_term_1_2 :
    ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 38 2
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 38) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 38 1 2
              - ramanujanGcdClassWindowAverageRat X0 38 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 6 1
              - ramanujanGcdClassWindowAverageRat X0 6 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 38 2
              + ramanujanGcdClassWindowAverageRat X0 6 1
                  * ramanujanGcdClassWindowAverageRat X0 38 2
                  * evenRamanujanBlockCountRat 6 38))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 38 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 38 2 = (4738 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 6 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 38 38 2 = (108 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 38 1 2 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_zero_of_incompatible]
    norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
