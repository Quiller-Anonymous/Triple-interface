import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch002Row_1Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_22_X1000000_divRight_for_row_1 : Nat.divisors 22 = ([1, 2, 11, 22] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_22_X1000000_row_1 :
    (∑ h ∈ Nat.divisors 22,
      ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 22 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 22) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 22 1 h
                - ramanujanGcdClassWindowAverageRat X0 22 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 22 6 1
                - ramanujanGcdClassWindowAverageRat X0 6 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 22 22 h
                + ramanujanGcdClassWindowAverageRat X0 6 1
                    * ramanujanGcdClassWindowAverageRat X0 22 h
                    * evenRamanujanBlockCountRat 6 22))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_22_X1000000_divRight_for_row_1]
  have hset : ([1, 2, 11, 22] : List ℕ).toFinset = periodicMainPair_6_22_X1000000_rowChunk_1_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_22_X1000000_rowPart_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
