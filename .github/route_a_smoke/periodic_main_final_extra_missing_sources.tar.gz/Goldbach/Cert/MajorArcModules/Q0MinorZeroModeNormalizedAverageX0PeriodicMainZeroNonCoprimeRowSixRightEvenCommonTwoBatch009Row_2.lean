import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch009Row_2Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_70_X1000000_divRight_for_row_2 : Nat.divisors 70 = ([1, 2, 5, 7, 10, 14, 35, 70] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_70_X1000000_row_2 :
    (∑ h ∈ Nat.divisors 70,
      ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 70 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 70) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 70 2 h
                - ramanujanGcdClassWindowAverageRat X0 70 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 6 2
                - ramanujanGcdClassWindowAverageRat X0 6 2
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 70 h
                + ramanujanGcdClassWindowAverageRat X0 6 2
                    * ramanujanGcdClassWindowAverageRat X0 70 h
                    * evenRamanujanBlockCountRat 6 70))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_70_X1000000_divRight_for_row_2]
  have hset : ([1, 2, 5, 7, 10, 14, 35, 70] : List ℕ).toFinset = periodicMainPair_6_70_X1000000_rowChunk_2_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_70_X1000000_rowPart_2_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
