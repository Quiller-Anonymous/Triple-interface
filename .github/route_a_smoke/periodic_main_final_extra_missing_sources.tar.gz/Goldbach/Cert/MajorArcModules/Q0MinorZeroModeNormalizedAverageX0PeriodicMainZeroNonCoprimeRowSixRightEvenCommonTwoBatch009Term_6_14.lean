import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_70_X1000000_term_6_14 :
    ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 70 14
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 70) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 70 6 14
              - ramanujanGcdClassWindowAverageRat X0 70 14
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 6 6
              - ramanujanGcdClassWindowAverageRat X0 6 6
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 70 14
              + ramanujanGcdClassWindowAverageRat X0 6 6
                  * ramanujanGcdClassWindowAverageRat X0 70 14
                  * evenRamanujanBlockCountRat 6 70))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 6 = (2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 70 14 = (-6 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 6 = (1 : ℚ) / 3 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 70 14 = (571 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 6 6 = (70 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 70 70 14 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 70 6 14 = (8 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
