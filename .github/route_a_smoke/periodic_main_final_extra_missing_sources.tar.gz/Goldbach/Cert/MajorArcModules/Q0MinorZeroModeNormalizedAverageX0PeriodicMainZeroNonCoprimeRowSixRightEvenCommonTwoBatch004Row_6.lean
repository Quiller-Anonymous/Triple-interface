import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch004Row_6Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_34_X1000000_divRight_for_row_6 : Nat.divisors 34 = ([1, 2, 17, 34] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_34_X1000000_row_6 :
    (∑ h ∈ Nat.divisors 34,
      ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 34 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 34) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 34 6 h
                - ramanujanGcdClassWindowAverageRat X0 34 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 34 6 6
                - ramanujanGcdClassWindowAverageRat X0 6 6
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 34 34 h
                + ramanujanGcdClassWindowAverageRat X0 6 6
                    * ramanujanGcdClassWindowAverageRat X0 34 h
                    * evenRamanujanBlockCountRat 6 34))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_34_X1000000_divRight_for_row_6]
  have hset : ([1, 2, 17, 34] : List ℕ).toFinset = periodicMainPair_6_34_X1000000_rowChunk_6_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_34_X1000000_rowPart_6_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
