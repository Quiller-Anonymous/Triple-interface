import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_22_X1000000_term_3_22 :
    ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 22 22
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 22) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 22 3 22
              - ramanujanGcdClassWindowAverageRat X0 22 22
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 22 6 3
              - ramanujanGcdClassWindowAverageRat X0 6 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 22 22 22
              + ramanujanGcdClassWindowAverageRat X0 6 3
                  * ramanujanGcdClassWindowAverageRat X0 22 22
                  * evenRamanujanBlockCountRat 6 22))
      = (0 : ℚ) / 1 := by
  have hCoeffLeft : ramanujanGcdClassCoeffRat 6 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight : ramanujanGcdClassCoeffRat 22 22 = (10 : ℚ) / 1 := by
    native_decide
  have hAvgLeft : ramanujanGcdClassWindowAverageRat X0 6 3 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgRight : ramanujanGcdClassWindowAverageRat X0 22 22 = (455 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 22 6 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockRight : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 22 22 22 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hPair : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 22 3 22 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_zero_of_incompatible]
    norm_num [ramanujanGcdClassJointCompatibility]
  norm_num [H, centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat,
    hCoeffLeft, hCoeffRight, hAvgLeft, hAvgRight,
    hBlockLeft, hBlockRight, hPair]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
