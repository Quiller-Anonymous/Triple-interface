import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_10
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_11
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_22
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_55
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch015Term_2_110

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_110_X1000000_rowChunk_2_0 : Finset ℕ :=
  ([1, 2, 5, 10, 11, 22, 55, 110] : List ℕ).toFinset

def periodicMainPair_6_110_X1000000_rowPartValue_2_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 5 => (0 : ℚ) / 1
| 10 => (0 : ℚ) / 1
| 11 => (0 : ℚ) / 1
| 22 => (0 : ℚ) / 1
| 55 => (0 : ℚ) / 1
| 110 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_110_X1000000_rowPart_2_0 :
    (∑ h ∈ periodicMainPair_6_110_X1000000_rowChunk_2_0,
      ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 110 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 110) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 110 2 h
                - ramanujanGcdClassWindowAverageRat X0 110 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 110 6 2
                - ramanujanGcdClassWindowAverageRat X0 6 2
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 110 110 h
                + ramanujanGcdClassWindowAverageRat X0 6 2
                    * ramanujanGcdClassWindowAverageRat X0 110 h
                    * evenRamanujanBlockCountRat 6 110))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_110_X1000000_rowChunk_2_0,
        ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 110 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 110) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 110 2 h
                  - ramanujanGcdClassWindowAverageRat X0 110 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 110 6 2
                  - ramanujanGcdClassWindowAverageRat X0 6 2
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 110 110 h
                  + ramanujanGcdClassWindowAverageRat X0 6 2
                      * ramanujanGcdClassWindowAverageRat X0 110 h
                      * evenRamanujanBlockCountRat 6 110))
      ) = (∑ h ∈ periodicMainPair_6_110_X1000000_rowChunk_2_0, periodicMainPair_6_110_X1000000_rowPartValue_2_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_110_X1000000_rowChunk_2_0] at hh
    rcases hh with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_1
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_2
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_5
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_10
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_11
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_22
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_55
    · simpa [periodicMainPair_6_110_X1000000_rowPartValue_2_0] using periodicMainPair_6_110_X1000000_term_2_110
  rw [hsum]
  norm_num [periodicMainPair_6_110_X1000000_rowChunk_2_0, periodicMainPair_6_110_X1000000_rowPartValue_2_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
