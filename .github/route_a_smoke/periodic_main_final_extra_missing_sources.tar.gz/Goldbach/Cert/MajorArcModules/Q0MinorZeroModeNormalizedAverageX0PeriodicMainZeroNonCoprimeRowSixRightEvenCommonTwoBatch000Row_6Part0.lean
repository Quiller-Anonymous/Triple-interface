import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch000Term_6_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch000Term_6_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch000Term_6_5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch000Term_6_10

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_10_X1000000_rowChunk_6_0 : Finset ℕ :=
  ([1, 2, 5, 10] : List ℕ).toFinset

def periodicMainPair_6_10_X1000000_rowPartValue_6_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 5 => (0 : ℚ) / 1
| 10 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_10_X1000000_rowPart_6_0 :
    (∑ h ∈ periodicMainPair_6_10_X1000000_rowChunk_6_0,
      ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 10 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 10) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 10 6 h
                - ramanujanGcdClassWindowAverageRat X0 10 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 10 6 6
                - ramanujanGcdClassWindowAverageRat X0 6 6
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 10 10 h
                + ramanujanGcdClassWindowAverageRat X0 6 6
                    * ramanujanGcdClassWindowAverageRat X0 10 h
                    * evenRamanujanBlockCountRat 6 10))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_10_X1000000_rowChunk_6_0,
        ramanujanGcdClassCoeffRat 6 6 * ramanujanGcdClassCoeffRat 10 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 10) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 10 6 h
                  - ramanujanGcdClassWindowAverageRat X0 10 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 10 6 6
                  - ramanujanGcdClassWindowAverageRat X0 6 6
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 10 10 h
                  + ramanujanGcdClassWindowAverageRat X0 6 6
                      * ramanujanGcdClassWindowAverageRat X0 10 h
                      * evenRamanujanBlockCountRat 6 10))
      ) = (∑ h ∈ periodicMainPair_6_10_X1000000_rowChunk_6_0, periodicMainPair_6_10_X1000000_rowPartValue_6_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_10_X1000000_rowChunk_6_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_10_X1000000_rowPartValue_6_0] using periodicMainPair_6_10_X1000000_term_6_1
    · simpa [periodicMainPair_6_10_X1000000_rowPartValue_6_0] using periodicMainPair_6_10_X1000000_term_6_2
    · simpa [periodicMainPair_6_10_X1000000_rowPartValue_6_0] using periodicMainPair_6_10_X1000000_term_6_5
    · simpa [periodicMainPair_6_10_X1000000_rowPartValue_6_0] using periodicMainPair_6_10_X1000000_term_6_10
  rw [hsum]
  norm_num [periodicMainPair_6_10_X1000000_rowChunk_6_0, periodicMainPair_6_10_X1000000_rowPartValue_6_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
