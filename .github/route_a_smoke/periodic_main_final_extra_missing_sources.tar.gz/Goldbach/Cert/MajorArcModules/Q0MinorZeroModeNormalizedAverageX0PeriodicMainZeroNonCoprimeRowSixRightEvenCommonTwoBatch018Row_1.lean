import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch018Row_1Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_130_X1000000_divRight_for_row_1 : Nat.divisors 130 = ([1, 2, 5, 10, 13, 26, 65, 130] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_130_X1000000_row_1 :
    (∑ h ∈ Nat.divisors 130,
      ramanujanGcdClassCoeffRat 6 1 * ramanujanGcdClassCoeffRat 130 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 130) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 130 1 h
                - ramanujanGcdClassWindowAverageRat X0 130 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 6 1
                - ramanujanGcdClassWindowAverageRat X0 6 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 130 130 h
                + ramanujanGcdClassWindowAverageRat X0 6 1
                    * ramanujanGcdClassWindowAverageRat X0 130 h
                    * evenRamanujanBlockCountRat 6 130))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_130_X1000000_divRight_for_row_1]
  have hset : ([1, 2, 5, 10, 13, 26, 65, 130] : List ℕ).toFinset = periodicMainPair_6_130_X1000000_rowChunk_1_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_130_X1000000_rowPart_1_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
