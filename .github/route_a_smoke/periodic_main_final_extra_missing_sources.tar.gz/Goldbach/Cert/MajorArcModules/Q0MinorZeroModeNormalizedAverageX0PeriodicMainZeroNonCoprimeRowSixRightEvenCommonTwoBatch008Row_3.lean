import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch008Row_3Part0

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_6_62_X1000000_divRight_for_row_3 : Nat.divisors 62 = ([1, 2, 31, 62] : List ℕ).toFinset := by
  native_decide

theorem periodicMainPair_6_62_X1000000_row_3 :
    (∑ h ∈ Nat.divisors 62,
      ramanujanGcdClassCoeffRat 6 3 * ramanujanGcdClassCoeffRat 62 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 62) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 62 3 h
                - ramanujanGcdClassWindowAverageRat X0 62 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 6 3
                - ramanujanGcdClassWindowAverageRat X0 6 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 62 62 h
                + ramanujanGcdClassWindowAverageRat X0 6 3
                    * ramanujanGcdClassWindowAverageRat X0 62 h
                    * evenRamanujanBlockCountRat 6 62))
    ) = (0 : ℚ) / 1 := by
  rw [periodicMainPair_6_62_X1000000_divRight_for_row_3]
  have hset : ([1, 2, 31, 62] : List ℕ).toFinset = periodicMainPair_6_62_X1000000_rowChunk_3_0 := by
    native_decide
  rw [hset]
  rw [periodicMainPair_6_62_X1000000_rowPart_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
