import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch003Term_2_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch003Term_2_2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch003Term_2_13
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeRowSixRightEvenCommonTwoBatch003Term_2_26

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_6_26_X1000000_rowChunk_2_0 : Finset ℕ :=
  ([1, 2, 13, 26] : List ℕ).toFinset

def periodicMainPair_6_26_X1000000_rowPartValue_2_0 : ℕ → ℚ
| 1 => (0 : ℚ) / 1
| 2 => (0 : ℚ) / 1
| 13 => (0 : ℚ) / 1
| 26 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_6_26_X1000000_rowPart_2_0 :
    (∑ h ∈ periodicMainPair_6_26_X1000000_rowChunk_2_0,
      ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 26 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 26) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 26 2 h
                - ramanujanGcdClassWindowAverageRat X0 26 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 26 6 2
                - ramanujanGcdClassWindowAverageRat X0 6 2
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 26 26 h
                + ramanujanGcdClassWindowAverageRat X0 6 2
                    * ramanujanGcdClassWindowAverageRat X0 26 h
                    * evenRamanujanBlockCountRat 6 26))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_6_26_X1000000_rowChunk_2_0,
        ramanujanGcdClassCoeffRat 6 2 * ramanujanGcdClassCoeffRat 26 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 6 26) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 6 26 2 h
                  - ramanujanGcdClassWindowAverageRat X0 26 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 26 6 2
                  - ramanujanGcdClassWindowAverageRat X0 6 2
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 6 26 26 h
                  + ramanujanGcdClassWindowAverageRat X0 6 2
                      * ramanujanGcdClassWindowAverageRat X0 26 h
                      * evenRamanujanBlockCountRat 6 26))
      ) = (∑ h ∈ periodicMainPair_6_26_X1000000_rowChunk_2_0, periodicMainPair_6_26_X1000000_rowPartValue_2_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_6_26_X1000000_rowChunk_2_0] at hh
    rcases hh with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_6_26_X1000000_rowPartValue_2_0] using periodicMainPair_6_26_X1000000_term_2_1
    · simpa [periodicMainPair_6_26_X1000000_rowPartValue_2_0] using periodicMainPair_6_26_X1000000_term_2_2
    · simpa [periodicMainPair_6_26_X1000000_rowPartValue_2_0] using periodicMainPair_6_26_X1000000_term_2_13
    · simpa [periodicMainPair_6_26_X1000000_rowPartValue_2_0] using periodicMainPair_6_26_X1000000_term_2_26
  rw [hsum]
  norm_num [periodicMainPair_6_26_X1000000_rowChunk_2_0, periodicMainPair_6_26_X1000000_rowPartValue_2_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
