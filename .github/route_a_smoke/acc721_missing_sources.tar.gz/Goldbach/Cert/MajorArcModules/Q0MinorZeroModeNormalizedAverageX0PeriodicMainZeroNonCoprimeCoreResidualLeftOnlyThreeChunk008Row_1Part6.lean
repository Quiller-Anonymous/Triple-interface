import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Term_1_77

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_154_X1000000_rowChunk_1_6 : Finset ℕ :=
  ([77] : List ℕ).toFinset

def periodicMainPair_21_154_X1000000_rowPartValue_1_6 : ℕ → ℚ
| 77 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_21_154_X1000000_rowPart_1_6 :
    (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_1_6,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 154 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 1 h
                - ramanujanGcdClassWindowAverageRat X0 154 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 154 h
                    * evenRamanujanBlockCountRat 21 154))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_1_6,
        ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 154 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 1 h
                  - ramanujanGcdClassWindowAverageRat X0 154 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 1
                  - ramanujanGcdClassWindowAverageRat X0 21 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                  + ramanujanGcdClassWindowAverageRat X0 21 1
                      * ramanujanGcdClassWindowAverageRat X0 154 h
                      * evenRamanujanBlockCountRat 21 154))
      ) = (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_1_6, periodicMainPair_21_154_X1000000_rowPartValue_1_6 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_154_X1000000_rowChunk_1_6] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_154_X1000000_rowPartValue_1_6] using periodicMainPair_21_154_X1000000_term_1_77
  rw [hsum]
  norm_num [periodicMainPair_21_154_X1000000_rowChunk_1_6, periodicMainPair_21_154_X1000000_rowPartValue_1_6]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
