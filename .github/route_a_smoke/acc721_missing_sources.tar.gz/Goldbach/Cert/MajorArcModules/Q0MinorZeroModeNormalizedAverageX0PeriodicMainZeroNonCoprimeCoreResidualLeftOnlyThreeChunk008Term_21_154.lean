import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_154_X1000000_term_21_154 :
    ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 154 154
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 21 154
              - ramanujanGcdClassWindowAverageRat X0 154 154
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 21
              - ramanujanGcdClassWindowAverageRat X0 21 21
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 154
              + ramanujanGcdClassWindowAverageRat X0 21 21
                  * ramanujanGcdClassWindowAverageRat X0 154 154
                  * evenRamanujanBlockCountRat 21 154))
      = (34299427200 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
