import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk060
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk061
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk062
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk063
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk064
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk065
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk066
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk067
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk068
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk069

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 060..069. -/

def PeriodicMainZeroCoprimeCoreResidualGroup006Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk060Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk061Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk062Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk063Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk064Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk065Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk066Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk067Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk068Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk069Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup006_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup006Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk060Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk061Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk062Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk063Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk064Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk065Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk066Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk067Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk068Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk069Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk060_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk061_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk062_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk063_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk064_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk065_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk066_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk067_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk068_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk069_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
