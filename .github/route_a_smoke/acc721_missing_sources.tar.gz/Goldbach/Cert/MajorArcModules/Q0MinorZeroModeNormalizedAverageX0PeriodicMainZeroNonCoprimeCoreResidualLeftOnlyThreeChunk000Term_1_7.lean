import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_7_X1000000_term_1_7 :
    ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 7 7
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 7) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 7 1 7
              - ramanujanGcdClassWindowAverageRat X0 7 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 21 1
              - ramanujanGcdClassWindowAverageRat X0 21 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 7 7
              + ramanujanGcdClassWindowAverageRat X0 21 1
                  * ramanujanGcdClassWindowAverageRat X0 7 7
                  * evenRamanujanBlockCountRat 21 7))
      = (-6802720680 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
