import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part4
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part6
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_21Part7

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_154_X1000000_divRight_for_row_21 : Nat.divisors 154 = ([1, 2, 7, 11, 14, 22, 77, 154] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_154_X1000000_row_21 :
    (∑ h ∈ Nat.divisors 154,
      ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 154 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 21 h
                - ramanujanGcdClassWindowAverageRat X0 154 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 21
                - ramanujanGcdClassWindowAverageRat X0 21 21
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                + ramanujanGcdClassWindowAverageRat X0 21 21
                    * ramanujanGcdClassWindowAverageRat X0 154 h
                    * evenRamanujanBlockCountRat 21 154))
    ) = (-2640 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_154_X1000000_divRight_for_row_21]
  have hset : ([1, 2, 7, 11, 14, 22, 77, 154] : List ℕ).toFinset = (((((((periodicMainPair_21_154_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_5) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_6) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_7) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((((((periodicMainPair_21_154_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_5) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_6) periodicMainPair_21_154_X1000000_rowChunk_21_7)]
  rw [Finset.sum_union (by native_decide : Disjoint (((((periodicMainPair_21_154_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_5) periodicMainPair_21_154_X1000000_rowChunk_21_6)]
  rw [Finset.sum_union (by native_decide : Disjoint ((((periodicMainPair_21_154_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_4) periodicMainPair_21_154_X1000000_rowChunk_21_5)]
  rw [Finset.sum_union (by native_decide : Disjoint (((periodicMainPair_21_154_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_3) periodicMainPair_21_154_X1000000_rowChunk_21_4)]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_154_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_21_2) periodicMainPair_21_154_X1000000_rowChunk_21_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_154_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_21_1) periodicMainPair_21_154_X1000000_rowChunk_21_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_154_X1000000_rowChunk_21_0 periodicMainPair_21_154_X1000000_rowChunk_21_1)]
  rw [periodicMainPair_21_154_X1000000_rowPart_21_0, periodicMainPair_21_154_X1000000_rowPart_21_1, periodicMainPair_21_154_X1000000_rowPart_21_2, periodicMainPair_21_154_X1000000_rowPart_21_3, periodicMainPair_21_154_X1000000_rowPart_21_4, periodicMainPair_21_154_X1000000_rowPart_21_5, periodicMainPair_21_154_X1000000_rowPart_21_6, periodicMainPair_21_154_X1000000_rowPart_21_7]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
