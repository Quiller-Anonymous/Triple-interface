import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk004Term_1_7

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_77_X1000000_rowChunk_1_1 : Finset ℕ :=
  ([7] : List ℕ).toFinset

def periodicMainPair_21_77_X1000000_rowPartValue_1_1 : ℕ → ℚ
| 7 => (6002400684 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_77_X1000000_rowPart_1_1 :
    (∑ h ∈ periodicMainPair_21_77_X1000000_rowChunk_1_1,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 77 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 77) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 77 1 h
                - ramanujanGcdClassWindowAverageRat X0 77 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 77 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 77 h
                    * evenRamanujanBlockCountRat 21 77))
    ) = (6002400684 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_77_X1000000_rowChunk_1_1,
        ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 77 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 77) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 77 1 h
                  - ramanujanGcdClassWindowAverageRat X0 77 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 21 1
                  - ramanujanGcdClassWindowAverageRat X0 21 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 77 h
                  + ramanujanGcdClassWindowAverageRat X0 21 1
                      * ramanujanGcdClassWindowAverageRat X0 77 h
                      * evenRamanujanBlockCountRat 21 77))
      ) = (∑ h ∈ periodicMainPair_21_77_X1000000_rowChunk_1_1, periodicMainPair_21_77_X1000000_rowPartValue_1_1 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_77_X1000000_rowChunk_1_1] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_77_X1000000_rowPartValue_1_1] using periodicMainPair_21_77_X1000000_term_1_7
  rw [hsum]
  norm_num [periodicMainPair_21_77_X1000000_rowChunk_1_1, periodicMainPair_21_77_X1000000_rowPartValue_1_1]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
