import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_91_X1000000_term_3_7 :
    ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 91 7
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 91) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 91 3 7
              - ramanujanGcdClassWindowAverageRat X0 91 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 21 3
              - ramanujanGcdClassWindowAverageRat X0 21 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 91 7
              + ramanujanGcdClassWindowAverageRat X0 21 3
                  * ramanujanGcdClassWindowAverageRat X0 91 7
                  * evenRamanujanBlockCountRat 21 91))
      = (-6173897832 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
