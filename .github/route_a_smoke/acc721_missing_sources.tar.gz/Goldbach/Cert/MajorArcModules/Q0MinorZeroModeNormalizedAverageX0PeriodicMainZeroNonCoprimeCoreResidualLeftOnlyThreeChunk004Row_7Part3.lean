import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk004Term_7_77

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_77_X1000000_rowChunk_7_3 : Finset ℕ :=
  ([77] : List ℕ).toFinset

def periodicMainPair_21_77_X1000000_rowPartValue_7_3 : ℕ → ℚ
| 77 => (-36014398560 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_77_X1000000_rowPart_7_3 :
    (∑ h ∈ periodicMainPair_21_77_X1000000_rowChunk_7_3,
      ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 77 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 77) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 77 7 h
                - ramanujanGcdClassWindowAverageRat X0 77 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 21 7
                - ramanujanGcdClassWindowAverageRat X0 21 7
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 77 h
                + ramanujanGcdClassWindowAverageRat X0 21 7
                    * ramanujanGcdClassWindowAverageRat X0 77 h
                    * evenRamanujanBlockCountRat 21 77))
    ) = (-36014398560 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_77_X1000000_rowChunk_7_3,
        ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 77 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 77) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 77 7 h
                  - ramanujanGcdClassWindowAverageRat X0 77 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 21 7
                  - ramanujanGcdClassWindowAverageRat X0 21 7
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 77 h
                  + ramanujanGcdClassWindowAverageRat X0 21 7
                      * ramanujanGcdClassWindowAverageRat X0 77 h
                      * evenRamanujanBlockCountRat 21 77))
      ) = (∑ h ∈ periodicMainPair_21_77_X1000000_rowChunk_7_3, periodicMainPair_21_77_X1000000_rowPartValue_7_3 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_77_X1000000_rowChunk_7_3] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_77_X1000000_rowPartValue_7_3] using periodicMainPair_21_77_X1000000_term_7_77
  rw [hsum]
  norm_num [periodicMainPair_21_77_X1000000_rowChunk_7_3, periodicMainPair_21_77_X1000000_rowPartValue_7_3]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
