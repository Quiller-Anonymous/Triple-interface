import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk001Term_1_7

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_14_X1000000_rowChunk_1_2 : Finset ℕ :=
  ([7] : List ℕ).toFinset

def periodicMainPair_21_14_X1000000_rowPartValue_1_2 : ℕ → ℚ
| 7 => (0 : ℚ) / 1
| _ => 0

theorem periodicMainPair_21_14_X1000000_rowPart_1_2 :
    (∑ h ∈ periodicMainPair_21_14_X1000000_rowChunk_1_2,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 14 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 14) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 14 1 h
                - ramanujanGcdClassWindowAverageRat X0 14 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 14 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 14 14 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 14 h
                    * evenRamanujanBlockCountRat 21 14))
    ) = (0 : ℚ) / 1 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_14_X1000000_rowChunk_1_2,
        ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 14 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 14) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 14 1 h
                  - ramanujanGcdClassWindowAverageRat X0 14 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 14 21 1
                  - ramanujanGcdClassWindowAverageRat X0 21 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 14 14 h
                  + ramanujanGcdClassWindowAverageRat X0 21 1
                      * ramanujanGcdClassWindowAverageRat X0 14 h
                      * evenRamanujanBlockCountRat 21 14))
      ) = (∑ h ∈ periodicMainPair_21_14_X1000000_rowChunk_1_2, periodicMainPair_21_14_X1000000_rowPartValue_1_2 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_14_X1000000_rowChunk_1_2] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_14_X1000000_rowPartValue_1_2] using periodicMainPair_21_14_X1000000_term_1_7
  rw [hsum]
  norm_num [periodicMainPair_21_14_X1000000_rowChunk_1_2, periodicMainPair_21_14_X1000000_rowPartValue_1_2]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
