import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk002Term_7_5

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_35_X1000000_rowChunk_7_1 : Finset ℕ :=
  ([5] : List ℕ).toFinset

def periodicMainPair_21_35_X1000000_rowPartValue_7_1 : ℕ → ℚ
| 5 => (-5373579936 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_35_X1000000_rowPart_7_1 :
    (∑ h ∈ periodicMainPair_21_35_X1000000_rowChunk_7_1,
      ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 35 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 35) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 35 7 h
                - ramanujanGcdClassWindowAverageRat X0 35 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 21 7
                - ramanujanGcdClassWindowAverageRat X0 21 7
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 35 h
                + ramanujanGcdClassWindowAverageRat X0 21 7
                    * ramanujanGcdClassWindowAverageRat X0 35 h
                    * evenRamanujanBlockCountRat 21 35))
    ) = (-5373579936 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_35_X1000000_rowChunk_7_1,
        ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 35 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 35) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 35 7 h
                  - ramanujanGcdClassWindowAverageRat X0 35 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 21 7
                  - ramanujanGcdClassWindowAverageRat X0 21 7
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 35 h
                  + ramanujanGcdClassWindowAverageRat X0 21 7
                      * ramanujanGcdClassWindowAverageRat X0 35 h
                      * evenRamanujanBlockCountRat 21 35))
      ) = (∑ h ∈ periodicMainPair_21_35_X1000000_rowChunk_7_1, periodicMainPair_21_35_X1000000_rowPartValue_7_1 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_35_X1000000_rowChunk_7_1] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_35_X1000000_rowPartValue_7_1] using periodicMainPair_21_35_X1000000_term_7_5
  rw [hsum]
  norm_num [periodicMainPair_21_35_X1000000_rowChunk_7_1, periodicMainPair_21_35_X1000000_rowPartValue_7_1]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
