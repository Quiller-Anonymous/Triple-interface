import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk000
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk001
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk002
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk003
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk004
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk005
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk006
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk007
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk008
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk009

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 000..009. -/

def PeriodicMainZeroCoprimeCoreResidualGroup000Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk000Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk001Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk002Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk003Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk004Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk005Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk006Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk007Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk008Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk009Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup000_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup000Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk000Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk001Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk002Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk003Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk004Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk005Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk006Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk007Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk008Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk009Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk000_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk001_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk002_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk003_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk004_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk005_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk006_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk007_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk008_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk009_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
