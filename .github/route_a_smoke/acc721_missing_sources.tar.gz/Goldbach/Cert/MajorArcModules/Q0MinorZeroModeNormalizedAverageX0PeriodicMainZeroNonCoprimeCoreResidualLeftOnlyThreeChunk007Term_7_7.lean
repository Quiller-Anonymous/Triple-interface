import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_133_X1000000_term_7_7 :
    ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 133 7
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 133) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 133 7 7
              - ramanujanGcdClassWindowAverageRat X0 133 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 21 7
              - ramanujanGcdClassWindowAverageRat X0 21 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 133 7
              + ramanujanGcdClassWindowAverageRat X0 21 7
                  * ramanujanGcdClassWindowAverageRat X0 133 7
                  * evenRamanujanBlockCountRat 21 133))
      = (37043383392 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
