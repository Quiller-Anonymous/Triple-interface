import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Term_21_19

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_133_X1000000_rowChunk_21_2 : Finset ℕ :=
  ([19] : List ℕ).toFinset

def periodicMainPair_21_133_X1000000_rowPartValue_21_2 : ℕ → ℚ
| 19 => (6173903808 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_133_X1000000_rowPart_21_2 :
    (∑ h ∈ periodicMainPair_21_133_X1000000_rowChunk_21_2,
      ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 133 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 133) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 133 21 h
                - ramanujanGcdClassWindowAverageRat X0 133 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 21 21
                - ramanujanGcdClassWindowAverageRat X0 21 21
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 133 h
                + ramanujanGcdClassWindowAverageRat X0 21 21
                    * ramanujanGcdClassWindowAverageRat X0 133 h
                    * evenRamanujanBlockCountRat 21 133))
    ) = (6173903808 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_133_X1000000_rowChunk_21_2,
        ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 133 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 133) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 133 21 h
                  - ramanujanGcdClassWindowAverageRat X0 133 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 21 21
                  - ramanujanGcdClassWindowAverageRat X0 21 21
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 133 h
                  + ramanujanGcdClassWindowAverageRat X0 21 21
                      * ramanujanGcdClassWindowAverageRat X0 133 h
                      * evenRamanujanBlockCountRat 21 133))
      ) = (∑ h ∈ periodicMainPair_21_133_X1000000_rowChunk_21_2, periodicMainPair_21_133_X1000000_rowPartValue_21_2 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_133_X1000000_rowChunk_21_2] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_133_X1000000_rowPartValue_21_2] using periodicMainPair_21_133_X1000000_term_21_19
  rw [hsum]
  norm_num [periodicMainPair_21_133_X1000000_rowChunk_21_2, periodicMainPair_21_133_X1000000_rowPartValue_21_2]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
