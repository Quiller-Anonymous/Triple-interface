import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_35_X1000000_term_3_35 :
    ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 35 35
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 35) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 35 3 35
              - ramanujanGcdClassWindowAverageRat X0 35 35
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 21 3
              - ramanujanGcdClassWindowAverageRat X0 21 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 35 35
              + ramanujanGcdClassWindowAverageRat X0 21 3
                  * ramanujanGcdClassWindowAverageRat X0 35 35
                  * evenRamanujanBlockCountRat 21 35))
      = (5373576928 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
