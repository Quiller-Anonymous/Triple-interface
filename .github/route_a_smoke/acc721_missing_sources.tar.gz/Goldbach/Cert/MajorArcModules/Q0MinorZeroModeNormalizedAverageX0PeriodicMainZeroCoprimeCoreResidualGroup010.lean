import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk100
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk101
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk102
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk103
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk104
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk105
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk106
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk107
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk108
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk109

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 100..109. -/

def PeriodicMainZeroCoprimeCoreResidualGroup010Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk100Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk101Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk102Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk103Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk104Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk105Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk106Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk107Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk108Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk109Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup010_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup010Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk100Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk101Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk102Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk103Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk104Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk105Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk106Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk107Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk108Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk109Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk100_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk101_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk102_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk103_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk104_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk105_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk106_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk107_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk108_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk109_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
