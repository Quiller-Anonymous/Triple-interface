import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk110
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk111
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk112
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk113
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk114
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk115
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk116
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk117
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk118
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk119

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 110..119. -/

def PeriodicMainZeroCoprimeCoreResidualGroup011Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk110Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk111Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk112Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk113Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk114Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk115Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk116Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk117Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk118Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk119Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup011_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup011Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk110Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk111Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk112Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk113Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk114Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk115Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk116Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk117Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk118Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk119Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk110_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk111_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk112_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk113_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk114_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk115_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk116_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk117_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk118_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk119_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
