import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk005Term_1_91

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_91_X1000000_rowChunk_1_3 : Finset ℕ :=
  ([91] : List ℕ).toFinset

def periodicMainPair_21_91_X1000000_rowPartValue_1_3 : ℕ → ℚ
| 91 => (-6173896896 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_91_X1000000_rowPart_1_3 :
    (∑ h ∈ periodicMainPair_21_91_X1000000_rowChunk_1_3,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 91 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 91) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 91 1 h
                - ramanujanGcdClassWindowAverageRat X0 91 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 91 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 91 h
                    * evenRamanujanBlockCountRat 21 91))
    ) = (-6173896896 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_91_X1000000_rowChunk_1_3,
        ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 91 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 91) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 91 1 h
                  - ramanujanGcdClassWindowAverageRat X0 91 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 21 1
                  - ramanujanGcdClassWindowAverageRat X0 21 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 91 h
                  + ramanujanGcdClassWindowAverageRat X0 21 1
                      * ramanujanGcdClassWindowAverageRat X0 91 h
                      * evenRamanujanBlockCountRat 21 91))
      ) = (∑ h ∈ periodicMainPair_21_91_X1000000_rowChunk_1_3, periodicMainPair_21_91_X1000000_rowPartValue_1_3 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_91_X1000000_rowChunk_1_3] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_91_X1000000_rowPartValue_1_3] using periodicMainPair_21_91_X1000000_term_1_91
  rw [hsum]
  norm_num [periodicMainPair_21_91_X1000000_rowChunk_1_3, periodicMainPair_21_91_X1000000_rowPartValue_1_3]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
