import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated periodic-main ordered-record proofs for selected JSON indices [530,535). -/

theorem periodicMainPair_214_21_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 214 21 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 214 = ([1, 2, 107, 214] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 21 = ([1, 3, 7, 21] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 214 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_2 : ramanujanGcdClassCoeffRat 214 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_107 : ramanujanGcdClassCoeffRat 214 107 = (-106 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_214 : ramanujanGcdClassCoeffRat 214 214 = (106 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 21 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 21 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_7 : ramanujanGcdClassCoeffRat 21 7 = (-6 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_21 : ramanujanGcdClassCoeffRat 21 21 = (12 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 214 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_2 : ramanujanGcdClassWindowAverageRat X0 214 2 = (4954 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_107 : ramanujanGcdClassWindowAverageRat X0 214 107 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_214 : ramanujanGcdClassWindowAverageRat X0 214 214 = (47 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 21 1 = (2858 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 21 3 = (1429 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_7 : ramanujanGcdClassWindowAverageRat X0 21 7 = (476 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_21 : ramanujanGcdClassWindowAverageRat X0 21 21 = (238 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 214 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_2 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 214 2 = (4452 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_107 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 214 107 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_214 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 214 214 = (42 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 21 1 = (2568 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 21 3 = (1284 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_7 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 21 7 = (428 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_21 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 214 21 21 21 = (214 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 1 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 1 7 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 1 21 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 2 1 = (2544 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 2 3 = (1272 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 2 7 = (424 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 2 21 = (212 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_107_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 107 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_107_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 107 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_107_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 107 7 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_107_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 107 21 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_214_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 214 1 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_214_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 214 3 = (12 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_214_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 214 7 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_214_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 214 21 214 21 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_2, hCoeffLeft_107, hCoeffLeft_214, hCoeffRight_1, hCoeffRight_3, hCoeffRight_7, hCoeffRight_21, hAvgLeft_1, hAvgLeft_2, hAvgLeft_107, hAvgLeft_214, hAvgRight_1, hAvgRight_3, hAvgRight_7, hAvgRight_21, hBlockLeft_1, hBlockLeft_2, hBlockLeft_107, hBlockLeft_214, hBlockRight_1, hBlockRight_3, hBlockRight_7, hBlockRight_21, hPair_1_1, hPair_1_3, hPair_1_7, hPair_1_21, hPair_2_1, hPair_2_3, hPair_2_7, hPair_2_21, hPair_107_1, hPair_107_3, hPair_107_7, hPair_107_21, hPair_214_1, hPair_214_3, hPair_214_7, hPair_214_21]

theorem periodicMainPair_214_21_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 214 21) = (0 : ℚ) / 1 := by
  have hneq : 214 ≠ 21 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 214 = (5 : ℚ) / 11236 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 21 = (5 : ℚ) / 144 := by
    native_decide
  have hvalue : ((5 : ℚ) / 11236) * ((5 : ℚ) / 144) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_214_21_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_215_21_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 215 21 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 215 = ([1, 5, 43, 215] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 21 = ([1, 3, 7, 21] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 215 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_5 : ramanujanGcdClassCoeffRat 215 5 = (-4 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_43 : ramanujanGcdClassCoeffRat 215 43 = (-42 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_215 : ramanujanGcdClassCoeffRat 215 215 = (168 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 21 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 21 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_7 : ramanujanGcdClassCoeffRat 21 7 = (-6 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_21 : ramanujanGcdClassCoeffRat 21 21 = (12 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 215 1 = (1302 : ℚ) / 1667 := by
    native_decide
  have hAvgLeft_5 : ramanujanGcdClassWindowAverageRat X0 215 5 = (326 : ℚ) / 1667 := by
    native_decide
  have hAvgLeft_43 : ramanujanGcdClassWindowAverageRat X0 215 43 = (94 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_215 : ramanujanGcdClassWindowAverageRat X0 215 215 = (23 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 21 1 = (2858 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 21 3 = (1429 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_7 : ramanujanGcdClassWindowAverageRat X0 21 7 = (476 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_21 : ramanujanGcdClassWindowAverageRat X0 21 21 = (238 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 215 1 = (3528 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_5 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 215 5 = (882 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_43 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 215 43 = (84 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_215 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 215 215 = (21 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 21 1 = (2580 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 21 3 = (1290 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_7 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 21 7 = (430 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_21 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 215 21 21 21 = (215 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 1 1 = (2016 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 1 3 = (1008 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 1 7 = (336 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 1 21 = (168 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_5_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 5 1 = (504 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_5_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 5 3 = (252 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_5_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 5 7 = (84 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_5_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 5 21 = (42 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_43_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 43 1 = (48 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_43_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 43 3 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_43_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 43 7 = (8 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_43_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 43 21 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_215_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 215 1 = (12 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_215_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 215 3 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_215_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 215 7 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_215_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 215 21 215 21 = (1 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_5, hCoeffLeft_43, hCoeffLeft_215, hCoeffRight_1, hCoeffRight_3, hCoeffRight_7, hCoeffRight_21, hAvgLeft_1, hAvgLeft_5, hAvgLeft_43, hAvgLeft_215, hAvgRight_1, hAvgRight_3, hAvgRight_7, hAvgRight_21, hBlockLeft_1, hBlockLeft_5, hBlockLeft_43, hBlockLeft_215, hBlockRight_1, hBlockRight_3, hBlockRight_7, hBlockRight_21, hPair_1_1, hPair_1_3, hPair_1_7, hPair_1_21, hPair_5_1, hPair_5_3, hPair_5_7, hPair_5_21, hPair_43_1, hPair_43_3, hPair_43_7, hPair_43_21, hPair_215_1, hPair_215_3, hPair_215_7, hPair_215_21]

theorem periodicMainPair_215_21_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 215 21) = (0 : ℚ) / 1 := by
  have hneq : 215 ≠ 21 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 215 = (5 : ℚ) / 28224 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 21 = (5 : ℚ) / 144 := by
    native_decide
  have hvalue : ((5 : ℚ) / 28224) * ((5 : ℚ) / 144) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_215_21_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_218_21_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 218 21 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 218 = ([1, 2, 109, 218] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 21 = ([1, 3, 7, 21] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 218 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_2 : ramanujanGcdClassCoeffRat 218 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_109 : ramanujanGcdClassCoeffRat 218 109 = (-108 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_218 : ramanujanGcdClassCoeffRat 218 218 = (108 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 21 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 21 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_7 : ramanujanGcdClassCoeffRat 21 7 = (-6 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_21 : ramanujanGcdClassCoeffRat 21 21 = (12 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 218 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_2 : ramanujanGcdClassWindowAverageRat X0 218 2 = (4955 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_109 : ramanujanGcdClassWindowAverageRat X0 218 109 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_218 : ramanujanGcdClassWindowAverageRat X0 218 218 = (46 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 21 1 = (2858 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 21 3 = (1429 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_7 : ramanujanGcdClassWindowAverageRat X0 21 7 = (476 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_21 : ramanujanGcdClassWindowAverageRat X0 21 21 = (238 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 218 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_2 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 218 2 = (4536 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_109 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 218 109 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_218 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 218 218 = (42 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 21 1 = (2616 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 21 3 = (1308 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_7 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 21 7 = (436 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_21 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 218 21 21 21 = (218 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 1 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 1 7 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 1 21 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 2 1 = (2592 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 2 3 = (1296 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 2 7 = (432 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 2 21 = (216 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_109_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 109 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_109_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 109 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_109_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 109 7 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_109_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 109 21 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_218_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 218 1 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_218_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 218 3 = (12 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_218_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 218 7 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_218_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 218 21 218 21 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_2, hCoeffLeft_109, hCoeffLeft_218, hCoeffRight_1, hCoeffRight_3, hCoeffRight_7, hCoeffRight_21, hAvgLeft_1, hAvgLeft_2, hAvgLeft_109, hAvgLeft_218, hAvgRight_1, hAvgRight_3, hAvgRight_7, hAvgRight_21, hBlockLeft_1, hBlockLeft_2, hBlockLeft_109, hBlockLeft_218, hBlockRight_1, hBlockRight_3, hBlockRight_7, hBlockRight_21, hPair_1_1, hPair_1_3, hPair_1_7, hPair_1_21, hPair_2_1, hPair_2_3, hPair_2_7, hPair_2_21, hPair_109_1, hPair_109_3, hPair_109_7, hPair_109_21, hPair_218_1, hPair_218_3, hPair_218_7, hPair_218_21]

theorem periodicMainPair_218_21_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 218 21) = (0 : ℚ) / 1 := by
  have hneq : 218 ≠ 21 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 218 = (5 : ℚ) / 11664 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 21 = (5 : ℚ) / 144 := by
    native_decide
  have hvalue : ((5 : ℚ) / 11664) * ((5 : ℚ) / 144) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_218_21_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_221_21_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 221 21 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 221 = ([1, 13, 17, 221] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 21 = ([1, 3, 7, 21] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 221 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_13 : ramanujanGcdClassCoeffRat 221 13 = (-12 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_17 : ramanujanGcdClassCoeffRat 221 17 = (-16 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_221 : ramanujanGcdClassCoeffRat 221 221 = (192 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 21 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 21 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_7 : ramanujanGcdClassCoeffRat 21 7 = (-6 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_21 : ramanujanGcdClassCoeffRat 21 21 = (12 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 221 1 = (4345 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_13 : ramanujanGcdClassWindowAverageRat X0 221 13 = (362 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_17 : ramanujanGcdClassWindowAverageRat X0 221 17 = (271 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_221 : ramanujanGcdClassWindowAverageRat X0 221 221 = (23 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 21 1 = (2858 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 21 3 = (1429 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_7 : ramanujanGcdClassWindowAverageRat X0 21 7 = (476 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_21 : ramanujanGcdClassWindowAverageRat X0 21 21 = (238 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 221 1 = (4032 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_13 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 221 13 = (336 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_17 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 221 17 = (252 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_221 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 221 221 = (21 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 21 1 = (2652 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 21 3 = (1326 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_7 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 21 7 = (442 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_21 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 221 21 21 21 = (221 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 1 1 = (2304 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 1 3 = (1152 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 1 7 = (384 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 1 21 = (192 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_13_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 13 1 = (192 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_13_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 13 3 = (96 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_13_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 13 7 = (32 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_13_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 13 21 = (16 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_17_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 17 1 = (144 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_17_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 17 3 = (72 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_17_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 17 7 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_17_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 17 21 = (12 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_221_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 221 1 = (12 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_221_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 221 3 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_221_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 221 7 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_221_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 221 21 221 21 = (1 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_13, hCoeffLeft_17, hCoeffLeft_221, hCoeffRight_1, hCoeffRight_3, hCoeffRight_7, hCoeffRight_21, hAvgLeft_1, hAvgLeft_13, hAvgLeft_17, hAvgLeft_221, hAvgRight_1, hAvgRight_3, hAvgRight_7, hAvgRight_21, hBlockLeft_1, hBlockLeft_13, hBlockLeft_17, hBlockLeft_221, hBlockRight_1, hBlockRight_3, hBlockRight_7, hBlockRight_21, hPair_1_1, hPair_1_3, hPair_1_7, hPair_1_21, hPair_13_1, hPair_13_3, hPair_13_7, hPair_13_21, hPair_17_1, hPair_17_3, hPair_17_7, hPair_17_21, hPair_221_1, hPair_221_3, hPair_221_7, hPair_221_21]

theorem periodicMainPair_221_21_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 221 21) = (0 : ℚ) / 1 := by
  have hneq : 221 ≠ 21 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 221 = (5 : ℚ) / 36864 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 21 = (5 : ℚ) / 144 := by
    native_decide
  have hvalue : ((5 : ℚ) / 36864) * ((5 : ℚ) / 144) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_221_21_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_222_5_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 222 5 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 222 = ([1, 2, 3, 6, 37, 74, 111, 222] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 5 = ([1, 5] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 222 1 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_2 : ramanujanGcdClassCoeffRat 222 2 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_3 : ramanujanGcdClassCoeffRat 222 3 = (2 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_6 : ramanujanGcdClassCoeffRat 222 6 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_37 : ramanujanGcdClassCoeffRat 222 37 = (36 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_74 : ramanujanGcdClassCoeffRat 222 74 = (-36 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_111 : ramanujanGcdClassCoeffRat 222 111 = (-72 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_222 : ramanujanGcdClassCoeffRat 222 222 = (72 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 5 1 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_5 : ramanujanGcdClassCoeffRat 5 5 = (4 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 222 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_2 : ramanujanGcdClassWindowAverageRat X0 222 2 = (3244 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_3 : ramanujanGcdClassWindowAverageRat X0 222 3 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_6 : ramanujanGcdClassWindowAverageRat X0 222 6 = (1622 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_37 : ramanujanGcdClassWindowAverageRat X0 222 37 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_74 : ramanujanGcdClassWindowAverageRat X0 222 74 = (30 : ℚ) / 1667 := by
    native_decide
  have hAvgLeft_111 : ramanujanGcdClassWindowAverageRat X0 222 111 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_222 : ramanujanGcdClassWindowAverageRat X0 222 222 = (15 : ℚ) / 1667 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 5 1 = (4000 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_5 : ramanujanGcdClassWindowAverageRat X0 5 5 = (1001 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_2 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 2 = (720 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_6 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 6 = (360 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_37 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 37 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_74 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 74 = (20 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_111 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 111 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_222 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 222 222 = (10 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 5 1 = (888 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_5 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 222 5 5 5 = (222 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 1 5 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 2 1 = (576 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 2 5 = (144 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_3_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 3 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_3_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 3 5 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_6_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 6 1 = (288 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_6_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 6 5 = (72 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_37_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 37 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_37_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 37 5 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_74_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 74 1 = (16 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_74_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 74 5 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_111_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 111 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_111_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 111 5 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_222_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 222 1 = (8 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_222_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 222 5 222 5 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_2, hCoeffLeft_3, hCoeffLeft_6, hCoeffLeft_37, hCoeffLeft_74, hCoeffLeft_111, hCoeffLeft_222, hCoeffRight_1, hCoeffRight_5, hAvgLeft_1, hAvgLeft_2, hAvgLeft_3, hAvgLeft_6, hAvgLeft_37, hAvgLeft_74, hAvgLeft_111, hAvgLeft_222, hAvgRight_1, hAvgRight_5, hBlockLeft_1, hBlockLeft_2, hBlockLeft_3, hBlockLeft_6, hBlockLeft_37, hBlockLeft_74, hBlockLeft_111, hBlockLeft_222, hBlockRight_1, hBlockRight_5, hPair_1_1, hPair_1_5, hPair_2_1, hPair_2_5, hPair_3_1, hPair_3_5, hPair_6_1, hPair_6_5, hPair_37_1, hPair_37_5, hPair_74_1, hPair_74_5, hPair_111_1, hPair_111_5, hPair_222_1, hPair_222_5]

theorem periodicMainPair_222_5_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 222 5) = (0 : ℚ) / 1 := by
  have hneq : 222 ≠ 5 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 222 = (5 : ℚ) / 5184 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 5 = (5 : ℚ) / 16 := by
    native_decide
  have hvalue : ((5 : ℚ) / 5184) * ((5 : ℚ) / 16) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_222_5_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsZeroCoprimeCoreResidualChunk106Pairs : Finset (ℕ × ℕ) :=
  [(214, 21), (215, 21), (218, 21), (221, 21), (222, 5)].toFinset

theorem PeriodicMainRecordsZeroCoprimeCoreResidualChunk106_value_on_records :
    ∀ p ∈ PeriodicMainRecordsZeroCoprimeCoreResidualChunk106Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsZeroCoprimeCoreResidualChunk106Pairs] at hp
  rcases hp with h | h | h | h | h
  · subst p
    simpa using periodicMainPair_214_21_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_215_21_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_218_21_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_221_21_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_222_5_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
