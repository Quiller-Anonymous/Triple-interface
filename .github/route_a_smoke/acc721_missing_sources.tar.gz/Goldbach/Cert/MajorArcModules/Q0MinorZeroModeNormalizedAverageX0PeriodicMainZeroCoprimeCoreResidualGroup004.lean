import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk040
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk041
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk042
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk043
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk044
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk045
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk046
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk047
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk048
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk049

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 040..049. -/

def PeriodicMainZeroCoprimeCoreResidualGroup004Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk040Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk041Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk042Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk043Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk044Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk045Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk046Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk047Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk048Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk049Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup004_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup004Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk040Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk041Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk042Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk043Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk044Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk045Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk046Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk047Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk048Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk049Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk040_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk041_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk042_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk043_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk044_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk045_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk046_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk047_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk048_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk049_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
