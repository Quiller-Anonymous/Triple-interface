import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk003Term_3_2

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_70_X1000000_rowChunk_3_1 : Finset ℕ :=
  ([2] : List ℕ).toFinset

def periodicMainPair_21_70_X1000000_rowPartValue_3_1 : ℕ → ℚ
| 2 => (-876540948 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_70_X1000000_rowPart_3_1 :
    (∑ h ∈ periodicMainPair_21_70_X1000000_rowChunk_3_1,
      ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 70 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 70) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 70 3 h
                - ramanujanGcdClassWindowAverageRat X0 70 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 21 3
                - ramanujanGcdClassWindowAverageRat X0 21 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 70 h
                + ramanujanGcdClassWindowAverageRat X0 21 3
                    * ramanujanGcdClassWindowAverageRat X0 70 h
                    * evenRamanujanBlockCountRat 21 70))
    ) = (-876540948 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_70_X1000000_rowChunk_3_1,
        ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 70 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 70) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 70 3 h
                  - ramanujanGcdClassWindowAverageRat X0 70 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 21 3
                  - ramanujanGcdClassWindowAverageRat X0 21 3
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 70 h
                  + ramanujanGcdClassWindowAverageRat X0 21 3
                      * ramanujanGcdClassWindowAverageRat X0 70 h
                      * evenRamanujanBlockCountRat 21 70))
      ) = (∑ h ∈ periodicMainPair_21_70_X1000000_rowChunk_3_1, periodicMainPair_21_70_X1000000_rowPartValue_3_1 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_70_X1000000_rowChunk_3_1] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_70_X1000000_rowPartValue_3_1] using periodicMainPair_21_70_X1000000_term_3_2
  rw [hsum]
  norm_num [periodicMainPair_21_70_X1000000_rowChunk_3_1, periodicMainPair_21_70_X1000000_rowPartValue_3_1]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
