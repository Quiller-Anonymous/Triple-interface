import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_35_X1000000_term_1_1 :
    ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 35 1
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 35) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 35 1 1
              - ramanujanGcdClassWindowAverageRat X0 35 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 21 1
              - ramanujanGcdClassWindowAverageRat X0 21 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 35 1
              + ramanujanGcdClassWindowAverageRat X0 21 1
                  * ramanujanGcdClassWindowAverageRat X0 35 1
                  * evenRamanujanBlockCountRat 21 35))
      = (895596186 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
