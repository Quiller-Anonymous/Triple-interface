import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part4
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part6
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_1Part7

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_154_X1000000_divRight_for_row_1 : Nat.divisors 154 = ([1, 2, 7, 11, 14, 22, 77, 154] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_154_X1000000_row_1 :
    (∑ h ∈ Nat.divisors 154,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 154 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 1 h
                - ramanujanGcdClassWindowAverageRat X0 154 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 154 h
                    * evenRamanujanBlockCountRat 21 154))
    ) = (440 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_154_X1000000_divRight_for_row_1]
  have hset : ([1, 2, 7, 11, 14, 22, 77, 154] : List ℕ).toFinset = (((((((periodicMainPair_21_154_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_5) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_6) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_7) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((((((periodicMainPair_21_154_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_5) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_6) periodicMainPair_21_154_X1000000_rowChunk_1_7)]
  rw [Finset.sum_union (by native_decide : Disjoint (((((periodicMainPair_21_154_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_5) periodicMainPair_21_154_X1000000_rowChunk_1_6)]
  rw [Finset.sum_union (by native_decide : Disjoint ((((periodicMainPair_21_154_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_4) periodicMainPair_21_154_X1000000_rowChunk_1_5)]
  rw [Finset.sum_union (by native_decide : Disjoint (((periodicMainPair_21_154_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_3) periodicMainPair_21_154_X1000000_rowChunk_1_4)]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_154_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_1_2) periodicMainPair_21_154_X1000000_rowChunk_1_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_154_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_1_1) periodicMainPair_21_154_X1000000_rowChunk_1_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_154_X1000000_rowChunk_1_0 periodicMainPair_21_154_X1000000_rowChunk_1_1)]
  rw [periodicMainPair_21_154_X1000000_rowPart_1_0, periodicMainPair_21_154_X1000000_rowPart_1_1, periodicMainPair_21_154_X1000000_rowPart_1_2, periodicMainPair_21_154_X1000000_rowPart_1_3, periodicMainPair_21_154_X1000000_rowPart_1_4, periodicMainPair_21_154_X1000000_rowPart_1_5, periodicMainPair_21_154_X1000000_rowPart_1_6, periodicMainPair_21_154_X1000000_rowPart_1_7]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
