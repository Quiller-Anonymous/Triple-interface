import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_77_X1000000_term_21_11 :
    ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 77 11
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 77) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 77 21 11
              - ramanujanGcdClassWindowAverageRat X0 77 11
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 21 21
              - ramanujanGcdClassWindowAverageRat X0 21 21
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 77 11
              + ramanujanGcdClassWindowAverageRat X0 21 21
                  * ramanujanGcdClassWindowAverageRat X0 77 11
                  * evenRamanujanBlockCountRat 21 77))
      = (6002403120 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
