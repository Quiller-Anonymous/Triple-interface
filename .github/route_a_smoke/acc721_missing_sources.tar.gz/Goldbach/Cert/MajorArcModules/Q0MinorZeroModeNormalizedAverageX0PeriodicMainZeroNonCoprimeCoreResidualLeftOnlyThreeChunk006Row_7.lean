import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk006Row_7Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk006Row_7Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk006Row_7Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk006Row_7Part3

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_119_X1000000_divRight_for_row_7 : Nat.divisors 119 = ([1, 7, 17, 119] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_119_X1000000_row_7 :
    (∑ h ∈ Nat.divisors 119,
      ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 119 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 119) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 119 7 h
                - ramanujanGcdClassWindowAverageRat X0 119 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 21 7
                - ramanujanGcdClassWindowAverageRat X0 21 7
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 119 h
                + ramanujanGcdClassWindowAverageRat X0 21 7
                    * ramanujanGcdClassWindowAverageRat X0 119 h
                    * evenRamanujanBlockCountRat 21 119))
    ) = (2856 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_119_X1000000_divRight_for_row_7]
  have hset : ([1, 7, 17, 119] : List ℕ).toFinset = (((periodicMainPair_21_119_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_119_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_119_X1000000_rowChunk_7_2) ∪ periodicMainPair_21_119_X1000000_rowChunk_7_3) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_119_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_119_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_119_X1000000_rowChunk_7_2) periodicMainPair_21_119_X1000000_rowChunk_7_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_119_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_119_X1000000_rowChunk_7_1) periodicMainPair_21_119_X1000000_rowChunk_7_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_119_X1000000_rowChunk_7_0 periodicMainPair_21_119_X1000000_rowChunk_7_1)]
  rw [periodicMainPair_21_119_X1000000_rowPart_7_0, periodicMainPair_21_119_X1000000_rowPart_7_1, periodicMainPair_21_119_X1000000_rowPart_7_2, periodicMainPair_21_119_X1000000_rowPart_7_3]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
