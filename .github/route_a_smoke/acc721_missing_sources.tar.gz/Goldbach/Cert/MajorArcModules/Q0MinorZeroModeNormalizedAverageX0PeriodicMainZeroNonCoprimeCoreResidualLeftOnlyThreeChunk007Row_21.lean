import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_21Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_21Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_21Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_21Part3

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_133_X1000000_divRight_for_row_21 : Nat.divisors 133 = ([1, 7, 19, 133] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_133_X1000000_row_21 :
    (∑ h ∈ Nat.divisors 133,
      ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 133 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 133) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 133 21 h
                - ramanujanGcdClassWindowAverageRat X0 133 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 21 21
                - ramanujanGcdClassWindowAverageRat X0 21 21
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 133 h
                + ramanujanGcdClassWindowAverageRat X0 21 21
                    * ramanujanGcdClassWindowAverageRat X0 133 h
                    * evenRamanujanBlockCountRat 21 133))
    ) = (66576 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_133_X1000000_divRight_for_row_21]
  have hset : ([1, 7, 19, 133] : List ℕ).toFinset = (((periodicMainPair_21_133_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_133_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_133_X1000000_rowChunk_21_2) ∪ periodicMainPair_21_133_X1000000_rowChunk_21_3) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_133_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_133_X1000000_rowChunk_21_1) ∪ periodicMainPair_21_133_X1000000_rowChunk_21_2) periodicMainPair_21_133_X1000000_rowChunk_21_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_133_X1000000_rowChunk_21_0 ∪ periodicMainPair_21_133_X1000000_rowChunk_21_1) periodicMainPair_21_133_X1000000_rowChunk_21_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_133_X1000000_rowChunk_21_0 periodicMainPair_21_133_X1000000_rowChunk_21_1)]
  rw [periodicMainPair_21_133_X1000000_rowPart_21_0, periodicMainPair_21_133_X1000000_rowPart_21_1, periodicMainPair_21_133_X1000000_rowPart_21_2, periodicMainPair_21_133_X1000000_rowPart_21_3]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
