import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk020
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk021
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk022
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk023
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk024
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk025
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk026
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk027
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk028
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk029

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 020..029. -/

def PeriodicMainZeroCoprimeCoreResidualGroup002Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk020Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk021Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk022Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk023Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk024Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk025Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk026Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk027Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk028Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk029Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup002_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup002Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk020Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk021Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk022Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk023Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk024Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk025Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk026Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk027Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk028Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk029Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk020_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk021_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk022_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk023_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk024_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk025_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk026_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk027_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk028_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk029_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
