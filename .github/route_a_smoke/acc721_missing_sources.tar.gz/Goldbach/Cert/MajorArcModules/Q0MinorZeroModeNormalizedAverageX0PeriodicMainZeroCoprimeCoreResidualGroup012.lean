import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk120
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk121
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk122
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk123
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk124
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk125

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 120..125. -/

def PeriodicMainZeroCoprimeCoreResidualGroup012Pairs : Finset (ℕ × ℕ) :=
  (((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk120Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk121Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk122Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk123Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk124Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk125Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup012_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup012Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk120Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk121Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk122Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk123Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk124Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk125Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h5
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h4
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h3
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h2
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with h0 | h1
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk120_value_on_records p h0
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk121_value_on_records p h1
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk122_value_on_records p h2
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk123_value_on_records p h3
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk124_value_on_records p h4
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk125_value_on_records p h5

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
