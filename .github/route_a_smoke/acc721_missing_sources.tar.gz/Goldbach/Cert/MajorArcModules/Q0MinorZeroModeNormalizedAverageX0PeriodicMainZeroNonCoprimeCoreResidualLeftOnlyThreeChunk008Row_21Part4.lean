import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Term_21_14

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_154_X1000000_rowChunk_21_4 : Finset ℕ :=
  ([14] : List ℕ).toFinset

def periodicMainPair_21_154_X1000000_rowPartValue_21_4 : ℕ → ℚ
| 14 => (-34299432480 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_154_X1000000_rowPart_21_4 :
    (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_21_4,
      ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 154 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 21 h
                - ramanujanGcdClassWindowAverageRat X0 154 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 21
                - ramanujanGcdClassWindowAverageRat X0 21 21
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                + ramanujanGcdClassWindowAverageRat X0 21 21
                    * ramanujanGcdClassWindowAverageRat X0 154 h
                    * evenRamanujanBlockCountRat 21 154))
    ) = (-34299432480 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_21_4,
        ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 154 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 21 h
                  - ramanujanGcdClassWindowAverageRat X0 154 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 21
                  - ramanujanGcdClassWindowAverageRat X0 21 21
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                  + ramanujanGcdClassWindowAverageRat X0 21 21
                      * ramanujanGcdClassWindowAverageRat X0 154 h
                      * evenRamanujanBlockCountRat 21 154))
      ) = (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_21_4, periodicMainPair_21_154_X1000000_rowPartValue_21_4 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_154_X1000000_rowChunk_21_4] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_154_X1000000_rowPartValue_21_4] using periodicMainPair_21_154_X1000000_term_21_14
  rw [hsum]
  norm_num [periodicMainPair_21_154_X1000000_rowChunk_21_4, periodicMainPair_21_154_X1000000_rowPartValue_21_4]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
