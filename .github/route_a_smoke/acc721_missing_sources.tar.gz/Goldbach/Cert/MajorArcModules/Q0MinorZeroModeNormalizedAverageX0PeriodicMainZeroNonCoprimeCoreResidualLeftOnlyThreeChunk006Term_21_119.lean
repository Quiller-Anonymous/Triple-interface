import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_119_X1000000_term_21_119 :
    ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 119 119
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 119) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 119 21 119
              - ramanujanGcdClassWindowAverageRat X0 119 119
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 21 21
              - ramanujanGcdClassWindowAverageRat X0 21 21
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 119 119
              + ramanujanGcdClassWindowAverageRat X0 21 21
                  * ramanujanGcdClassWindowAverageRat X0 119 119
                  * evenRamanujanBlockCountRat 21 119))
      = (38415363840 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
