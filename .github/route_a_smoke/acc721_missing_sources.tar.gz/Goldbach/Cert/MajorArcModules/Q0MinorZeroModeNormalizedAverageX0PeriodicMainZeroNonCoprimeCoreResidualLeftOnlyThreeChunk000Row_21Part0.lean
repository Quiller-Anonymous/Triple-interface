import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk000Term_21_1

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_7_X1000000_rowChunk_21_0 : Finset ℕ :=
  ([1] : List ℕ).toFinset

def periodicMainPair_21_7_X1000000_rowPartValue_21_0 : ℕ → ℚ
| 1 => (6802720680 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_7_X1000000_rowPart_21_0 :
    (∑ h ∈ periodicMainPair_21_7_X1000000_rowChunk_21_0,
      ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 7 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 7) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 7 21 h
                - ramanujanGcdClassWindowAverageRat X0 7 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 21 21
                - ramanujanGcdClassWindowAverageRat X0 21 21
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 7 h
                + ramanujanGcdClassWindowAverageRat X0 21 21
                    * ramanujanGcdClassWindowAverageRat X0 7 h
                    * evenRamanujanBlockCountRat 21 7))
    ) = (6802720680 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_7_X1000000_rowChunk_21_0,
        ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 7 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 7) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 7 21 h
                  - ramanujanGcdClassWindowAverageRat X0 7 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 21 21
                  - ramanujanGcdClassWindowAverageRat X0 21 21
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 7 h
                  + ramanujanGcdClassWindowAverageRat X0 21 21
                      * ramanujanGcdClassWindowAverageRat X0 7 h
                      * evenRamanujanBlockCountRat 21 7))
      ) = (∑ h ∈ periodicMainPair_21_7_X1000000_rowChunk_21_0, periodicMainPair_21_7_X1000000_rowPartValue_21_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_7_X1000000_rowChunk_21_0] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_7_X1000000_rowPartValue_21_0] using periodicMainPair_21_7_X1000000_term_21_1
  rw [hsum]
  norm_num [periodicMainPair_21_7_X1000000_rowChunk_21_0, periodicMainPair_21_7_X1000000_rowPartValue_21_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
