import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk090
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk091
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk092
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk093
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk094
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk095
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk096
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk097
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk098
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk099

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 090..099. -/

def PeriodicMainZeroCoprimeCoreResidualGroup009Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk090Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk091Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk092Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk093Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk094Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk095Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk096Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk097Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk098Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk099Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup009_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup009Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk090Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk091Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk092Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk093Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk094Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk095Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk096Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk097Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk098Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk099Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk090_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk091_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk092_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk093_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk094_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk095_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk096_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk097_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk098_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk099_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
