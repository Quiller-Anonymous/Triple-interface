import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_70_X1000000_term_3_10 :
    ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 70 10
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 70) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 70 3 10
              - ramanujanGcdClassWindowAverageRat X0 70 10
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 21 3
              - ramanujanGcdClassWindowAverageRat X0 21 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 70 10
              + ramanujanGcdClassWindowAverageRat X0 21 3
                  * ramanujanGcdClassWindowAverageRat X0 70 10
                  * evenRamanujanBlockCountRat 21 70))
      = (876541408 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
