import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk080
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk081
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk082
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk083
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk084
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk085
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk086
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk087
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk088
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk089

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 080..089. -/

def PeriodicMainZeroCoprimeCoreResidualGroup008Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk080Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk081Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk082Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk083Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk084Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk085Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk086Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk087Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk088Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk089Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup008_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup008Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk080Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk081Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk082Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk083Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk084Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk085Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk086Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk087Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk088Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk089Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk080_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk081_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk082_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk083_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk084_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk085_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk086_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk087_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk088_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk089_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
