import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk030
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk031
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk032
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk033
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk034
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk035
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk036
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk037
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk038
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk039

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 030..039. -/

def PeriodicMainZeroCoprimeCoreResidualGroup003Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk030Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk031Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk032Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk033Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk034Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk035Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk036Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk037Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk038Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk039Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup003_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup003Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk030Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk031Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk032Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk033Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk034Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk035Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk036Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk037Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk038Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk039Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk030_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk031_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk032_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk033_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk034_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk035_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk036_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk037_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk038_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk039_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
