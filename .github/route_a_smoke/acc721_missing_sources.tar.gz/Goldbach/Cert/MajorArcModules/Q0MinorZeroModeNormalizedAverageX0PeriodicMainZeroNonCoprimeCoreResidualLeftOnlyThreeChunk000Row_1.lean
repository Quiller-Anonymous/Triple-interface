import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk000Row_1Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk000Row_1Part1

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_7_X1000000_divRight_for_row_1 : Nat.divisors 7 = ([1, 7] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_7_X1000000_row_1 :
    (∑ h ∈ Nat.divisors 7,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 7 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 7) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 7 1 h
                - ramanujanGcdClassWindowAverageRat X0 7 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 7 7 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 7 h
                    * evenRamanujanBlockCountRat 21 7))
    ) = (-7936507460 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_7_X1000000_divRight_for_row_1]
  have hset : ([1, 7] : List ℕ).toFinset = (periodicMainPair_21_7_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_7_X1000000_rowChunk_1_1) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_7_X1000000_rowChunk_1_0 periodicMainPair_21_7_X1000000_rowChunk_1_1)]
  rw [periodicMainPair_21_7_X1000000_rowPart_1_0, periodicMainPair_21_7_X1000000_rowPart_1_1]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
