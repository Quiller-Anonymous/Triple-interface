import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_14_X1000000_term_7_14 :
    ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 14 14
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 14) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 14 7 14
              - ramanujanGcdClassWindowAverageRat X0 14 14
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 14 21 7
              - ramanujanGcdClassWindowAverageRat X0 21 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 14 14 14
              + ramanujanGcdClassWindowAverageRat X0 21 7
                  * ramanujanGcdClassWindowAverageRat X0 14 14
                  * evenRamanujanBlockCountRat 21 14))
      = (-40816324080 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
