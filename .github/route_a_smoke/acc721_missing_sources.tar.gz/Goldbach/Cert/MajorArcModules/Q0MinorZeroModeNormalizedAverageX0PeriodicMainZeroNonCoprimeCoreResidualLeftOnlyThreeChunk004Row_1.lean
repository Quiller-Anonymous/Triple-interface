import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk004Row_1Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk004Row_1Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk004Row_1Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk004Row_1Part3

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_77_X1000000_divRight_for_row_1 : Nat.divisors 77 = ([1, 7, 11, 77] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_77_X1000000_row_1 :
    (∑ h ∈ Nat.divisors 77,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 77 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 77) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 77 1 h
                - ramanujanGcdClassWindowAverageRat X0 77 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 77 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 77 h
                    * evenRamanujanBlockCountRat 21 77))
    ) = (462 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_77_X1000000_divRight_for_row_1]
  have hset : ([1, 7, 11, 77] : List ℕ).toFinset = (((periodicMainPair_21_77_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_77_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_77_X1000000_rowChunk_1_2) ∪ periodicMainPair_21_77_X1000000_rowChunk_1_3) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_77_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_77_X1000000_rowChunk_1_1) ∪ periodicMainPair_21_77_X1000000_rowChunk_1_2) periodicMainPair_21_77_X1000000_rowChunk_1_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_77_X1000000_rowChunk_1_0 ∪ periodicMainPair_21_77_X1000000_rowChunk_1_1) periodicMainPair_21_77_X1000000_rowChunk_1_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_77_X1000000_rowChunk_1_0 periodicMainPair_21_77_X1000000_rowChunk_1_1)]
  rw [periodicMainPair_21_77_X1000000_rowPart_1_0, periodicMainPair_21_77_X1000000_rowPart_1_1, periodicMainPair_21_77_X1000000_rowPart_1_2, periodicMainPair_21_77_X1000000_rowPart_1_3]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
