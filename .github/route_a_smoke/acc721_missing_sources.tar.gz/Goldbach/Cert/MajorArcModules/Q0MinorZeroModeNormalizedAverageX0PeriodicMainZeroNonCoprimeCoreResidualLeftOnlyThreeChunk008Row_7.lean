import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part4
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part5
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part6
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Row_7Part7

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_154_X1000000_divRight_for_row_7 : Nat.divisors 154 = ([1, 2, 7, 11, 14, 22, 77, 154] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_154_X1000000_row_7 :
    (∑ h ∈ Nat.divisors 154,
      ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 154 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 7 h
                - ramanujanGcdClassWindowAverageRat X0 154 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 7
                - ramanujanGcdClassWindowAverageRat X0 21 7
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                + ramanujanGcdClassWindowAverageRat X0 21 7
                    * ramanujanGcdClassWindowAverageRat X0 154 h
                    * evenRamanujanBlockCountRat 21 154))
    ) = (2640 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_154_X1000000_divRight_for_row_7]
  have hset : ([1, 2, 7, 11, 14, 22, 77, 154] : List ℕ).toFinset = (((((((periodicMainPair_21_154_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_5) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_6) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_7) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((((((periodicMainPair_21_154_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_5) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_6) periodicMainPair_21_154_X1000000_rowChunk_7_7)]
  rw [Finset.sum_union (by native_decide : Disjoint (((((periodicMainPair_21_154_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_4) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_5) periodicMainPair_21_154_X1000000_rowChunk_7_6)]
  rw [Finset.sum_union (by native_decide : Disjoint ((((periodicMainPair_21_154_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_3) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_4) periodicMainPair_21_154_X1000000_rowChunk_7_5)]
  rw [Finset.sum_union (by native_decide : Disjoint (((periodicMainPair_21_154_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_2) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_3) periodicMainPair_21_154_X1000000_rowChunk_7_4)]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_154_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_7_1) ∪ periodicMainPair_21_154_X1000000_rowChunk_7_2) periodicMainPair_21_154_X1000000_rowChunk_7_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_154_X1000000_rowChunk_7_0 ∪ periodicMainPair_21_154_X1000000_rowChunk_7_1) periodicMainPair_21_154_X1000000_rowChunk_7_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_154_X1000000_rowChunk_7_0 periodicMainPair_21_154_X1000000_rowChunk_7_1)]
  rw [periodicMainPair_21_154_X1000000_rowPart_7_0, periodicMainPair_21_154_X1000000_rowPart_7_1, periodicMainPair_21_154_X1000000_rowPart_7_2, periodicMainPair_21_154_X1000000_rowPart_7_3, periodicMainPair_21_154_X1000000_rowPart_7_4, periodicMainPair_21_154_X1000000_rowPart_7_5, periodicMainPair_21_154_X1000000_rowPart_7_6, periodicMainPair_21_154_X1000000_rowPart_7_7]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
