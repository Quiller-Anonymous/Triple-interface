import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk005Term_3_1

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_91_X1000000_rowChunk_3_0 : Finset ℕ :=
  ([1] : List ℕ).toFinset

def periodicMainPair_21_91_X1000000_rowPartValue_3_0 : ℕ → ℚ
| 1 => (-1028982924 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_91_X1000000_rowPart_3_0 :
    (∑ h ∈ periodicMainPair_21_91_X1000000_rowChunk_3_0,
      ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 91 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 91) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 91 3 h
                - ramanujanGcdClassWindowAverageRat X0 91 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 21 3
                - ramanujanGcdClassWindowAverageRat X0 21 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 91 h
                + ramanujanGcdClassWindowAverageRat X0 21 3
                    * ramanujanGcdClassWindowAverageRat X0 91 h
                    * evenRamanujanBlockCountRat 21 91))
    ) = (-1028982924 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_91_X1000000_rowChunk_3_0,
        ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 91 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 91) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 91 3 h
                  - ramanujanGcdClassWindowAverageRat X0 91 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 21 3
                  - ramanujanGcdClassWindowAverageRat X0 21 3
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 91 h
                  + ramanujanGcdClassWindowAverageRat X0 21 3
                      * ramanujanGcdClassWindowAverageRat X0 91 h
                      * evenRamanujanBlockCountRat 21 91))
      ) = (∑ h ∈ periodicMainPair_21_91_X1000000_rowChunk_3_0, periodicMainPair_21_91_X1000000_rowPartValue_3_0 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_91_X1000000_rowChunk_3_0] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_91_X1000000_rowPartValue_3_0] using periodicMainPair_21_91_X1000000_term_3_1
  rw [hsum]
  norm_num [periodicMainPair_21_91_X1000000_rowChunk_3_0, periodicMainPair_21_91_X1000000_rowPartValue_3_0]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
