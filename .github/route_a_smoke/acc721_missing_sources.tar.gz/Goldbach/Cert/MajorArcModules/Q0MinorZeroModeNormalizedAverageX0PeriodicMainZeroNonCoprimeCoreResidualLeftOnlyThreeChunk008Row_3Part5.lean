import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Term_3_22

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_154_X1000000_rowChunk_3_5 : Finset ℕ :=
  ([22] : List ℕ).toFinset

def periodicMainPair_21_154_X1000000_rowPartValue_3_5 : ℕ → ℚ
| 22 => (952762400 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_154_X1000000_rowPart_3_5 :
    (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_3_5,
      ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 154 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 3 h
                - ramanujanGcdClassWindowAverageRat X0 154 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 3
                - ramanujanGcdClassWindowAverageRat X0 21 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                + ramanujanGcdClassWindowAverageRat X0 21 3
                    * ramanujanGcdClassWindowAverageRat X0 154 h
                    * evenRamanujanBlockCountRat 21 154))
    ) = (952762400 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_3_5,
        ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 154 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 3 h
                  - ramanujanGcdClassWindowAverageRat X0 154 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 3
                  - ramanujanGcdClassWindowAverageRat X0 21 3
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                  + ramanujanGcdClassWindowAverageRat X0 21 3
                      * ramanujanGcdClassWindowAverageRat X0 154 h
                      * evenRamanujanBlockCountRat 21 154))
      ) = (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_3_5, periodicMainPair_21_154_X1000000_rowPartValue_3_5 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_154_X1000000_rowChunk_3_5] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_154_X1000000_rowPartValue_3_5] using periodicMainPair_21_154_X1000000_term_3_22
  rw [hsum]
  norm_num [periodicMainPair_21_154_X1000000_rowChunk_3_5, periodicMainPair_21_154_X1000000_rowPartValue_3_5]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
