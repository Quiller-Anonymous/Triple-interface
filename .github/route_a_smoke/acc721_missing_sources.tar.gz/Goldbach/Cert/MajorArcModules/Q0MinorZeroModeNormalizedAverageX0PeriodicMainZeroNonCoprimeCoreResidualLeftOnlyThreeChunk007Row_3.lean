import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_3Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_3Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_3Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk007Row_3Part3

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_133_X1000000_divRight_for_row_3 : Nat.divisors 133 = ([1, 7, 19, 133] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_133_X1000000_row_3 :
    (∑ h ∈ Nat.divisors 133,
      ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 133 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 133) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 133 3 h
                - ramanujanGcdClassWindowAverageRat X0 133 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 21 3
                - ramanujanGcdClassWindowAverageRat X0 21 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 133 133 h
                + ramanujanGcdClassWindowAverageRat X0 21 3
                    * ramanujanGcdClassWindowAverageRat X0 133 h
                    * evenRamanujanBlockCountRat 21 133))
    ) = (11096 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_133_X1000000_divRight_for_row_3]
  have hset : ([1, 7, 19, 133] : List ℕ).toFinset = (((periodicMainPair_21_133_X1000000_rowChunk_3_0 ∪ periodicMainPair_21_133_X1000000_rowChunk_3_1) ∪ periodicMainPair_21_133_X1000000_rowChunk_3_2) ∪ periodicMainPair_21_133_X1000000_rowChunk_3_3) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_133_X1000000_rowChunk_3_0 ∪ periodicMainPair_21_133_X1000000_rowChunk_3_1) ∪ periodicMainPair_21_133_X1000000_rowChunk_3_2) periodicMainPair_21_133_X1000000_rowChunk_3_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_133_X1000000_rowChunk_3_0 ∪ periodicMainPair_21_133_X1000000_rowChunk_3_1) periodicMainPair_21_133_X1000000_rowChunk_3_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_133_X1000000_rowChunk_3_0 periodicMainPair_21_133_X1000000_rowChunk_3_1)]
  rw [periodicMainPair_21_133_X1000000_rowPart_3_0, periodicMainPair_21_133_X1000000_rowPart_3_1, periodicMainPair_21_133_X1000000_rowPart_3_2, periodicMainPair_21_133_X1000000_rowPart_3_3]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
