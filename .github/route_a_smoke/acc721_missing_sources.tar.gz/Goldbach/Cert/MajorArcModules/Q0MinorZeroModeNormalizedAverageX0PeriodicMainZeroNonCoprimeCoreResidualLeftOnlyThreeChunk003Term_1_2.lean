import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_70_X1000000_term_1_2 :
    ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 70 2
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 70) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 70 1 2
              - ramanujanGcdClassWindowAverageRat X0 70 2
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 21 1
              - ramanujanGcdClassWindowAverageRat X0 21 1
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 70 2
              + ramanujanGcdClassWindowAverageRat X0 21 1
                  * ramanujanGcdClassWindowAverageRat X0 70 2
                  * evenRamanujanBlockCountRat 21 70))
      = (876540948 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
