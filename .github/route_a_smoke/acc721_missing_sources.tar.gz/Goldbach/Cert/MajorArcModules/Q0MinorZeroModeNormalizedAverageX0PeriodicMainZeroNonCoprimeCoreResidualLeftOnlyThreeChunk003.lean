import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk003Row_1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk003Row_3
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk003Row_7
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk003Row_21

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Split generated periodic-main zero-record proof for selected JSON index 3. -/

theorem periodicMainPair_21_70_X1000000_divLeft : Nat.divisors 21 = ([1, 3, 7, 21] : List ℕ).toFinset := by
  decide

def periodicMainPair_21_70_X1000000_rowValue : ℕ → ℚ
| 1 => (460 : ℚ) / 2778889
| 3 => (-460 : ℚ) / 2778889
| 7 => (2760 : ℚ) / 2778889
| 21 => (-2760 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_70_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 21 70 = (0 : ℚ) / 1 := by
  unfold centeredRamanujanPairPeriodicMainTermRat
  have hsum :
      (∑ g ∈ Nat.divisors 21, ∑ h ∈ Nat.divisors 70,
        ramanujanGcdClassCoeffRat 21 g * ramanujanGcdClassCoeffRat 70 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 70) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 70 g h
                  - ramanujanGcdClassWindowAverageRat X0 70 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 21 g
                  - ramanujanGcdClassWindowAverageRat X0 21 g
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 70 h
                  + ramanujanGcdClassWindowAverageRat X0 21 g
                      * ramanujanGcdClassWindowAverageRat X0 70 h
                      * evenRamanujanBlockCountRat 21 70))
      ) = (∑ g ∈ Nat.divisors 21, periodicMainPair_21_70_X1000000_rowValue g) := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [periodicMainPair_21_70_X1000000_divLeft] at hg
    simp at hg
    rcases hg with rfl | rfl | rfl | rfl
    · simpa [periodicMainPair_21_70_X1000000_rowValue] using periodicMainPair_21_70_X1000000_row_1
    · simpa [periodicMainPair_21_70_X1000000_rowValue] using periodicMainPair_21_70_X1000000_row_3
    · simpa [periodicMainPair_21_70_X1000000_rowValue] using periodicMainPair_21_70_X1000000_row_7
    · simpa [periodicMainPair_21_70_X1000000_rowValue] using periodicMainPair_21_70_X1000000_row_21
  rw [hsum, periodicMainPair_21_70_X1000000_divLeft]
  norm_num [periodicMainPair_21_70_X1000000_rowValue]

theorem periodicMainPair_21_70_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 21 70) = (0 : ℚ) / 1 := by
  have hneq : 21 ≠ 70 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 21 = (5 : ℚ) / 144 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 70 = (5 : ℚ) / 576 := by
    native_decide
  have hvalue : ((5 : ℚ) / 144) * ((5 : ℚ) / 576) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_21_70_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsCoreLeftOnlyThreeChunk003Pairs : Finset (ℕ × ℕ) :=
  [(21, 70)].toFinset

theorem PeriodicMainRecordsCoreLeftOnlyThreeChunk003_value_on_records :
    ∀ p ∈ PeriodicMainRecordsCoreLeftOnlyThreeChunk003Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsCoreLeftOnlyThreeChunk003Pairs] at hp
  rcases hp with h
  · subst p
    simpa using periodicMainPair_21_70_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
