import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_77_X1000000_term_3_11 :
    ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 77 11
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 77) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 77 3 11
              - ramanujanGcdClassWindowAverageRat X0 77 11
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 21 3
              - ramanujanGcdClassWindowAverageRat X0 21 3
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 77 77 11
              + ramanujanGcdClassWindowAverageRat X0 21 3
                  * ramanujanGcdClassWindowAverageRat X0 77 11
                  * evenRamanujanBlockCountRat 21 77))
      = (1000400520 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
