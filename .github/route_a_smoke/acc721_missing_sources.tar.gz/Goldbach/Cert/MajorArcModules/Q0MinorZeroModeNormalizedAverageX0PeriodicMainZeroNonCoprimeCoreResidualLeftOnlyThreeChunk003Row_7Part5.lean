import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk003Term_7_14

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_70_X1000000_rowChunk_7_5 : Finset ℕ :=
  ([14] : List ℕ).toFinset

def periodicMainPair_21_70_X1000000_rowPartValue_7_5 : ℕ → ℚ
| 14 => (31555478544 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_70_X1000000_rowPart_7_5 :
    (∑ h ∈ periodicMainPair_21_70_X1000000_rowChunk_7_5,
      ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 70 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 70) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 70 7 h
                - ramanujanGcdClassWindowAverageRat X0 70 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 21 7
                - ramanujanGcdClassWindowAverageRat X0 21 7
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 70 h
                + ramanujanGcdClassWindowAverageRat X0 21 7
                    * ramanujanGcdClassWindowAverageRat X0 70 h
                    * evenRamanujanBlockCountRat 21 70))
    ) = (31555478544 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_70_X1000000_rowChunk_7_5,
        ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 70 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 70) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 70 7 h
                  - ramanujanGcdClassWindowAverageRat X0 70 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 21 7
                  - ramanujanGcdClassWindowAverageRat X0 21 7
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 70 70 h
                  + ramanujanGcdClassWindowAverageRat X0 21 7
                      * ramanujanGcdClassWindowAverageRat X0 70 h
                      * evenRamanujanBlockCountRat 21 70))
      ) = (∑ h ∈ periodicMainPair_21_70_X1000000_rowChunk_7_5, periodicMainPair_21_70_X1000000_rowPartValue_7_5 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_70_X1000000_rowChunk_7_5] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_70_X1000000_rowPartValue_7_5] using periodicMainPair_21_70_X1000000_term_7_14
  rw [hsum]
  norm_num [periodicMainPair_21_70_X1000000_rowChunk_7_5, periodicMainPair_21_70_X1000000_rowPartValue_7_5]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
