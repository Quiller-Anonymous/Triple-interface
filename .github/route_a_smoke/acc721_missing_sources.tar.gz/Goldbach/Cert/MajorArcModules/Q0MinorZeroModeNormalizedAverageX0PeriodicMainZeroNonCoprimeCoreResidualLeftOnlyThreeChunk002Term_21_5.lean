import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_35_X1000000_term_21_5 :
    ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 35 5
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 35) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 35 21 5
              - ramanujanGcdClassWindowAverageRat X0 35 5
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 21 21
              - ramanujanGcdClassWindowAverageRat X0 21 21
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 35 5
              + ramanujanGcdClassWindowAverageRat X0 21 21
                  * ramanujanGcdClassWindowAverageRat X0 35 5
                  * evenRamanujanBlockCountRat 21 35))
      = (5373579936 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
