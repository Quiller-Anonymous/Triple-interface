import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk010
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk011
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk012
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk013
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk014
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk015
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk016
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk017
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk018
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk019

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 010..019. -/

def PeriodicMainZeroCoprimeCoreResidualGroup001Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk010Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk011Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk012Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk013Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk014Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk015Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk016Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk017Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk018Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk019Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup001_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup001Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk010Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk011Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk012Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk013Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk014Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk015Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk016Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk017Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk018Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk019Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk010_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk011_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk012_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk013_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk014_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk015_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk016_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk017_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk018_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk019_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
