import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated periodic-main ordered-record proofs for selected JSON indices [230,235). -/

theorem periodicMainPair_21_235_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 21 235 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 21 = ([1, 3, 7, 21] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 235 = ([1, 5, 47, 235] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 21 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_3 : ramanujanGcdClassCoeffRat 21 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_7 : ramanujanGcdClassCoeffRat 21 7 = (-6 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_21 : ramanujanGcdClassCoeffRat 21 21 = (12 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 235 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_5 : ramanujanGcdClassCoeffRat 235 5 = (-4 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_47 : ramanujanGcdClassCoeffRat 235 47 = (-46 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_235 : ramanujanGcdClassCoeffRat 235 235 = (184 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 21 1 = (2858 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_3 : ramanujanGcdClassWindowAverageRat X0 21 3 = (1429 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_7 : ramanujanGcdClassWindowAverageRat X0 21 7 = (476 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_21 : ramanujanGcdClassWindowAverageRat X0 21 21 = (238 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 235 1 = (1305 : ℚ) / 1667 := by
    native_decide
  have hAvgRight_5 : ramanujanGcdClassWindowAverageRat X0 235 5 = (980 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_47 : ramanujanGcdClassWindowAverageRat X0 235 47 = (85 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_235 : ramanujanGcdClassWindowAverageRat X0 235 235 = (7 : ℚ) / 1667 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 21 1 = (2820 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 21 3 = (1410 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_7 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 21 7 = (470 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_21 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 21 21 = (235 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 235 1 = (3864 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_5 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 235 5 = (966 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_47 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 235 47 = (84 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_235 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 235 235 235 = (21 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 1 1 = (2208 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 1 5 = (552 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_47 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 1 47 = (48 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_235 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 1 235 = (12 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_3_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 3 1 = (1104 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_3_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 3 5 = (276 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_3_47 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 3 47 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_3_235 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 3 235 = (6 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_7_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 7 1 = (368 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_7_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 7 5 = (92 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_7_47 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 7 47 = (8 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_7_235 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 7 235 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_21_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 21 1 = (184 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_21_5 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 21 5 = (46 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_21_47 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 21 47 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_21_235 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 235 21 235 = (1 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_3, hCoeffLeft_7, hCoeffLeft_21, hCoeffRight_1, hCoeffRight_5, hCoeffRight_47, hCoeffRight_235, hAvgLeft_1, hAvgLeft_3, hAvgLeft_7, hAvgLeft_21, hAvgRight_1, hAvgRight_5, hAvgRight_47, hAvgRight_235, hBlockLeft_1, hBlockLeft_3, hBlockLeft_7, hBlockLeft_21, hBlockRight_1, hBlockRight_5, hBlockRight_47, hBlockRight_235, hPair_1_1, hPair_1_5, hPair_1_47, hPair_1_235, hPair_3_1, hPair_3_5, hPair_3_47, hPair_3_235, hPair_7_1, hPair_7_5, hPair_7_47, hPair_7_235, hPair_21_1, hPair_21_5, hPair_21_47, hPair_21_235]

theorem periodicMainPair_21_235_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 21 235) = (0 : ℚ) / 1 := by
  have hneq : 21 ≠ 235 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 21 = (5 : ℚ) / 144 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 235 = (5 : ℚ) / 33856 := by
    native_decide
  have hvalue : ((5 : ℚ) / 144) * ((5 : ℚ) / 33856) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_21_235_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_22_21_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 22 21 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 22 = ([1, 2, 11, 22] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 21 = ([1, 3, 7, 21] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 22 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_2 : ramanujanGcdClassCoeffRat 22 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_11 : ramanujanGcdClassCoeffRat 22 11 = (-10 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_22 : ramanujanGcdClassCoeffRat 22 22 = (10 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 21 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 21 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_7 : ramanujanGcdClassCoeffRat 21 7 = (-6 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_21 : ramanujanGcdClassCoeffRat 21 21 = (12 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 22 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_2 : ramanujanGcdClassWindowAverageRat X0 22 2 = (4546 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_11 : ramanujanGcdClassWindowAverageRat X0 22 11 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_22 : ramanujanGcdClassWindowAverageRat X0 22 22 = (455 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 21 1 = (2858 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 21 3 = (1429 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_7 : ramanujanGcdClassWindowAverageRat X0 21 7 = (476 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_21 : ramanujanGcdClassWindowAverageRat X0 21 21 = (238 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 22 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_2 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 22 2 = (420 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_11 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 22 11 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_22 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 22 22 = (42 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 21 1 = (264 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 21 3 = (132 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_7 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 21 7 = (44 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_21 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 21 21 21 = (22 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 1 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 1 7 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 1 21 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 2 1 = (240 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 2 3 = (120 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 2 7 = (40 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 2 21 = (20 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 11 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 11 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 11 7 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 11 21 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 22 1 = (24 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 22 3 = (12 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_7 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 22 7 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_21 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 21 22 21 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_2, hCoeffLeft_11, hCoeffLeft_22, hCoeffRight_1, hCoeffRight_3, hCoeffRight_7, hCoeffRight_21, hAvgLeft_1, hAvgLeft_2, hAvgLeft_11, hAvgLeft_22, hAvgRight_1, hAvgRight_3, hAvgRight_7, hAvgRight_21, hBlockLeft_1, hBlockLeft_2, hBlockLeft_11, hBlockLeft_22, hBlockRight_1, hBlockRight_3, hBlockRight_7, hBlockRight_21, hPair_1_1, hPair_1_3, hPair_1_7, hPair_1_21, hPair_2_1, hPair_2_3, hPair_2_7, hPair_2_21, hPair_11_1, hPair_11_3, hPair_11_7, hPair_11_21, hPair_22_1, hPair_22_3, hPair_22_7, hPair_22_21]

theorem periodicMainPair_22_21_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 22 21) = (0 : ℚ) / 1 := by
  have hneq : 22 ≠ 21 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 22 = (1 : ℚ) / 20 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 21 = (5 : ℚ) / 144 := by
    native_decide
  have hvalue : ((1 : ℚ) / 20) * ((5 : ℚ) / 144) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_22_21_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_22_51_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 22 51 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 22 = ([1, 2, 11, 22] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 51 = ([1, 3, 17, 51] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 22 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_2 : ramanujanGcdClassCoeffRat 22 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_11 : ramanujanGcdClassCoeffRat 22 11 = (-10 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_22 : ramanujanGcdClassCoeffRat 22 22 = (10 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 51 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 51 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_17 : ramanujanGcdClassCoeffRat 51 17 = (-16 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_51 : ramanujanGcdClassCoeffRat 51 51 = (32 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 22 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_2 : ramanujanGcdClassWindowAverageRat X0 22 2 = (4546 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_11 : ramanujanGcdClassWindowAverageRat X0 22 11 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_22 : ramanujanGcdClassWindowAverageRat X0 22 22 = (455 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 51 1 = (1046 : ℚ) / 1667 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 51 3 = (523 : ℚ) / 1667 := by
    native_decide
  have hAvgRight_17 : ramanujanGcdClassWindowAverageRat X0 51 17 = (196 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_51 : ramanujanGcdClassWindowAverageRat X0 51 51 = (98 : ℚ) / 5001 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 22 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_2 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 22 2 = (1020 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_11 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 22 11 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_22 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 22 22 = (102 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 51 1 = (704 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 51 3 = (352 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_17 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 51 17 = (44 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_51 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 51 51 51 = (22 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 1 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_17 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 1 17 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_51 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 1 51 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 2 1 = (640 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 2 3 = (320 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_17 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 2 17 = (40 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_51 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 2 51 = (20 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 11 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 11 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_17 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 11 17 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_51 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 11 51 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 22 1 = (64 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 22 3 = (32 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_17 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 22 17 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_51 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 51 22 51 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_2, hCoeffLeft_11, hCoeffLeft_22, hCoeffRight_1, hCoeffRight_3, hCoeffRight_17, hCoeffRight_51, hAvgLeft_1, hAvgLeft_2, hAvgLeft_11, hAvgLeft_22, hAvgRight_1, hAvgRight_3, hAvgRight_17, hAvgRight_51, hBlockLeft_1, hBlockLeft_2, hBlockLeft_11, hBlockLeft_22, hBlockRight_1, hBlockRight_3, hBlockRight_17, hBlockRight_51, hPair_1_1, hPair_1_3, hPair_1_17, hPair_1_51, hPair_2_1, hPair_2_3, hPair_2_17, hPair_2_51, hPair_11_1, hPair_11_3, hPair_11_17, hPair_11_51, hPair_22_1, hPair_22_3, hPair_22_17, hPair_22_51]

theorem periodicMainPair_22_51_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 22 51) = (0 : ℚ) / 1 := by
  have hneq : 22 ≠ 51 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 22 = (1 : ℚ) / 20 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 51 = (5 : ℚ) / 1024 := by
    native_decide
  have hvalue : ((1 : ℚ) / 20) * ((5 : ℚ) / 1024) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_22_51_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_22_111_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 22 111 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 22 = ([1, 2, 11, 22] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 111 = ([1, 3, 37, 111] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 22 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_2 : ramanujanGcdClassCoeffRat 22 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_11 : ramanujanGcdClassCoeffRat 22 11 = (-10 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_22 : ramanujanGcdClassCoeffRat 22 22 = (10 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 111 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 111 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_37 : ramanujanGcdClassCoeffRat 111 37 = (-36 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_111 : ramanujanGcdClassCoeffRat 111 111 = (72 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 22 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_2 : ramanujanGcdClassWindowAverageRat X0 22 2 = (4546 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_11 : ramanujanGcdClassWindowAverageRat X0 22 11 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_22 : ramanujanGcdClassWindowAverageRat X0 22 22 = (455 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 111 1 = (3244 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 111 3 = (1622 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_37 : ramanujanGcdClassWindowAverageRat X0 111 37 = (30 : ℚ) / 1667 := by
    native_decide
  have hAvgRight_111 : ramanujanGcdClassWindowAverageRat X0 111 111 = (15 : ℚ) / 1667 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 22 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_2 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 22 2 = (2220 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_11 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 22 11 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_22 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 22 22 = (222 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 111 1 = (1584 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 111 3 = (792 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_37 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 111 37 = (44 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_111 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 111 111 111 = (22 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 1 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_37 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 1 37 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_111 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 1 111 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 2 1 = (1440 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 2 3 = (720 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_37 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 2 37 = (40 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_111 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 2 111 = (20 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 11 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 11 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_37 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 11 37 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_111 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 11 111 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 22 1 = (144 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 22 3 = (72 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_37 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 22 37 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_111 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 111 22 111 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_2, hCoeffLeft_11, hCoeffLeft_22, hCoeffRight_1, hCoeffRight_3, hCoeffRight_37, hCoeffRight_111, hAvgLeft_1, hAvgLeft_2, hAvgLeft_11, hAvgLeft_22, hAvgRight_1, hAvgRight_3, hAvgRight_37, hAvgRight_111, hBlockLeft_1, hBlockLeft_2, hBlockLeft_11, hBlockLeft_22, hBlockRight_1, hBlockRight_3, hBlockRight_37, hBlockRight_111, hPair_1_1, hPair_1_3, hPair_1_37, hPair_1_111, hPair_2_1, hPair_2_3, hPair_2_37, hPair_2_111, hPair_11_1, hPair_11_3, hPair_11_37, hPair_11_111, hPair_22_1, hPair_22_3, hPair_22_37, hPair_22_111]

theorem periodicMainPair_22_111_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 22 111) = (0 : ℚ) / 1 := by
  have hneq : 22 ≠ 111 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 22 = (1 : ℚ) / 20 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 111 = (5 : ℚ) / 5184 := by
    native_decide
  have hvalue : ((1 : ℚ) / 20) * ((5 : ℚ) / 5184) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_22_111_X1000000_centeredTerm
    hvalue

theorem periodicMainPair_22_129_X1000000_centeredTerm :
    centeredRamanujanPairPeriodicMainTermRat X0 22 129 = (0 : ℚ) / 1 := by
  have hDivLeft : Nat.divisors 22 = ([1, 2, 11, 22] : List ℕ).toFinset := by
    native_decide
  have hDivRight : Nat.divisors 129 = ([1, 3, 43, 129] : List ℕ).toFinset := by
    native_decide
  have hCoeffLeft_1 : ramanujanGcdClassCoeffRat 22 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_2 : ramanujanGcdClassCoeffRat 22 2 = (-1 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_11 : ramanujanGcdClassCoeffRat 22 11 = (-10 : ℚ) / 1 := by
    native_decide
  have hCoeffLeft_22 : ramanujanGcdClassCoeffRat 22 22 = (10 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_1 : ramanujanGcdClassCoeffRat 129 1 = (1 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_3 : ramanujanGcdClassCoeffRat 129 3 = (-2 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_43 : ramanujanGcdClassCoeffRat 129 43 = (-42 : ℚ) / 1 := by
    native_decide
  have hCoeffRight_129 : ramanujanGcdClassCoeffRat 129 129 = (84 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_1 : ramanujanGcdClassWindowAverageRat X0 22 1 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_2 : ramanujanGcdClassWindowAverageRat X0 22 2 = (4546 : ℚ) / 5001 := by
    native_decide
  have hAvgLeft_11 : ramanujanGcdClassWindowAverageRat X0 22 11 = (0 : ℚ) / 1 := by
    native_decide
  have hAvgLeft_22 : ramanujanGcdClassWindowAverageRat X0 22 22 = (455 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_1 : ramanujanGcdClassWindowAverageRat X0 129 1 = (3256 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_3 : ramanujanGcdClassWindowAverageRat X0 129 3 = (1628 : ℚ) / 5001 := by
    native_decide
  have hAvgRight_43 : ramanujanGcdClassWindowAverageRat X0 129 43 = (26 : ℚ) / 1667 := by
    native_decide
  have hAvgRight_129 : ramanujanGcdClassWindowAverageRat X0 129 129 = (13 : ℚ) / 1667 := by
    native_decide
  have hBlockLeft_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 22 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_2 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 22 2 = (2580 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockLeft_11 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 22 11 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_zero_of_not_isEven_g_of_isEven_quotient]
    · norm_num [Goldbach.Windows.IsEven]
    · norm_num [Goldbach.Windows.IsEven]
  have hBlockLeft_22 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 22 22 = (258 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_1 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 129 1 = (1848 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_3 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 129 3 = (924 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_43 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 129 43 = (44 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hBlockRight_129 : rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 22 129 129 129 = (22 : ℚ) := by
    rw [rawEvenRamanujanGcdClassBlockPeriodicCountRat_eq_odd_totient_main_add_remainder]
    all_goals native_decide
  have hPair_1_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 1 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 1 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_43 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 1 43 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_1_129 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 1 129 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 2 1 = (1680 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 2 3 = (840 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_43 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 2 43 = (40 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_2_129 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 2 129 = (20 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 11 1 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 11 3 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_43 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 11 43 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_11_129 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 11 129 = (0 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_zero_of_not_isEven_lcm_of_isEven_jointModulus]
      · norm_num [Goldbach.Windows.IsEven]
      · norm_num [Goldbach.Windows.IsEven, ramanujanGcdClassJointModulus]
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_1 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 22 1 = (168 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_3 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 22 3 = (84 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_43 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 22 43 = (4 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  have hPair_22_129 : rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 22 129 22 129 = (2 : ℚ) := by
    rw [rawEvenRamanujanGcdClassPairBlockResolvedCountRat_eq_periodic_of_compatible]
    · rw [rawEvenRamanujanGcdClassPairBlockPeriodicCountRat_eq_even_totient_main_add_remainder]
      all_goals native_decide
    · norm_num [ramanujanGcdClassJointCompatibility]
  unfold centeredRamanujanPairPeriodicMainTermRat
  norm_num [centeredRamanujanPairBlockPeriod, evenRamanujanBlockCountRat, H, hDivLeft, hDivRight, hCoeffLeft_1, hCoeffLeft_2, hCoeffLeft_11, hCoeffLeft_22, hCoeffRight_1, hCoeffRight_3, hCoeffRight_43, hCoeffRight_129, hAvgLeft_1, hAvgLeft_2, hAvgLeft_11, hAvgLeft_22, hAvgRight_1, hAvgRight_3, hAvgRight_43, hAvgRight_129, hBlockLeft_1, hBlockLeft_2, hBlockLeft_11, hBlockLeft_22, hBlockRight_1, hBlockRight_3, hBlockRight_43, hBlockRight_129, hPair_1_1, hPair_1_3, hPair_1_43, hPair_1_129, hPair_2_1, hPair_2_3, hPair_2_43, hPair_2_129, hPair_11_1, hPair_11_3, hPair_11_43, hPair_11_129, hPair_22_1, hPair_22_3, hPair_22_43, hPair_22_129]

theorem periodicMainPair_22_129_X1000000_orderedSummand :
    surrogatePeriodicMainActiveOrderedPairSummandRat X0 (Prod.mk 22 129) = (0 : ℚ) / 1 := by
  have hneq : 22 ≠ 129 := by
    norm_num
  have hCoeffLeft : surrogateNormalizedSigmaTruncSummandCoeffRat 22 = (1 : ℚ) / 20 := by
    native_decide
  have hCoeffRight : surrogateNormalizedSigmaTruncSummandCoeffRat 129 = (5 : ℚ) / 7056 := by
    native_decide
  have hvalue : ((1 : ℚ) / 20) * ((5 : ℚ) / 7056) * ((0 : ℚ) / 1) = (0 : ℚ) / 1 := by
    norm_num
  exact surrogatePeriodicMainActiveOrderedPairSummandRat_eq_of_pairValue
    hneq hCoeffLeft hCoeffRight
    periodicMainPair_22_129_X1000000_centeredTerm
    hvalue

def PeriodicMainRecordsZeroCoprimeCoreResidualChunk046Pairs : Finset (ℕ × ℕ) :=
  [(21, 235), (22, 21), (22, 51), (22, 111), (22, 129)].toFinset

theorem PeriodicMainRecordsZeroCoprimeCoreResidualChunk046_value_on_records :
    ∀ p ∈ PeriodicMainRecordsZeroCoprimeCoreResidualChunk046Pairs,
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  simp [PeriodicMainRecordsZeroCoprimeCoreResidualChunk046Pairs] at hp
  rcases hp with h | h | h | h | h
  · subst p
    simpa using periodicMainPair_21_235_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_22_21_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_22_51_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_22_111_X1000000_orderedSummand
  · subst p
    simpa using periodicMainPair_22_129_X1000000_orderedSummand

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
