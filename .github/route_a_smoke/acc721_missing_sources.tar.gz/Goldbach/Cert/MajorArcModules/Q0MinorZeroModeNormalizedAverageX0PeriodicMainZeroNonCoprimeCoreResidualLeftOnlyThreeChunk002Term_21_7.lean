import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMain

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_35_X1000000_term_21_7 :
    ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 35 7
      * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 35) : ℕ)
          • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 35 21 7
              - ramanujanGcdClassWindowAverageRat X0 35 7
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 21 21
              - ramanujanGcdClassWindowAverageRat X0 21 21
                  * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 35 35 7
              + ramanujanGcdClassWindowAverageRat X0 21 21
                  * ramanujanGcdClassWindowAverageRat X0 35 7
                  * evenRamanujanBlockCountRat 21 35))
      = (-32241467208 : ℚ) / 2778889 := by
  native_decide

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
