import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk070
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk071
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk072
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk073
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk074
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk075
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk076
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk077
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk078
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk079

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 070..079. -/

def PeriodicMainZeroCoprimeCoreResidualGroup007Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk070Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk071Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk072Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk073Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk074Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk075Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk076Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk077Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk078Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk079Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup007_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup007Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk070Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk071Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk072Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk073Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk074Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk075Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk076Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk077Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk078Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk079Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk070_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk071_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk072_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk073_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk074_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk075_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk076_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk077_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk078_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk079_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
