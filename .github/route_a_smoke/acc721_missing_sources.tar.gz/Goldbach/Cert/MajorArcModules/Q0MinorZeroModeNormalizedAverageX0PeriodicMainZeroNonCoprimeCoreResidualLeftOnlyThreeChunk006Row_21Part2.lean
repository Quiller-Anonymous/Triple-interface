import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk006Term_21_17

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_119_X1000000_rowChunk_21_2 : Finset ℕ :=
  ([17] : List ℕ).toFinset

def periodicMainPair_21_119_X1000000_rowPartValue_21_2 : ℕ → ℚ
| 17 => (6402557952 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_119_X1000000_rowPart_21_2 :
    (∑ h ∈ periodicMainPair_21_119_X1000000_rowChunk_21_2,
      ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 119 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 119) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 119 21 h
                - ramanujanGcdClassWindowAverageRat X0 119 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 21 21
                - ramanujanGcdClassWindowAverageRat X0 21 21
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 119 h
                + ramanujanGcdClassWindowAverageRat X0 21 21
                    * ramanujanGcdClassWindowAverageRat X0 119 h
                    * evenRamanujanBlockCountRat 21 119))
    ) = (6402557952 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_119_X1000000_rowChunk_21_2,
        ramanujanGcdClassCoeffRat 21 21 * ramanujanGcdClassCoeffRat 119 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 119) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 119 21 h
                  - ramanujanGcdClassWindowAverageRat X0 119 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 21 21
                  - ramanujanGcdClassWindowAverageRat X0 21 21
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 119 h
                  + ramanujanGcdClassWindowAverageRat X0 21 21
                      * ramanujanGcdClassWindowAverageRat X0 119 h
                      * evenRamanujanBlockCountRat 21 119))
      ) = (∑ h ∈ periodicMainPair_21_119_X1000000_rowChunk_21_2, periodicMainPair_21_119_X1000000_rowPartValue_21_2 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_119_X1000000_rowChunk_21_2] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_119_X1000000_rowPartValue_21_2] using periodicMainPair_21_119_X1000000_term_21_17
  rw [hsum]
  norm_num [periodicMainPair_21_119_X1000000_rowChunk_21_2, periodicMainPair_21_119_X1000000_rowPartValue_21_2]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
