import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk006Term_1_119

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_119_X1000000_rowChunk_1_3 : Finset ℕ :=
  ([119] : List ℕ).toFinset

def periodicMainPair_21_119_X1000000_rowPartValue_1_3 : ℕ → ℚ
| 119 => (-6402560640 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_119_X1000000_rowPart_1_3 :
    (∑ h ∈ periodicMainPair_21_119_X1000000_rowChunk_1_3,
      ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 119 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 119) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 119 1 h
                - ramanujanGcdClassWindowAverageRat X0 119 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 21 1
                - ramanujanGcdClassWindowAverageRat X0 21 1
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 119 h
                + ramanujanGcdClassWindowAverageRat X0 21 1
                    * ramanujanGcdClassWindowAverageRat X0 119 h
                    * evenRamanujanBlockCountRat 21 119))
    ) = (-6402560640 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_119_X1000000_rowChunk_1_3,
        ramanujanGcdClassCoeffRat 21 1 * ramanujanGcdClassCoeffRat 119 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 119) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 119 1 h
                  - ramanujanGcdClassWindowAverageRat X0 119 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 21 1
                  - ramanujanGcdClassWindowAverageRat X0 21 1
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 119 119 h
                  + ramanujanGcdClassWindowAverageRat X0 21 1
                      * ramanujanGcdClassWindowAverageRat X0 119 h
                      * evenRamanujanBlockCountRat 21 119))
      ) = (∑ h ∈ periodicMainPair_21_119_X1000000_rowChunk_1_3, periodicMainPair_21_119_X1000000_rowPartValue_1_3 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_119_X1000000_rowChunk_1_3] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_119_X1000000_rowPartValue_1_3] using periodicMainPair_21_119_X1000000_term_1_119
  rw [hsum]
  norm_num [periodicMainPair_21_119_X1000000_rowChunk_1_3, periodicMainPair_21_119_X1000000_rowPartValue_1_3]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
