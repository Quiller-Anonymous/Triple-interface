import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk008Term_7_2

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

def periodicMainPair_21_154_X1000000_rowChunk_7_1 : Finset ℕ :=
  ([2] : List ℕ).toFinset

def periodicMainPair_21_154_X1000000_rowPartValue_7_1 : ℕ → ℚ
| 2 => (5716571760 : ℚ) / 2778889
| _ => 0

theorem periodicMainPair_21_154_X1000000_rowPart_7_1 :
    (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_7_1,
      ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 154 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 7 h
                - ramanujanGcdClassWindowAverageRat X0 154 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 7
                - ramanujanGcdClassWindowAverageRat X0 21 7
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                + ramanujanGcdClassWindowAverageRat X0 21 7
                    * ramanujanGcdClassWindowAverageRat X0 154 h
                    * evenRamanujanBlockCountRat 21 154))
    ) = (5716571760 : ℚ) / 2778889 := by
  have hsum :
      (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_7_1,
        ramanujanGcdClassCoeffRat 21 7 * ramanujanGcdClassCoeffRat 154 h
          * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 154) : ℕ)
              • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 154 7 h
                  - ramanujanGcdClassWindowAverageRat X0 154 h
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 21 7
                  - ramanujanGcdClassWindowAverageRat X0 21 7
                      * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 154 154 h
                  + ramanujanGcdClassWindowAverageRat X0 21 7
                      * ramanujanGcdClassWindowAverageRat X0 154 h
                      * evenRamanujanBlockCountRat 21 154))
      ) = (∑ h ∈ periodicMainPair_21_154_X1000000_rowChunk_7_1, periodicMainPair_21_154_X1000000_rowPartValue_7_1 h) := by
    apply Finset.sum_congr rfl
    intro h hh
    simp [periodicMainPair_21_154_X1000000_rowChunk_7_1] at hh
    rcases hh with rfl
    · simpa [periodicMainPair_21_154_X1000000_rowPartValue_7_1] using periodicMainPair_21_154_X1000000_term_7_2
  rw [hsum]
  norm_num [periodicMainPair_21_154_X1000000_rowChunk_7_1, periodicMainPair_21_154_X1000000_rowPartValue_7_1]

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
