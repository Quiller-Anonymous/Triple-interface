import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk050
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk051
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk052
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk053
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk054
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk055
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk056
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk057
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk058
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroCoprimeCoreResidualChunk059

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

/- Generated assembly group for coprime-core residual chunks 050..059. -/

def PeriodicMainZeroCoprimeCoreResidualGroup005Pairs : Finset (ℕ × ℕ) :=
  (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk050Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk051Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk052Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk053Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk054Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk055Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk056Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk057Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk058Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk059Pairs)

theorem PeriodicMainZeroCoprimeCoreResidualGroup005_value_on_records :
    ∀ p : (ℕ × ℕ), p ∈ PeriodicMainZeroCoprimeCoreResidualGroup005Pairs →
      surrogatePeriodicMainActiveOrderedPairSummandRat X0 p = 0 := by
  intro p hp
  change p ∈ (((((((((PeriodicMainRecordsZeroCoprimeCoreResidualChunk050Pairs ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk051Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk052Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk053Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk054Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk055Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk056Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk057Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk058Pairs) ∪ PeriodicMainRecordsZeroCoprimeCoreResidualChunk059Pairs) at hp
  have hsplit1 := Finset.mem_union.mp hp
  rcases hsplit1 with hprev1 | h9
  ·
    have hsplit2 := Finset.mem_union.mp hprev1
    rcases hsplit2 with hprev2 | h8
    ·
      have hsplit3 := Finset.mem_union.mp hprev2
      rcases hsplit3 with hprev3 | h7
      ·
        have hsplit4 := Finset.mem_union.mp hprev3
        rcases hsplit4 with hprev4 | h6
        ·
          have hsplit5 := Finset.mem_union.mp hprev4
          rcases hsplit5 with hprev5 | h5
          ·
            have hsplit6 := Finset.mem_union.mp hprev5
            rcases hsplit6 with hprev6 | h4
            ·
              have hsplit7 := Finset.mem_union.mp hprev6
              rcases hsplit7 with hprev7 | h3
              ·
                have hsplit8 := Finset.mem_union.mp hprev7
                rcases hsplit8 with hprev8 | h2
                ·
                  have hsplit9 := Finset.mem_union.mp hprev8
                  rcases hsplit9 with h0 | h1
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk050_value_on_records p h0
                  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk051_value_on_records p h1
                · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk052_value_on_records p h2
              · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk053_value_on_records p h3
            · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk054_value_on_records p h4
          · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk055_value_on_records p h5
        · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk056_value_on_records p h6
      · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk057_value_on_records p h7
    · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk058_value_on_records p h8
  · exact PeriodicMainRecordsZeroCoprimeCoreResidualChunk059_value_on_records p h9

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
