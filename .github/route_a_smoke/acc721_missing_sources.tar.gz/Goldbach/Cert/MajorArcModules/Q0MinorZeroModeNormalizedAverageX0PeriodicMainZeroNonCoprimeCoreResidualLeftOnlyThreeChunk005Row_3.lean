import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk005Row_3Part0
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk005Row_3Part1
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk005Row_3Part2
import Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverageX0PeriodicMainZeroNonCoprimeCoreResidualLeftOnlyThreeChunk005Row_3Part3

set_option maxHeartbeats 0
set_option maxRecDepth 100000
set_option linter.constructorNameAsVariable false

namespace Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage

open Goldbach
open Goldbach.BankParams
open Goldbach.Windows

theorem periodicMainPair_21_91_X1000000_divRight_for_row_3 : Nat.divisors 91 = ([1, 7, 13, 91] : List ℕ).toFinset := by
  decide

theorem periodicMainPair_21_91_X1000000_row_3 :
    (∑ h ∈ Nat.divisors 91,
      ramanujanGcdClassCoeffRat 21 3 * ramanujanGcdClassCoeffRat 91 h
        * ((((H + 1) / centeredRamanujanPairBlockPeriod 21 91) : ℕ)
            • (rawEvenRamanujanGcdClassPairBlockResolvedCountRat X0 21 91 3 h
                - ramanujanGcdClassWindowAverageRat X0 91 h
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 21 3
                - ramanujanGcdClassWindowAverageRat X0 21 3
                    * rawEvenRamanujanGcdClassBlockPeriodicCountRat X0 21 91 91 h
                + ramanujanGcdClassWindowAverageRat X0 21 3
                    * ramanujanGcdClassWindowAverageRat X0 91 h
                    * evenRamanujanBlockCountRat 21 91))
    ) = (-468 : ℚ) / 2778889 := by
  rw [periodicMainPair_21_91_X1000000_divRight_for_row_3]
  have hset : ([1, 7, 13, 91] : List ℕ).toFinset = (((periodicMainPair_21_91_X1000000_rowChunk_3_0 ∪ periodicMainPair_21_91_X1000000_rowChunk_3_1) ∪ periodicMainPair_21_91_X1000000_rowChunk_3_2) ∪ periodicMainPair_21_91_X1000000_rowChunk_3_3) := by
    native_decide
  rw [hset]
  rw [Finset.sum_union (by native_decide : Disjoint ((periodicMainPair_21_91_X1000000_rowChunk_3_0 ∪ periodicMainPair_21_91_X1000000_rowChunk_3_1) ∪ periodicMainPair_21_91_X1000000_rowChunk_3_2) periodicMainPair_21_91_X1000000_rowChunk_3_3)]
  rw [Finset.sum_union (by native_decide : Disjoint (periodicMainPair_21_91_X1000000_rowChunk_3_0 ∪ periodicMainPair_21_91_X1000000_rowChunk_3_1) periodicMainPair_21_91_X1000000_rowChunk_3_2)]
  rw [Finset.sum_union (by native_decide : Disjoint periodicMainPair_21_91_X1000000_rowChunk_3_0 periodicMainPair_21_91_X1000000_rowChunk_3_1)]
  rw [periodicMainPair_21_91_X1000000_rowPart_3_0, periodicMainPair_21_91_X1000000_rowPart_3_1, periodicMainPair_21_91_X1000000_rowPart_3_2, periodicMainPair_21_91_X1000000_rowPart_3_3]
  norm_num

end Goldbach.Cert.MajorArcModules.Q0MinorZeroModeNormalizedAverage
