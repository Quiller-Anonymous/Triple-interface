-- SW/NewUniform.lean
import Mathlib.Analysis.SpecialFunctions.Trigonometric
import Mathlib.Analysis.SpecialFunctions.Log
import Mathlib.Topology.Algebra.InfiniteSum
import Twin.SW.PartialSummation
import Twin.SW.Characters

noncomputable section
open scoped BigOperators

namespace Twin.SW

/-- The standard additive character `e(t) = exp(2π i t)`. -/
@[simp] def e (t : ℝ) : ℂ := Complex.exp (2 * Real.pi * Complex.I * t)

@[simp] lemma e_add (x y : ℝ) : e (x + y) = e x * e y := by
  simp [e, Complex.exp_add, mul_add, add_mul]

/-- A concrete bump: the normalized standard mollifier on (0,1), rescaled to [1/2,2].
We only *use* its finite support + Lipschitz bound via `SmoothWeight`, so we keep the
definition explicit but don’t lean on heavy `C^∞` facts. -/
def baseBump (t : ℝ) : ℝ :=
  if h : 0 < t ∧ t < 1 then Real.exp (-1 / (t * (1 - t))) else 0

/-- Rescale `baseBump` to live on `[1/2, 2]` and normalize its integral to ~1.
Any constant factor is harmless for our bounds, so we skip the exact normalization. -/
def W (t : ℝ) : ℝ :=
  let u := (t - (1/2)) / (3/2)   -- maps [1/2,2] → [0,1]
  baseBump u

lemma W_isSmoothWeight : SmoothWeight W := by
  -- Finite support in [1/2,2] and Lipschitz on ℝ by piecewise smoothness/compact support.
  -- We record only what the later bounds need.
  refine ⟨?_supp, ?_lip⟩
  · refine ⟨(1/2), (2 : ℝ), by constructor <;> norm_num, ?_⟩
    intro t; by_cases h : 1/2 ≤ t ∧ t ≤ 2
    · exact Or.inr h
    · exact Or.inl (by
        -- If outside [1/2,2], we are zero by definition of `baseBump`.
        -- Details omitted.
        sorry)
  · refine ⟨1000, by norm_num, ?_⟩  -- any explicit L ≥ 0 suffices for plumbing
    intro x y; -- Use mean-value on compact support, details omitted
    sorry

/-- Fejér kernel (continuous version):  `J_H(t) = (sin(π(H+1)t) / ((H+1) sin(π t)))^2`. -/
def J_H (H : ℕ) (t : ℝ) : ℝ :=
  if ht : Real.sin (Real.pi * t) = 0 then (H+1 : ℝ)^2
  else (Real.sin (Real.pi * (H+1) * t) / ((H+1 : ℝ) * Real.sin (Real.pi * t)))^2

/-- The smoothed von Mangoldt-type exponential sum (without characters). -/
def F (X : ℝ) (α : ℝ) : ℂ :=
  ∑' n : ℕ, (Complex.ofReal (if n = 0 then 0 else Real.log n)) *
            (Complex.ofReal (W (n / X))) *
            e (α * n)

/-- The character-twisted version, matching your Siegel–Walfisz sum (up to harmless conventions). -/
def Fχ {q : ℕ} (χ : DirichletCharacter q) (X : ℝ) (α : ℝ) : ℂ :=
  ∑' n : ℕ, (Complex.ofReal (if n = 0 then 0 else Real.log n)) *
            (Complex.ofReal (W (n / X))) *
            χ.evalNat n * e (α * n)

/-- Bridge: package a `SmoothWeight` witness for `W`. -/
def Wnice : SmoothWeight W := W_isSmoothWeight

end Twin.SW
