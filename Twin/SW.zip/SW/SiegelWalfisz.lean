import Twin.SW.Characters

noncomputable section
open scoped BigOperators

namespace Twin.SW

/-- Dirichlet characters modulo `q` with complex values. -/
abbrev DirichletCharacter (q : ℕ) := _root_.DirichletCharacter ℂ q

/-- Twisted “ψ-like” sum weighted by `log n` (a stand-in for Λ in this plumbing).
You already used this signature in your file; I keep it byte-for-byte compatible. -/
def twistedVonMangoldtSum {q : ℕ} (χ : DirichletCharacter q) (x : ℝ) : ℂ :=
  ∑ n in Finset.Icc 1 ⌊x⌋₊,
      (Complex.ofReal (Real.log (n : ℝ))) * χ.evalNat n

/-- Uniform Siegel–Walfisz bound in the polylogarithmic range. -/
class SiegelWalfisz (A B : ℝ) : Prop :=
  (C : ℝ)
  (bound :
    ∀ ⦃x : ℝ⦄, 3 ≤ x →
    ∀ ⦃q : ℕ⦄, 1 ≤ q ∧ (q : ℝ) ≤ (Real.log x)^B →
    ∀ (χ : DirichletCharacter q),
      Complex.abs (twistedVonMangoldtSum χ x)
        ≤ C * x / (Real.log x)^A)

end Twin.SW
