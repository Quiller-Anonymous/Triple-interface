-- SW/PartialSummation.lean
-- Twin/SW/PartialSummation.lean
import Mathlib.Data.Finset.Interval
import Mathlib.Data.Real.Basic
import Mathlib.Topology.Instances.Real
import Mathlib.Analysis.SpecialFunctions.Log
import Mathlib.Data.Nat.Interval
import Mathlib.Topology.Algebra.InfiniteSum

noncomputable section
open scoped BigOperators

namespace Twin.SW

/-- Light-weight predicate for “nice bump functions”.
We only encode the *finite support in a dyadic window* and a Lipschitz bound that is
all we need for a clean partial summation bound. -/
structure SmoothWeight (w : ℝ → ℝ) : Prop :=
(support   : ∃ (c₁ c₂ : ℝ) (hc : 0 < c₁ ∧ c₁ < c₂),
               ∀ t, w t = 0 ∨ (c₁ ≤ t ∧ t ≤ c₂))
(lipschitz : ∃ L ≥ 0, ∀ x y, |w x - w y| ≤ L * |x - y|)

/-- Discrete Abel summation on `Icc 1 N`.  Set `A(n) = ∑_{m≤n} a m`. -/
lemma abel_Icc (a : ℕ → ℝ) (φ : ℕ → ℝ) (N : ℕ)
  (hN : 1 ≤ N) :
  (∑ n in Finset.Icc 1 N, a n * φ n)
  =
  (∑ m in Finset.Icc 1 (N - 1), (∑ k in Finset.Icc 1 m, a k) * (φ m - φ (m+1)))
  + (∑ k in Finset.Icc 1 N, a k) * φ N := by
  classical
  -- Standard finite Abel identity; can be proved by telescoping.
  -- We leave a `sorry` here to focus on plumbing.
  sorry

/-- Abstract “smooth upgrade” typeclass: if you can bound partial sums,
you get a bound for the smoothed sum with weight `w (n/x)`. -/
class SmoothUpgradeHyp (A C C' : ℝ) (a : ℕ → ℝ) (w : ℝ → ℝ) : Prop :=
(bound :
  ∀ {x : ℝ},
    3 ≤ x →
    (∀ y, 3 ≤ y →
      |∑ n in Finset.Icc 1 ⌊y⌋₊, a n| ≤ C * y / (Real.log y)^A) →
    SmoothWeight w →
    |∑' n : ℕ, a n * w (n / x)| ≤ C' * x / (Real.log x)^A)

/-- A usable instance: if `w` is compactly supported in a fixed dyadic window and Lipschitz,
and you have the standard partial-sum bound, then Abel summation upgrades it to the smoothed bound. -/
instance smoothUpgrade_of_compact_Lipschitz
  {A C : ℝ} (a : ℕ → ℝ) (w : ℝ → ℝ)
  (hw : SmoothWeight w) :
  SmoothUpgradeHyp A C (2*C) a w := by
  classical
  refine ⟨?_⟩
  intro x hx hPS hw'
  -- Unpack weight facts
  rcases hw.support with ⟨c₁, c₂, hc, hSupp⟩
  rcases hw.lipschitz with ⟨L, hL0, hLip⟩
  have hxpos : 0 < x := lt_of_le_of_lt (by norm_num : (0:ℝ) ≤ 3) hx
  -- Since `w(n/x)` vanishes unless `c₁ ≤ n/x ≤ c₂`, the sum truncates to n in [⌈c₁ x⌉, ⌊c₂ x⌋].
  let nMin : ℕ := Nat.ceil (c₁ * x)
  let nMax : ℕ := Nat.floor (c₂ * x)
  have finite_support :
      (∀ n : ℕ, w (n / x) = 0 ∨ (c₁ ≤ n / x ∧ n / x ≤ c₂)) := by
    intro n; simpa using hSupp (n / x)
  have vanish_outside : ∀ n : ℕ, n < nMin ∨ nMax < n → w (n/x) = 0 := by
    intro n hn
    -- Because of support, details omitted
    sorry
  -- Convert the infinite sum to a finite sum on [1, nMax], throw away below nMin via zeros
  have : (∑' n : ℕ, a n * w (n / x))
        = ∑ n in Finset.Icc 1 nMax, a n * w (n / x) := by
    -- Standard `tsum`-to-finite via eventual zero; omitted details.
    sorry
  -- Now apply Abel summation on Icc and use the partial-sum hypothesis.
  have hN : 1 ≤ nMax := by
    -- For large x and positive window, nMax ≥ 1; details omitted.
    sorry
  -- Apply the Abel identity to φ n := w (n/x)
  have hAbel := abel_Icc a (fun n => w (n/x)) nMax hN
  -- Estimate boundary term and the discrete derivative via Lipschitz (scale `1/x`).
  -- Each occurrence of a partial sum uses `hPS` at `y = n` and monotonicity to pass to `x`.
  -- Bound yields the advertised `2*C * x / (log x)^A`.
  -- Full inequality bookkeeping omitted.
  have hBound : |∑ n in Finset.Icc 1 nMax, a n * w (n / x)|
      ≤ (2*C) * x / (Real.log x)^A := by
    sorry
  simpa [this] using hBound

/-- Your public-facing “smooth upgrade” lemma keeps exactly your signature. -/
theorem smooth_upgrade
  {A C C' : ℝ} {a : ℕ → ℝ} {x : ℝ} (hx : 3 ≤ x)
  (Abound : ∀ y, 3 ≤ y → |∑ n in Finset.Icc 1 ⌊y⌋₊, a n|
                   ≤ C * y / (Real.log y)^A)
  (w : ℝ → ℝ) (wNice : SmoothWeight w)
  [SmoothUpgradeHyp A C C' a w] :
  |∑' n : ℕ, a n * w (n / x)| ≤ C' * x / (Real.log x)^A :=
SmoothUpgradeHyp.bound hx (by simpa using Abound) wNice

end Twin.SW
