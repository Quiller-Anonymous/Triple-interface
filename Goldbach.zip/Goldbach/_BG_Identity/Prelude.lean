import Mathlib  -- (you can slim later; keep it while stabilizing)
import Goldbach.BankParams
import Goldbach.Windows
import Goldbach.AO_Major          -- errAO
import Goldbach.BG_Bank
import Goldbach.BG_Operator
import Goldbach.TypeI_Tent
import Goldbach.MainTerm
import Goldbach.SingularSeries
import Goldbach.BG_Operator
import Goldbach.MainTerm
import Mathlib.Tactic
import Mathlib.Algebra.BigOperators.Finprod
import Mathlib.Algebra.BigOperators.Module
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Group.Defs
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.Calculus.ParametricIntegral
import Mathlib.Analysis.Normed.Group.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic

open MeasureTheory Set Filter
open Goldbach
open scoped BigOperators
open Goldbach.Windows
open Goldbach.BG_Bank
open Goldbach.BG_Operator
open Goldbach.TypeI_Tent
open Real
open Classical

namespace Goldbach.BG_Identity




end Goldbach.BG_Identity
