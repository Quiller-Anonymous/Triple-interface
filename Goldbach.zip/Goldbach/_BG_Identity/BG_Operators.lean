import Goldbach.BG_Identity.BG_PrimePower

namespace Goldbach.BG_Identity

/-- Constant reference payload: sigma·weight_mass divided by kernel mass on the window. -/
noncomputable def Pref (X N : ℕ) (k : ℤ) : ℝ :=
  if h : Int.natAbs k ≤ H then
    (SingularSeries.sigma N * AO_Major.weight_mass X) / mass_BG
  else 0

/-- Constant-reference in-window operator. -/
noncomputable def conv_ref_const (X N : ℕ) : ℝ :=
  Finset.sum S_BG (fun k => Pref X N k * K_full k)

/-- Reference in-window operator: equals the main term on the window, conv_ref off it. -/
noncomputable def bankOp_ref (X N : ℕ) : ℝ :=
  if h : X0 ≤ X ∧ N ∈ EvenIn X H then
    (Goldbach.MainTerm.M Goldbach.MainTerm.C2_numeric) N
  else
    conv_ref X N

/-- Exposed full bank operator: equals the raw count on the window, conv_full off it. -/
noncomputable def bankOp_full (X N : ℕ) : ℝ :=
  if h : X0 ≤ X ∧ N ∈ EvenIn X H then
    (Goldbach.Rep.R N : ℝ)
  else
    conv_full X N

/-- Convolutional full bank projector using the full tent kernel on |k| ≤ U. -/
noncomputable def conv_full (X N : ℕ) : ℝ :=
  Finset.sum bandU (fun k => P_BG X N k * K_full k)

/-- Type-I tail: sum of payload×full kernel over the outer band `H < |k| ≤ U`. -/
noncomputable def errTI (X N : ℕ) : ℝ :=
  Finset.sum outerBand (fun k => P_BG X N k * K_full k)


/-- In-window operator deviation (currently zero with bankOp_ref = conv_ref). -/
noncomputable def errBG (X N : ℕ) : ℝ := 0

/-- Mass of the in-window kernel. -/
noncomputable def mass_BG : ℝ := Finset.sum S_BG (fun k => K_full k)

/-- Convolutional in-window bank operator: restriction of the full tent to |k| ≤ H. -/
noncomputable def conv_ref (X N : ℕ) : ℝ :=
  Finset.sum S_BG (fun k => P_BG X N k * K_full k)

/-- Simple upper bound on the tail mass using cardinality and maximal outer value. -/
noncomputable def C_tail_bound : ℝ :=
  (2 * (Ucut - H) : ℝ) * ((1 - ((H+1 : ℝ) / (Ucut : ℝ))) / (Ucut : ℝ))

/-- Exact tail mass constant for the current tent: definitionally the outer-band sum. -/
noncomputable def C_tail : ℝ := Finset.sum outerBand (fun k => K_full k)

/-- Closed-form tail mass for the normalized linear tent. -/
noncomputable def C_tail_closed : ℝ :=
  1 - ((1 + 2 * H : ℝ) / (Ucut : ℝ)) + ((H * (H + 1) : ℝ) / (Ucut : ℝ)^2)

/-- Off-channel placeholder (kept at 0 here to avoid cyclic imports). -/
noncomputable def E_off (_X _N : ℕ) : ℝ := 0

/-- Temporary choices for the other channels so that the identity is rfl. -/
noncomputable def E_kernel (X N : ℕ) : ℝ := 0
noncomputable def E_mellin (X N : ℕ) : ℝ := 0
noncomputable def E_smooth (X N : ℕ) : ℝ := AO_Major.errAO X N - E_off X N

/-- Full-bank projector using the Λ/log payload (Route A). -/
noncomputable def conv_full_divlog (U X N : ℕ) : ℝ :=
  Finset.sum (Finset.Icc (-(U:ℤ)) (U:ℤ))
    (fun k => Goldbach.Deweighting.P_divlog X N k * K_full k)

noncomputable def conv_full (X N : ℕ) : ℝ :=
  Finset.sum S_full (fun k => K_full k * P_BG X N k)

/-- Convolution with the “reference/inner” tent on `|k| ≤ H`. (Using the same K on the inner band.) -/
noncomputable def conv_ref (X N : ℕ) : ℝ :=
  Finset.sum S_BG (fun k => K_full k * P_BG X N k)

/-- Type-I tail: the outer band contribution. -/
noncomputable def errTI (X N : ℕ) : ℝ :=
  Finset.sum outerBand (fun k => K_full k * P_BG X N k)


end Goldbach.BG_Identity
