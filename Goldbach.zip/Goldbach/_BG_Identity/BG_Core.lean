import Mathlib
import Goldbach.BankParams
import Goldbach.BG_Identity.Prelude

open scoped BigOperators

namespace Goldbach.BG_Identity

/-- The BG window half-width. -/
abbrev H : ℕ := BankParams.H

/-- Cutoff for the full tent kernel (your old `H + (H+99)/100`). -/
noncomputable def Ucut : ℕ := H + (H + 99) / 100

/-- The BG index set `[-H, H] ⊆ ℤ`. -/
noncomputable def S_BG : Finset ℤ := Finset.Icc (-(H : ℤ)) (H : ℤ)

/-- The full band `[-Ucut, Ucut] ⊆ ℤ`. -/
noncomputable def bandU : Finset ℤ := Finset.Icc (-(Ucut : ℤ)) (Ucut : ℤ)

/-- A normalized tent kernel with peak `1/U`.  Using `max` avoids any `decide`/`if` plumbing. -/
noncomputable def K_full_raw (U : ℕ) (k : ℤ) : ℝ :=
  (max (1 - (k.natAbs : ℝ) / (U : ℝ)) 0) / (U : ℝ)

noncomputable def K_full (k : ℤ) : ℝ := K_full_raw Ucut k

/-- In the original file this was a separate name; keep it for compatibility. -/
noncomputable def tentFullWeight (k : ℤ) : ℝ := K_full k

noncomputable def tentFullMass : ℝ := ∑ k ∈ S_BG, tentFullWeight k

lemma K_full_raw_nonneg (U : ℕ) (k : ℤ) : 0 ≤ K_full_raw U k := by
  have hU : 0 ≤ (U : ℝ) := by exact_mod_cast (Nat.zero_le U)
  have hmax : 0 ≤ max (1 - (k.natAbs : ℝ) / (U : ℝ)) 0 := by
    exact le_max_right _ _
  exact div_nonneg hmax hU

lemma K_full_nonneg (k : ℤ) : 0 ≤ K_full k := by
  simpa [K_full] using K_full_raw_nonneg (U := Ucut) (k := k)

lemma K_full_raw_le_one_div (U : ℕ) (k : ℤ) (hUpos : 0 < (U : ℝ)) :
    K_full_raw U k ≤ 1 / (U : ℝ) := by
  have hmax_le : max (1 - (k.natAbs : ℝ) / (U : ℝ)) 0 ≤ (1 : ℝ) := by
    refine max_le ?_ ?_
    · have h1 : 0 ≤ (k.natAbs : ℝ) / (U : ℝ) := div_nonneg (Nat.cast_nonneg _) (le_of_lt hUpos)
      linarith
    · exact zero_le_one
  have hU : 0 ≤ (U : ℝ) := le_of_lt hUpos
  exact div_le_div_of_nonneg_right hmax_le hU

lemma abs_K_full_raw_le_one_div (U : ℕ) (k : ℤ) (hUpos : 0 < (U : ℝ)) :
    |K_full_raw U k| ≤ 1 / (U : ℝ) := by
  have hnonneg : 0 ≤ K_full_raw U k := K_full_raw_nonneg (U := U) (k := k)
  simpa [abs_of_nonneg hnonneg] using K_full_raw_le_one_div (U := U) (k := k) hUpos

lemma abs_K_full_le_one_div (k : ℤ) (hUpos : 0 < (Ucut : ℝ)) :
    |K_full k| ≤ 1 / (Ucut : ℝ) := by
  simpa [K_full] using abs_K_full_raw_le_one_div (U := Ucut) (k := k) hUpos

/-- Generic “cap times sum of abs” inequality for finite sums. -/
lemma abs_sum_mul_le {α : Type} [DecidableEq α] (s : Finset α)
    (a b : α → ℝ) (C : ℝ)
    (hCap : ∀ k ∈ s, |a k| ≤ C) :
    |Finset.sum s (fun k => a k * b k)| ≤ C * Finset.sum s (fun k => |b k|) := by
  classical
  have htri :
      |Finset.sum s (fun k => a k * b k)|
        ≤ Finset.sum s (fun k => |a k * b k|) := by
        exact Finset.abs_sum_le_sum_abs (s := s) (f := fun k => a k * b k)
  have hpoint : ∀ k ∈ s, |a k * b k| ≤ C * |b k| := by
    intro k hk
    have ha : |a k| ≤ C := hCap k hk
    simpa [abs_mul, mul_assoc] using (mul_le_mul_of_nonneg_right ha (abs_nonneg (b k)))
  have hsum :
      Finset.sum s (fun k => |a k * b k|) ≤ Finset.sum s (fun k => C * |b k|) :=
    Finset.sum_le_sum (fun k hk => hpoint k hk)
  have hfactor : Finset.sum s (fun k => C * |b k|) = C * Finset.sum s (fun k => |b k|) := by
    simpa using (Finset.mul_sum s (fun k => |b k|) C).symm
  exact le_trans htri (le_trans hsum (by simpa [hfactor]))

end Goldbach.BG_Identity
