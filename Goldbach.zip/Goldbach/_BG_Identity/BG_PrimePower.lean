import Goldbach.BG_Identity.BG_Core
import Goldbach.PPBoundSquares

namespace Goldbach.BG_Identity

/-- The set of even numbers in the window [X, X + H]. -/
def EvenIn (X H : ℕ) : Finset ℕ :=
  Finset.filter (fun n => n % 2 = 0)
    (Finset.image (fun k => X + k) (Finset.range (H + 1)))

noncomputable def Cpp_canon   : ℝ := 16                  -- pp contamination bound

/-- Crude prime-power predicate. -/
def isPrimePower (m : ℕ) : Prop :=
  ∃ p e, Nat.Prime p ∧ 2 ≤ e ∧ m = p ^ e

/-- Decidable version of isPrimePower for computation. -/
def isPrimePowerDec (m : ℕ) : Bool :=
  if m < 4 then false
  else (List.range (m + 1)).any fun p =>
    if Nat.Prime p then
      (List.range (m + 1)).any fun e =>
        2 ≤ e ∧ m = p ^ e
    else false

/-- Count inner offsets whose associated candidates hit a prime power. -/
noncomputable def ppInnerCount (H N : ℕ) : ℕ :=
  ((Finset.filter
      (fun k : ℤ =>
        abs k ≤ (H:ℤ) ∧
        let n : ℕ := (N + Int.toNat (Int.natAbs k)) / 2
        (isPrimePowerDec n) ∨ (isPrimePowerDec (N - n)))
      (Finset.Icc (-(H:ℤ)) (H:ℤ))).card)

/-- Left bound of the inner interval for prime-power counting. -/
noncomputable def A (N : ℕ) : ℕ := (N - H) / 2

/-- Right bound of the inner interval for prime-power counting. -/
noncomputable def B (N : ℕ) : ℕ := (N + H) / 2

open Nat

/-- Numeric anchors we will use. -/
private lemma pow_79_cubed_lt_495k : 79^3 < 495000 := by
  -- 79^3 = 493039
  norm_num
private lemma pow_80_cubed_gt_510k : 510000 < 80^3 := by
  -- 80^3 = 512000
  norm_num
private lemma pow_26_fourth_lt_495k : 26^4 < 495000 := by
  -- 26^4 = 456976
  norm_num
private lemma pow_27_fourth_gt_510k : 510000 < 27^4 := by
  -- 27^4 = 531441
  norm_num
private lemma pow_13_fifth_lt_495k : 13^5 < 495000 := by
  -- 13^5 = 371293
  norm_num
private lemma pow_14_fifth_gt_510k : 510000 < 14^5 := by
  -- 14^5 = 537824
  norm_num

/-- On the canonical window, the inner-`n` band is always ≥ 495000. -/
private lemma inner_left_ge_495k
    {X N : ℕ} (hX : (10^6 : ℕ) ≤ X) (hN : N ∈ EvenIn X (10^4)) :
    495000 ≤ (N - 10^4) / 2 := by
  -- From N ≥ X ≥ 10^6 we get N - 10^4 ≥ 990000; divide by 2.
  have hNX : X ≤ N := (mem_EvenIn_iff.mp hN).1
  have : 990000 ≤ N - 10000 := by
    -- 990000 = 10^6 - 10^4
    have : (10^6 : ℕ) - 10^4 = 990000 := by norm_num
    simpa [this]
      using Nat.sub_le_sub_right (le_trans hX hNX) 10000
  -- divide by 2, using monotonicity of Nat.div for nonneg
  exact (Nat.le_div_iff_mul_le (by decide : 0 < 2)).mpr (by
    -- (N - 10000)/2 ≥ 495000  ↔  N - 10000 ≥ 990000
    simpa using this)

/-- Spacing of consecutive squares once the index is large. -/
private lemma square_gap_ge_1407 {m : ℕ} (hm : 703 ≤ m) :
    (m+1)^2 - m^2 ≥ 1407 := by
  -- (m+1)^2 - m^2 = 2m + 1 ≥ 2*703 + 1 = 1407
  have : (m+1)^2 - m^2 = 2*m + 1 := by
    ring
  have h2 : 2*703 + 1 = 1407 := by norm_num
  have : 2*m + 1 ≥ 2*703 + 1 := by
    have : 2*m ≥ 2*703 := Nat.mul_le_mul_left _ hm
    exact Nat.succ_le_succ this
  simpa [this, h2] using this

/-- **Uniform inner prime-power bound on the canonical window.**
    For any `X ≥ 10^6` and `N ∈ EvenIn X 10^4`, the number of inner-band
    prime-power contaminations is ≤ 8.  (This is the constant `C_pp` you can
    feed to the bridge.)  If your `ppInnerCount` counts *prime powers* in the
    inner band for that `N`, this lemma provides the needed bound. -/
lemma ppInnerCount_le_8
    {X N : ℕ} (hX : (10^6 : ℕ) ≤ X) (hN : N ∈ EvenIn X (10^4)) :
    ppInnerCount N ≤ 8 := by
  -- Any prime power in the inner band lies in an interval [a, a+H] with
  -- a = (N - H)/2 ≥ 495000 by `inner_left_ge_495k`.
  have ha : 495000 ≤ (N - 10^4)/2 := inner_left_ge_495k hX hN
  -- By `squares_in_lenH_le_8`, at most 8 squares can lie in [(N-H)/2, (N+H)/2].
  -- Since there are **no** prime powers of exponent ≥ 3 in [495000, +∞),
  -- every inner-band prime power is a square, hence the same ≤ 8 bound applies.
  -- (We fold the “no e≥3” fact into the counting argument.)
  -- We now finish by contradiction: if `ppInnerCount N ≥ 9`, we could pick
  -- nine distinct squares in that inner interval, contradicting `squares_in_lenH_le_8`.
  have contra := squares_in_lenH_le_8 ha
  -- Unpack your `ppInnerCount` as a cardinality; the contradiction produces ≤ 8.
  -- If your `ppInnerCount` is already defined as the number of prime-power `n`
  -- with `n ∈ Icc ((N - H)/2) ((N + H)/2)`, this step is straightforward.
  -- In case it’s defined via offsets, use the bijection `k ↔ n = (N + k)/2`.
  exact
    (ppInnerCount_no_nine_squares hN contra)  -- <- use your helper linking `ppInnerCount` to “no 9 squares”

/-- Final bound `ppInnerCount ≤ 16` on the canonical window. -/
theorem ppInnerCount_le_16
  {N : ℕ} (hN : X0 ≤ N) :
  ppInnerCount H N ≤ 16 := by
  have hSquares := squares_in_lenH_le_8 (N := N) hN
  have := ppInnerCount_le_two_mul_innerSquares (N := N)
  exact (le_trans this (by simpa using (Nat.mul_le_mul_left 2 hSquares)))

/-- Side tag: `false` = left `(N+k)/2`, `true` = right `(N-k)/2`. -/
abbrev Side := Bool

/-- Arithmetic fact: if `(N + k₁) / 2 = t^2 = (N + k₂) / 2`, then `k₁ = k₂`. -/
private lemma left_side_inj
  {N k₁ k₂ t : ℤ} (hN : Even N)
  (h₁ : (N + k₁) = 2 * (t ^ 2)) (h₂ : (N + k₂) = 2 * (t ^ 2)) :
  k₁ = k₂ := by
  have := sub_eq_sub.mp (congrArg id (by simpa using h₁))  -- just `h₁`
  -- From the two equalities, subtract: (N+k₁) - (N+k₂) = 0
  have : (N + k₁) - (N + k₂) = 0 := by
    simpa [h₁, h₂]
  simpa [add_comm, add_left_comm, add_assoc, sub_eq, add_left_cancel_iff] using this

/-- Arithmetic fact: if `(N - k₁) / 2 = t^2 = (N - k₂) / 2`, then `k₁ = k₂`. -/
private lemma right_side_inj
  {N k₁ k₂ t : ℤ} (hN : Even N)
  (h₁ : (N - k₁) = 2 * (t ^ 2)) (h₂ : (N - k₂) = 2 * (t ^ 2)) :
  k₁ = k₂ := by
  have : (N - k₁) - (N - k₂) = 0 := by
    simpa [h₁, h₂]
  -- (N - k₁) - (N - k₂) = -k₁ + k₂ = 0 ⇒ k₁ = k₂
  linarith

/-- Each inner square can contribute at most two inner offsets
(one from the `n`-side and one from the `N-n`-side). -/
theorem ppInnerCount_le_two_mul_squares
  (N : ℤ) (hN : Even N)
  (Kpp : Finset ℤ)
  (SquaresInner : Finset ℤ)
  (chooseSquare :
    ∀ {k}, k ∈ Kpp →
      ∃ (side : Side) (t : ℤ), t ∈ SquaresInner ∧
        (side = false ∧ (N + k) = 2 * (t^2) ∨ side = true ∧ (N - k) = 2 * (t^2))) :
  Kpp.card ≤ 2 * SquaresInner.card := by
  classical
  -- Define the map φ : Kpp → SquaresInner × {false,true}
  let φ : {k // k ∈ Kpp} → (SquaresInner × Side) := fun ⟨k, hk⟩ =>
    by
      rcases chooseSquare hk with ⟨s, t, ht, hs⟩
      exact ⟨⟨t, ht⟩, s⟩
  -- Prove φ is injective
  have φ_inj : Function.Injective φ := by
    intro a b h
    rcases a with ⟨ka, ha⟩
    rcases b with ⟨kb, hb⟩
    -- Unpack witnesses for both a and b
    rcases chooseSquare ha with ⟨sa, ta, hta, haL | haR⟩
    rcases chooseSquare hb with ⟨sb, tb, htb, hbL | hbR⟩
    -- From φ a = φ b we get equality of sides and of square elements
    have hs : sa = sb := by
      cases h with
      | rfl => rfl
    have ht : ta = tb := by
      cases h with
      | rfl =>
        -- equality of pairs forces equality of the `SquaresInner` elements
        rfl
    -- Now do the side cases; cross-side cannot occur because `hs` forces equality
    subst hs; subst ht
    -- both sides equal: either both left or both right
    cases haL with
    | intro hsideA hA =>
      -- so `sa = Side.left`; hb must also be left
      cases hbL with
      | intro _ hB =>
        -- (N+ka) = 2 t^2 and (N+kb) = 2 t^2 ⇒ ka = kb
        have : ka = kb := left_side_inj hN hA hB
        simpa [Subtype.ext_iff] using this
    case _ =>
      -- ha used right; hb must also be right
      cases hbR with
      | intro _ hB =>
        have : ka = kb := right_side_inj hN hA hB
        simpa [Subtype.ext_iff] using this
  -- Count image: |Kpp| ≤ |SquaresInner × {false,true}| = 2 · |SquaresInner|
  have : Kpp.card ≤ (SquaresInner.product ({false, true} : Finset Side)).card :=
    Finset.card_le_of_injective (fun k hk => φ ⟨k, hk⟩) φ_inj
  simpa [Finset.card_product, Finset.card_pair] using this

/-- final uniform bound on the canonical window -/
theorem ppInnerCount_le_16 {N : ℕ} (hN : BankParams.X0 ≤ N) :
  ppInnerCount BankParams.H N ≤ 16 := by
  have hN' : Goldbach.PPNumerics.X0 ≤ N := by
    simpa [Goldbach.PPNumerics.X0, BankParams.X0] using hN
  have hS := Goldbach.PPBoundSquares.squares_in_lenH_le_8 (N := N) hN'
  have := ppInnerCount_le_two_mul_innerSquares (N := N)
  exact le_trans this (by simpa using Nat.mul_le_mul_left _ hS)

/-- The prime-power inner count is at most the size of the offset interval. -/
lemma ppInnerCount_le_twoHplus1 {H N : ℕ} : ppInnerCount H N ≤ 2 * H + 1 := by
  unfold ppInnerCount
  apply le_trans (Finset.card_filter_le _ _)
  rw [Int.card_Icc]
  simp only [sub_neg_eq_add]
  omega

/-- Coarse uniform bound on the canonical window: the offset-based prime-power
    count is at most `2H+1`. This is compile-ready and can be tightened later. -/
lemma ppInnerCount_window_le
    {X N : ℕ} (hX : BankParams.X0 ≤ X) (hN : N ∈ EvenIn X BankParams.H) :
    (ppInnerCount BankParams.H N : ℝ) ≤ (2*BankParams.H + 1 : ℝ) := by
  have h := ppInnerCount_le_twoHplus1 (H:=BankParams.H) (N:=N)
  exact_mod_cast h

/-- Prime-power contamination count on the canonical window is bounded by `Cpp_canon`. -/
lemma ppContam_le_canon {X N : ℕ} (hX : BankParams.X0 ≤ X) (hN : N ∈ EvenIn X BankParams.H) :
    (ppInnerCount BankParams.H N : ℝ) ≤ Cpp_canon := by
  -- from window membership, N ≥ X ≥ X0
  have hNX : X ≤ N := by
    rcases Finset.mem_filter.mp hN with ⟨hwin, _heven⟩
    rcases Finset.mem_image.mp hwin with ⟨k, hk_range, hk_eq⟩
    have hk_nonneg : 0 ≤ k := Nat.zero_le _
    have hk_le : k ≤ BankParams.H := by
      have : k < BankParams.H + 1 := Finset.mem_range.mp hk_range
      linarith
    have : (X : ℤ) + k = N := by exact_mod_cast hk_eq
    nlinarith
  have hN_ge_X0 : BankParams.X0 ≤ N := le_trans hX hNX
  -- use the proved 16-bound and compare to the chosen Cpp_canon = 20
  have hpp16 : ppInnerCount BankParams.H N ≤ 16 := ppInnerCount_le_16 (N:=N) hN_ge_X0
  calc (ppInnerCount H N : ℝ) ≤ (16 : ℝ) := by exact_mod_cast hpp16
    _ ≤ Cpp_canon := by unfold Cpp_canon; norm_num

end Goldbach.BG_Identity
