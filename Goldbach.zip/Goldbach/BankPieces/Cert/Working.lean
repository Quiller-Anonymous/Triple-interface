import Mathlib
import Goldbach.Windows
import Goldbach.Rep
import Goldbach.MainTerm
import Goldbach.Analytic.NumericSigma

/-
Certificate stub for the working window.

Replace `bank_cert_bound` with a real proof that on the window
`X0 = 10^6`, `H = 10^4` you have
`|R N - M N| ≤ 0.01` for all even `N ∈ EvenIn X H` with `X ≥ X0`.
-/
namespace Goldbach.BankPieces.Cert.Working

open Goldbach.Analytic
open Goldbach.Windows
open Goldbach.Rep

axiom bank_cert_bound :
  ∀ {X N}, X0 ≤ X → N ∈ Goldbach.Windows.EvenIn X H →
    |(Goldbach.Rep.R N : ℝ) - (Goldbach.MainTerm.M C2_numeric) N| ≤ (0.01 : ℝ)

end Goldbach.BankPieces.Cert.Working
