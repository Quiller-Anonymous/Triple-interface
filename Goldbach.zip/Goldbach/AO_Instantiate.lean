import Goldbach.AO_Major
import Goldbach.AO_AssembleEnvelope
import Goldbach.AO_ErrorEnvelope
import Goldbach.AO_Models
import Goldbach.AO_KernelTail
import Goldbach.AO_MellinTrunc
import Goldbach.AO_SmoothLoss
import Goldbach.AO_OffDiag
import Goldbach.AO_Stages
import Goldbach.AO_McanonWiring
import Goldbach.BankParams
import Goldbach.Windows

namespace Goldbach.AO_Instantiate
open Goldbach
open Goldbach.AO_Models
open Goldbach.AO_Major
open Goldbach.AO_AssembleEnvelope

/-- Canonical channel functions used in the assembled AO envelope. -/
noncomputable def channels : Channels :=
{ E_kernel := Goldbach.AO_KernelTail.E_kernel
, E_mellin := Goldbach.AO_MellinTrunc.E_mellin
, E_smooth := Goldbach.AO_SmoothLoss.E_smooth
, E_off    := Goldbach.AO_OffDiag.E_off
}

/-- Canonical numeric caps (edit the numbers to your current budget split). -/
noncomputable def caps : Caps :=
{ δ_kernel := ((1252 : ℝ) / 10^6) * Goldbach.BG_Identity.C_tail_closed
, δ_mellin := Goldbach.AO_MellinTrunc.δ_mellin_canon
, δ_smooth := (0.0008 : ℝ)
, δ_off    := (3e-4 : ℝ)
, δ_kernel_nonneg := by
    have htail_val : Goldbach.BG_Identity.C_tail_closed = (99 : ℝ) / 1020100 := by
      norm_num [Goldbach.BG_Identity.C_tail_closed, Goldbach.BG_Identity.Ucut, Goldbach.BankParams.H]
    have htail_nonneg : 0 ≤ Goldbach.BG_Identity.C_tail_closed := by nlinarith [htail_val]
    have hconst : 0 ≤ ((1252 : ℝ) / 10^6) := by norm_num
    exact mul_nonneg hconst htail_nonneg
, δ_mellin_nonneg := Goldbach.AO_MellinTrunc.δ_mellin_nonneg
, δ_smooth_nonneg := by norm_num
, δ_off_nonneg    := by norm_num
}

/-!
We isolate the remaining AO “wiring” obligation as a single identification statement:
`Mcanon` agrees with the final staged term `AO_Stages.M_off` on the canonical window.

Once this is proved, the four-channel decomposition becomes a purely algebraic telescope
(`Goldbach.AO_Stages.errAO_decomp_window_of_Mcanon_eq`) rather than an axiom.
-/
theorem Mcanon_eq_M_off_on_window :
  ∀ {X N : ℕ}, Goldbach.BankParams.X0 ≤ X →
      N ∈ Goldbach.Windows.EvenIn X Goldbach.BankParams.H →
    Goldbach.AO_Core.Mcanon N = Goldbach.AO_Stages.M_off channels X N := by
  intro X N hX hN
  have hkern :
      Goldbach.AO_KernelTail.E_kernel Goldbach.BankParams.X0 N =
        Goldbach.AO_KernelTail.E_kernel X N := by
    simpa using (Goldbach.AO_KernelTail.E_kernel_congr_X Goldbach.BankParams.X0 X N)
  have hoff :
      Goldbach.AO_OffDiag.E_off Goldbach.BankParams.X0 N =
        Goldbach.AO_OffDiag.E_off X N := by
    simpa using (Goldbach.AO_OffDiag.E_off_congr_X Goldbach.BankParams.X0 X N)
  -- Everything is definitionally independent of `X` on the main track.
  simp [Goldbach.AO_Core.Mcanon, Goldbach.AO_Mcanon.Mcanon, channels, Goldbach.AO_CanonChannels.channels,
    Goldbach.AO_Stages.M_off, Goldbach.AO_Stages.M_kernel, Goldbach.AO_Stages.M_mellin,
    Goldbach.AO_Stages.M_smooth, Goldbach.AO_Stages.M_raw,
    Goldbach.AO_Core.sigma, Goldbach.AO_Core.weight_mass, Goldbach.AO_WeightMass.weight_mass,
    Goldbach.AO_SmoothLoss.E_smooth, Goldbach.AO_MellinTrunc.E_mellin,
    hkern, hoff, add_assoc, add_left_comm, add_comm]

instance : Goldbach.AO_McanonWiring.McanonEqMOffOnWindow channels := by
  refine ⟨by
    intro X N hX hN
    simpa using (Mcanon_eq_M_off_on_window (X := X) (N := N) hX hN)⟩

instance : Bounds channels caps := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro X N hX hN
    have hX' : Goldbach.BG_Bank.X0 ≤ X := by simpa [Goldbach.BG_Bank.X0] using hX
    have hN' : N ∈ Goldbach.Windows.EvenIn X Goldbach.BG_Bank.H := by
      simpa [Goldbach.BG_Bank.H] using hN
    have hkernel :
        |Goldbach.AO_KernelTail.E_kernel X N|
          ≤ Goldbach.BG_Bank.payload_cap X N * Goldbach.BG_Identity.C_tail_closed := by
      simpa using (Goldbach.AO_KernelTail.E_kernel_bound (X := X) (N := N) hX' hN')
    have hcap :
        Goldbach.BG_Bank.payload_cap X N ≤ (1252 : ℝ) / 10^6 := by
      simpa [Goldbach.BG_Bank.X0, Goldbach.BG_Bank.H] using
        (Goldbach.BG_Bank.payload_cap_window_num (X := X) (N := N) hX' hN')
    have htail_val : Goldbach.BG_Identity.C_tail_closed = (99 : ℝ) / 1020100 := by
      norm_num [Goldbach.BG_Identity.C_tail_closed, Goldbach.BG_Identity.Ucut, Goldbach.BankParams.H]
    have htail_nonneg : 0 ≤ Goldbach.BG_Identity.C_tail_closed := by nlinarith [htail_val]
    have hprod :
        Goldbach.BG_Bank.payload_cap X N * Goldbach.BG_Identity.C_tail_closed
          ≤ ((1252 : ℝ) / 10^6) * Goldbach.BG_Identity.C_tail_closed :=
      mul_le_mul_of_nonneg_right hcap htail_nonneg
    have : |channels.E_kernel X N| ≤ caps.δ_kernel := by
      -- Keep `E_kernel` opaque; only unfold the numeric cap and the record projections.
      simpa [channels, caps] using (le_trans hkernel hprod)
    simpa using this
  · intro X N hX hN
    have hmellin :
        |Goldbach.AO_MellinTrunc.E_mellin X N|
          ≤ Goldbach.AO_MellinTrunc.δ_mellin_canon :=
      Goldbach.AO_MellinTrunc.E_mellin_bound (X := X) (N := N) hX hN
    simpa [channels, caps] using hmellin
  · intro X N hX hN
    have hsmooth :
        |Goldbach.AO_SmoothLoss.E_smooth X N| ≤ (0.0008 : ℝ) := by
      have hX' : Goldbach.BG_Bank.X0 ≤ X := by simpa [Goldbach.BG_Bank.X0] using hX
      have hN' : N ∈ Goldbach.Windows.EvenIn X Goldbach.BG_Bank.H := by
        simpa [Goldbach.BG_Bank.H] using hN
      simpa using (Goldbach.AO_SmoothLoss.E_smooth_bound (X := X) (N := N) hX' hN')
    simpa [channels, caps] using hsmooth
  · intro X N hX hN
    have hoff :
        |Goldbach.AO_OffDiag.E_off X N| ≤ (3e-4 : ℝ) :=
      Goldbach.AO_OffDiag.E_off_bound (X := X) (N := N) hX hN
    simpa [channels, caps] using hoff

/-- Total AO cap for the canonical caps. -/
noncomputable abbrev δAO : ℝ :=
  Goldbach.AO_AssembleEnvelope.δAO caps

lemma δAO_nonneg : 0 ≤ δAO := by
  simpa [δAO] using (Goldbach.AO_AssembleEnvelope.δAO_nonneg caps)

/-- The assembled AO envelope bound in the `AO_Major` shape used downstream. -/
lemma errAO_bound {X N : ℕ} (hX : Goldbach.BankParams.X0 ≤ X)
    (hN : N ∈ Goldbach.Windows.EvenIn X Goldbach.BankParams.H) :
    |Goldbach.AO_Major.errAO X N| ≤ δAO := by
  simpa [δAO, Goldbach.AO_Major.errAO, channels] using
    (Goldbach.AO_ErrorEnvelope.errAO_bound (C := channels) (K := caps) hX hN)

end Goldbach.AO_Instantiate
