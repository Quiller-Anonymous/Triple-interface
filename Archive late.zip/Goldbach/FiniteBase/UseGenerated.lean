import Mathlib
import Goldbach.Base.FiniteBaseDefs
import Goldbach.FiniteBase.Generated_real_Proofs

open Goldbach.Base
namespace Goldbach.FiniteBase

abbrev HI : ℕ := 100000

/-- Small-N finite base provided by generated proofs. -/
theorem base_000004_100000 : FiniteBaseUpTo HI := by
  intro N hEven h4 hLe
  exact Goldbach.FiniteBase.Generated_000004_100000.rep_in_range hEven h4 hLe

end Goldbach.FiniteBase
